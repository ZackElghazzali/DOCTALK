"""
propagator.map
==============
Empirical vulnerability map construction and visualization for the
PROPAGATOR framework.

This sub-package provides:

* :class:`VulnerabilityMapCell` — a single cell in the 4-D tensor
  (topology × attack_type × heterogeneity_level × seed_node).
* :class:`VulnerabilityMap` — the full 4-D empirical vulnerability map;
  the **primary deliverable** of PROPAGATOR's measurement phase.
* :class:`VulnerabilityMapBuilder` — orchestrates building the map from
  experiment results or by running a full measurement sweep.
* :class:`PropagatorVisualizer` — produces topology heatmaps, attack
  propagation curves, HST transition plots, and GAF heatmaps.

Quick start
-----------
>>> from propagator.graph import TopologyFactory
>>> from propagator.map import VulnerabilityMapBuilder, PropagatorVisualizer
>>> graphs = {"chain_4": TopologyFactory.chain(4)}
>>> builder = VulnerabilityMapBuilder()
>>> vmap = builder.build_full_map(graphs, trials=5)
>>> viz = PropagatorVisualizer(vmap)
>>> data = viz.topology_heatmap_data("context_poisoning")
"""

from .builder import VulnerabilityMap, VulnerabilityMapBuilder, VulnerabilityMapCell
from .visualizer import PropagatorVisualizer

__all__ = [
    "VulnerabilityMapCell",
    "VulnerabilityMap",
    "VulnerabilityMapBuilder",
    "PropagatorVisualizer",
]
