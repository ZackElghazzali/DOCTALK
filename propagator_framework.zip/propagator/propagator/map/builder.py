"""
propagator.map.builder
======================
Empirical vulnerability map construction for the PROPAGATOR framework.

The vulnerability map is a 4-D tensor indexed by:
    topology × attack_type × heterogeneity_level × seed_node

Each cell stores a :class:`VulnerabilityMapCell` with the distribution over
final infection rates (mean + std over 30 trials), the peak propagation
velocity, PRS, and the effective R₀ for that configuration.

This is the **primary deliverable** of PROPAGATOR's measurement phase.

Typical usage
-------------
>>> from propagator.graph import TopologyFactory
>>> from propagator.map import VulnerabilityMapBuilder
>>> graphs = {"chain_4": TopologyFactory.chain(4), "star_5": TopologyFactory.star(5)}
>>> builder = VulnerabilityMapBuilder()
>>> vmap = builder.build_full_map(graphs, trials=10)
>>> vmap.save("vulnerability_map.json")
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional, Tuple

from ..graph import PropagatorGraph
from ..metrics.prs import compute_prs
from ..sim import (
    ATTACK_BASE_RATES,
    AttackConfig,
    AttackResult,
    AttackType,
    SimulationEngine,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default heterogeneity configs
# ---------------------------------------------------------------------------

_DEFAULT_HETEROGENEITY_CONFIGS: Dict[str, Dict[str, Any]] = {
    "low":    {"sigma_sq": 0.01, "description": "Low heterogeneity (σ²≈0.01)"},
    "medium": {"sigma_sq": 0.10, "description": "Medium heterogeneity (σ²≈0.10)"},
    "high":   {"sigma_sq": 0.30, "description": "High heterogeneity (σ²≈0.30)"},
}

# Map heterogeneity level name → injection strength multiplier
_LEVEL_INJECTION_STRENGTH: Dict[str, float] = {
    "low":    0.3,
    "medium": 0.6,
    "high":   1.0,
}


# ---------------------------------------------------------------------------
# VulnerabilityMapCell
# ---------------------------------------------------------------------------


@dataclass
class VulnerabilityMapCell:
    """
    A single cell in the 4-D vulnerability map tensor.

    Attributes
    ----------
    topology : str
        Name of the topology (e.g. ``"chain_4"``).
    attack_type : str
        Value of the :class:`~propagator.sim.AttackType` enum.
    heterogeneity_level : str
        One of ``"low"``, ``"medium"``, or ``"high"``.
    seed_node : str
        Identifier of the injection seed node.
    mean_infection_rate : float
        Mean final infection rate Ī averaged over all trials, ∈ [0, 1].
    std_infection_rate : float
        Standard deviation of Ī across trials, ≥ 0.
    mean_peak_velocity : float
        Mean peak propagation velocity V_peak across trials.
    prs : float
        Propagation Risk Score for this cell, ∈ [0, 1].
    n_trials : int
        Number of Monte-Carlo trials contributing to this cell.
    r0 : float
        Effective reproduction number R₀ for this topology configuration.
    """

    topology: str
    attack_type: str          # AttackType.value
    heterogeneity_level: str  # "low", "medium", "high"
    seed_node: str
    mean_infection_rate: float
    std_infection_rate: float
    mean_peak_velocity: float
    prs: float
    n_trials: int
    r0: float

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "topology":            self.topology,
            "attack_type":         self.attack_type,
            "heterogeneity_level": self.heterogeneity_level,
            "seed_node":           self.seed_node,
            "mean_infection_rate": self.mean_infection_rate,
            "std_infection_rate":  self.std_infection_rate,
            "mean_peak_velocity":  self.mean_peak_velocity,
            "prs":                 self.prs,
            "n_trials":            self.n_trials,
            "r0":                  self.r0,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VulnerabilityMapCell":
        """Reconstruct a :class:`VulnerabilityMapCell` from a dict."""
        return cls(
            topology=            data["topology"],
            attack_type=         data["attack_type"],
            heterogeneity_level= data["heterogeneity_level"],
            seed_node=           data["seed_node"],
            mean_infection_rate= float(data["mean_infection_rate"]),
            std_infection_rate=  float(data["std_infection_rate"]),
            mean_peak_velocity=  float(data["mean_peak_velocity"]),
            prs=                 float(data["prs"]),
            n_trials=            int(data["n_trials"]),
            r0=                  float(data["r0"]),
        )

    def __repr__(self) -> str:
        return (
            f"VulnerabilityMapCell("
            f"topology={self.topology!r}, attack={self.attack_type!r}, "
            f"level={self.heterogeneity_level!r}, seed={self.seed_node!r}, "
            f"mean_I={self.mean_infection_rate:.4f}, prs={self.prs:.4f})"
        )


# ---------------------------------------------------------------------------
# VulnerabilityMap
# ---------------------------------------------------------------------------


class VulnerabilityMap:
    """
    4-D empirical vulnerability map indexed by:
    ``topology × attack_type × heterogeneity_level × seed_node``.

    Each cell stores a :class:`VulnerabilityMapCell` with the distribution
    over final infection rates (mean + std) and PRS.  This is the
    **primary deliverable** of PROPAGATOR's measurement phase.

    The map is backed by:

    * ``_cells`` — flat list of all cells (preserves insertion order, safe
      for iteration).
    * ``_index`` — nested dict providing O(1) lookup by the 4-D key.
    """

    def __init__(self) -> None:
        self._cells: List[VulnerabilityMapCell] = []
        # Nested index: topology → attack_type → heterogeneity_level → seed_node → cell
        self._index: Dict[str, Dict[str, Dict[str, Dict[str, VulnerabilityMapCell]]]] = {}

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def add_cell(self, cell: VulnerabilityMapCell) -> None:
        """Append *cell* to the map and update the internal index.

        If a cell with identical 4-D key already exists, it is **replaced**
        in the index (but the old entry remains in ``_cells`` — this is
        intentional for append-only auditing).

        Parameters
        ----------
        cell : VulnerabilityMapCell
            The cell to add.
        """
        self._cells.append(cell)
        # Ensure nested dicts exist
        topo_dict = self._index.setdefault(cell.topology, {})
        atk_dict  = topo_dict.setdefault(cell.attack_type, {})
        lvl_dict  = atk_dict.setdefault(cell.heterogeneity_level, {})
        lvl_dict[cell.seed_node] = cell

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_cell(
        self,
        topology: str,
        attack_type: str,
        heterogeneity_level: str,
        seed_node: str,
    ) -> Optional[VulnerabilityMapCell]:
        """Retrieve a single cell by its 4-D key, or ``None``."""
        return (
            self._index
            .get(topology, {})
            .get(attack_type, {})
            .get(heterogeneity_level, {})
            .get(seed_node)
        )

    def get_topology_slice(
        self,
        topology: str,
        heterogeneity_level: str = "high",
    ) -> List[VulnerabilityMapCell]:
        """Return all cells for a given topology and heterogeneity level.

        Parameters
        ----------
        topology : str
            Topology name.
        heterogeneity_level : str
            Heterogeneity level to filter by.  Default ``"high"``.

        Returns
        -------
        list[VulnerabilityMapCell]
            All matching cells (may be empty).
        """
        result: List[VulnerabilityMapCell] = []
        for atk_dict in self._index.get(topology, {}).values():
            for seed_cell in atk_dict.get(heterogeneity_level, {}).values():
                result.append(seed_cell)
        return result

    def get_attack_slice(
        self,
        attack_type: str,
        heterogeneity_level: str = "high",
    ) -> List[VulnerabilityMapCell]:
        """Return all cells for a given attack type and heterogeneity level.

        Parameters
        ----------
        attack_type : str
            Attack type string (``AttackType.value``).
        heterogeneity_level : str
            Heterogeneity level to filter by.  Default ``"high"``.

        Returns
        -------
        list[VulnerabilityMapCell]
        """
        result: List[VulnerabilityMapCell] = []
        for topo_dict in self._index.values():
            for seed_cell in topo_dict.get(attack_type, {}).get(heterogeneity_level, {}).values():
                result.append(seed_cell)
        return result

    def highest_prs_cells(self, n: int = 5) -> List[VulnerabilityMapCell]:
        """Return the *n* cells with the highest PRS values.

        Parameters
        ----------
        n : int
            Number of cells to return.  Default ``5``.

        Returns
        -------
        list[VulnerabilityMapCell]
            Sorted descending by PRS (highest first).
        """
        return sorted(self._cells, key=lambda c: c.prs, reverse=True)[:n]

    def lowest_prs_cells(self, n: int = 5) -> List[VulnerabilityMapCell]:
        """Return the *n* cells with the lowest PRS values.

        Parameters
        ----------
        n : int
            Number of cells to return.  Default ``5``.

        Returns
        -------
        list[VulnerabilityMapCell]
            Sorted ascending by PRS (lowest first).
        """
        return sorted(self._cells, key=lambda c: c.prs)[:n]

    def summary_table(self) -> List[dict]:
        """Return a list of dicts suitable for tabular display.

        Each dict contains all cell fields plus a human-readable label.

        Returns
        -------
        list[dict]
        """
        return [cell.to_dict() for cell in self._cells]

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def n_cells(self) -> int:
        """Total number of cells currently in the map."""
        return len(self._cells)

    @property
    def topologies(self) -> List[str]:
        """Distinct topology names present in the map."""
        return list(self._index.keys())

    @property
    def attack_types(self) -> List[str]:
        """Distinct attack type values present in the map."""
        seen: set = set()
        for topo_dict in self._index.values():
            seen.update(topo_dict.keys())
        return list(seen)

    @property
    def heterogeneity_levels(self) -> List[str]:
        """Distinct heterogeneity levels present in the map."""
        seen: set = set()
        for topo_dict in self._index.values():
            for atk_dict in topo_dict.values():
                seen.update(atk_dict.keys())
        return list(seen)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation of the entire map."""
        return {
            "cells": [cell.to_dict() for cell in self._cells],
            "metadata": {
                "n_cells":             self.n_cells,
                "topologies":          self.topologies,
                "attack_types":        self.attack_types,
                "heterogeneity_levels": self.heterogeneity_levels,
            },
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VulnerabilityMap":
        """Reconstruct a :class:`VulnerabilityMap` from a serialised dict.

        Parameters
        ----------
        data : dict
            Dict produced by :meth:`to_dict`.

        Returns
        -------
        VulnerabilityMap
        """
        vm = cls()
        for cell_dict in data.get("cells", []):
            vm.add_cell(VulnerabilityMapCell.from_dict(cell_dict))
        return vm

    def save(self, path: str) -> None:
        """Serialise the map to a JSON file at *path*.

        Parameters
        ----------
        path : str
            Destination file path.
        """
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2)
        logger.info("VulnerabilityMap saved to %s (%d cells)", path, self.n_cells)

    @classmethod
    def load(cls, path: str) -> "VulnerabilityMap":
        """Load a :class:`VulnerabilityMap` from a JSON file.

        Parameters
        ----------
        path : str
            Source file path.

        Returns
        -------
        VulnerabilityMap
        """
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        vm = cls.from_dict(data)
        logger.info("VulnerabilityMap loaded from %s (%d cells)", path, vm.n_cells)
        return vm

    def __repr__(self) -> str:
        return (
            f"VulnerabilityMap("
            f"cells={self.n_cells}, "
            f"topologies={self.topologies}, "
            f"levels={self.heterogeneity_levels})"
        )


# ---------------------------------------------------------------------------
# VulnerabilityMapBuilder
# ---------------------------------------------------------------------------


class VulnerabilityMapBuilder:
    """Orchestrates building the full empirical vulnerability map.

    The builder accepts an optional *engine_factory* callable that constructs
    a :class:`~propagator.sim.SimulationEngine` for a given graph.  When
    ``None``, a default engine with standard parameters (β=0.3, γ=0.0,
    rounds=20) is used.

    Parameters
    ----------
    engine_factory : callable | None
        Signature: ``engine_factory(graph: PropagatorGraph) → SimulationEngine``.
        If ``None``, a default engine is constructed for each graph.
    """

    def __init__(self, engine_factory=None) -> None:
        self.engine_factory = engine_factory

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _make_engine(self, graph: PropagatorGraph) -> SimulationEngine:
        """Construct (or delegate to factory) a :class:`SimulationEngine`."""
        if self.engine_factory is not None:
            return self.engine_factory(graph)
        return SimulationEngine(
            graph=graph,
            beta=0.3,
            gamma=0.0,
            infection_threshold=0.5,
            rounds=20,
        )

    @staticmethod
    def _cell_from_result(
        topology_name: str,
        attack_type: AttackType,
        heterogeneity_level: str,
        seed_node: str,
        result: AttackResult,
        r0: float,
        prs_override: Optional[float] = None,
    ) -> VulnerabilityMapCell:
        """Construct a :class:`VulnerabilityMapCell` from an :class:`AttackResult`."""
        prs_result = compute_prs(result, attack_type, topology_name)
        prs_value  = prs_override if prs_override is not None else prs_result.prs_value

        return VulnerabilityMapCell(
            topology=            topology_name,
            attack_type=         attack_type.value,
            heterogeneity_level= heterogeneity_level,
            seed_node=           seed_node,
            mean_infection_rate= result.mean_final_rate,
            std_infection_rate=  result.std_final_rate,
            mean_peak_velocity=  result.mean_peak_velocity,
            prs=                 prs_value,
            n_trials=            len(result.final_infection_rates) or result.attack_config.trials,
            r0=                  r0,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_from_results(
        self,
        results: dict,
        topology_graphs: Dict[str, PropagatorGraph],
        prs_by_cell: Optional[dict] = None,
    ) -> VulnerabilityMap:
        """Build a :class:`VulnerabilityMap` from pre-computed experiment results.

        Parameters
        ----------
        results : dict
            Nested mapping:
            ``heterogeneity_level → topology_name → (AttackType, seed_node) → AttackResult``
        topology_graphs : dict[str, PropagatorGraph]
            Mapping from topology name to its graph (used for R₀ computation).
        prs_by_cell : dict | None
            Optional override map:
            ``(topology, attack_type_value, level, seed) → float``
            If provided, the PRS from this dict is used instead of recomputing.

        Returns
        -------
        VulnerabilityMap
        """
        prs_by_cell = prs_by_cell or {}
        vmap = VulnerabilityMap()

        # Cache R₀ per topology to avoid recomputing
        r0_cache: Dict[str, float] = {}
        for topo_name, graph in topology_graphs.items():
            try:
                eng = self._make_engine(graph)
                r0_cache[topo_name] = eng.compute_r0()
            except Exception as exc:
                logger.warning("R₀ computation failed for %s: %s", topo_name, exc)
                r0_cache[topo_name] = 0.0

        for level, topo_dict in results.items():
            for topo_name, attack_dict in topo_dict.items():
                r0 = r0_cache.get(topo_name, 0.0)
                for (attack_type, seed_node), result in attack_dict.items():
                    # attack_type may be AttackType or its string value
                    if isinstance(attack_type, str):
                        try:
                            attack_type = AttackType(attack_type)
                        except ValueError:
                            logger.warning("Unknown AttackType %r — skipping.", attack_type)
                            continue

                    prs_override = prs_by_cell.get(
                        (topo_name, attack_type.value, level, seed_node)
                    )
                    cell = self._cell_from_result(
                        topo_name, attack_type, level, seed_node,
                        result, r0, prs_override,
                    )
                    vmap.add_cell(cell)

        logger.info(
            "build_from_results: constructed VulnerabilityMap with %d cells",
            vmap.n_cells,
        )
        return vmap

    def build_full_map(
        self,
        topology_graphs: Dict[str, PropagatorGraph],
        attack_types: Optional[List] = None,
        heterogeneity_configs: Optional[Dict[str, dict]] = None,
        trials: int = 30,
    ) -> VulnerabilityMap:
        """Run all experiments and build the complete vulnerability map.

        This is the top-level entry point for the PROPAGATOR measurement phase.
        It sweeps all combinations of topology × attack_type ×
        heterogeneity_level × seed_node, running *trials* Monte-Carlo trials
        per cell.

        Parameters
        ----------
        topology_graphs : dict[str, PropagatorGraph]
            Mapping from topology name to its graph.
        attack_types : list | None
            Attack types to include.  Defaults to all five :class:`AttackType`
            members.
        heterogeneity_configs : dict[str, dict] | None
            Mapping ``level_name → {"sigma_sq": float, "description": str}``.
            Default levels: ``low`` (σ²≈0.01), ``medium`` (σ²≈0.10),
            ``high`` (σ²≈0.30).
        trials : int
            Monte-Carlo trials per cell.  Default ``30``.

        Returns
        -------
        VulnerabilityMap
            Fully populated vulnerability map.
        """
        if attack_types is None:
            attack_types = list(AttackType)

        if heterogeneity_configs is None:
            heterogeneity_configs = _DEFAULT_HETEROGENEITY_CONFIGS

        vmap = VulnerabilityMap()

        for topo_name, graph in topology_graphs.items():
            logger.info("build_full_map: processing topology %r", topo_name)
            eng = self._make_engine(graph)

            # Compute R₀ once per topology
            try:
                r0 = eng.compute_r0()
            except Exception as exc:
                logger.warning("R₀ computation failed for %s: %s", topo_name, exc)
                r0 = 0.0

            node_ids = graph.node_ids()
            if not node_ids:
                logger.warning("Topology %r has no nodes — skipping.", topo_name)
                continue

            for level, level_cfg in heterogeneity_configs.items():
                injection_strength = _LEVEL_INJECTION_STRENGTH.get(level, 1.0)

                for attack_type in attack_types:
                    # Accept both AttackType and string
                    if isinstance(attack_type, str):
                        try:
                            attack_type = AttackType(attack_type)
                        except ValueError:
                            logger.warning("Unknown AttackType %r — skipping.", attack_type)
                            continue

                    for seed_node in node_ids:
                        logger.debug(
                            "build_full_map: %s / %s / %s / %s",
                            topo_name, attack_type.value, level, seed_node,
                        )
                        cfg = AttackConfig(
                            attack_type=        attack_type,
                            injection_strength= injection_strength,
                            seed_node_id=       seed_node,
                            trials=             trials,
                        )
                        try:
                            result = eng.run_experiment(cfg)
                        except Exception as exc:
                            logger.error(
                                "Experiment failed (%s/%s/%s/%s): %s",
                                topo_name, attack_type.value, level, seed_node, exc,
                            )
                            continue

                        cell = self._cell_from_result(
                            topo_name, attack_type, level, seed_node, result, r0
                        )
                        vmap.add_cell(cell)

        logger.info(
            "build_full_map: completed — %d cells across %d topologies",
            vmap.n_cells, len(topology_graphs),
        )
        return vmap
