"""
propagator.map.visualizer
=========================
Visualization utilities for the PROPAGATOR vulnerability map.

Produces four visualisation artefacts:

1. **Topology heatmap** — per-topology node infection levels and edge
   transmission rates, coloured by severity.
2. **Attack propagation curves** — time-series of total infection fraction
   for each attack type under a fixed topology.
3. **HST transition plot** — final infection rate as a function of
   heterogeneity level (the Heterogeneity Sensitivity Transition figure).
4. **GAF table** — topology × guardrail-config heatmap coloured by GAF value.

All ``plot_*`` methods require **matplotlib**.  When matplotlib is unavailable
(``try/except ImportError``), the class still works but raises
:class:`RuntimeError` on plotting calls.  All ``*_data`` methods work without
matplotlib and return plain Python dicts suitable for downstream processing
or custom rendering.

Typical usage
-------------
>>> from propagator.map import VulnerabilityMap, PropagatorVisualizer
>>> vmap = VulnerabilityMap.load("vulnerability_map.json")
>>> viz = PropagatorVisualizer(vmap)
>>> data = viz.topology_heatmap_data("context_poisoning")
>>> viz.plot_propagation_curves("chain_4", save_path="curves.png")
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .builder import VulnerabilityMap

logger = logging.getLogger(__name__)

# Optional matplotlib import
try:
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors

    _MPL_AVAILABLE = True
except ImportError:
    _MPL_AVAILABLE = False
    logger.info(
        "matplotlib not available — PropagatorVisualizer.plot_* methods will raise RuntimeError."
    )


# ---------------------------------------------------------------------------
# PropagatorVisualizer
# ---------------------------------------------------------------------------


class PropagatorVisualizer:
    """Produces visualisations of the PROPAGATOR vulnerability map.

    When *vuln_map* is ``None``, only methods that do not require map data
    (e.g. ``plot_gaf_table``) are fully functional.  All other methods that
    access the map will return empty results or raise :class:`ValueError`.

    Parameters
    ----------
    vuln_map : VulnerabilityMap | None
        The vulnerability map to visualise.  May be set or replaced at any
        time by assigning ``self.vuln_map``.
    """

    def __init__(self, vuln_map: Optional[VulnerabilityMap] = None) -> None:
        self.vuln_map = vuln_map

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _require_map(self) -> VulnerabilityMap:
        """Return ``self.vuln_map`` or raise :class:`ValueError`."""
        if self.vuln_map is None:
            raise ValueError(
                "PropagatorVisualizer requires a VulnerabilityMap. "
                "Set self.vuln_map before calling this method."
            )
        return self.vuln_map

    @staticmethod
    def _require_matplotlib() -> None:
        """Raise :class:`RuntimeError` when matplotlib is unavailable."""
        if not _MPL_AVAILABLE:
            raise RuntimeError(
                "matplotlib is required for plotting. "
                "Install it with: pip install matplotlib"
            )

    @staticmethod
    def _level_order(levels: List[str]) -> List[str]:
        """Sort heterogeneity levels in canonical order: low → medium → high."""
        order = {"low": 0, "medium": 1, "high": 2}
        return sorted(levels, key=lambda lvl: order.get(lvl, 99))

    # ------------------------------------------------------------------
    # Data methods (no matplotlib needed)
    # ------------------------------------------------------------------

    def topology_heatmap_data(
        self,
        attack_type: str,
        heterogeneity_level: str = "high",
    ) -> Dict[str, Any]:
        """Compute topology heatmap data for *attack_type*.

        Returns a nested dict mapping each topology name to its aggregated
        node infection levels, edge transmission rate proxies, and PRS.

        Parameters
        ----------
        attack_type : str
            Attack type value string (e.g. ``"context_poisoning"``).
        heterogeneity_level : str
            Heterogeneity level to slice on.  Default ``"high"``.

        Returns
        -------
        dict
            Structure::

                {
                    topology_name: {
                        "node_infection_levels": {node_id: mean_infection_rate},
                        "edge_transmission_rates": {},   # placeholder; populated when
                                                         # per-edge data is available
                        "prs": float,
                        "mean_infection_rate": float,
                        "std_infection_rate": float,
                    }
                }
        """
        vmap = self._require_map()
        cells = vmap.get_attack_slice(attack_type, heterogeneity_level)

        result: Dict[str, Any] = {}
        for cell in cells:
            topo = cell.topology
            if topo not in result:
                result[topo] = {
                    "node_infection_levels": {},
                    "edge_transmission_rates": {},
                    "prs": 0.0,
                    "mean_infection_rate": 0.0,
                    "std_infection_rate": 0.0,
                    "_prs_list": [],
                    "_mean_list": [],
                    "_std_list": [],
                }
            entry = result[topo]
            entry["node_infection_levels"][cell.seed_node] = cell.mean_infection_rate
            entry["_prs_list"].append(cell.prs)
            entry["_mean_list"].append(cell.mean_infection_rate)
            entry["_std_list"].append(cell.std_infection_rate)

        # Aggregate per-topology stats
        for topo, entry in result.items():
            n = len(entry["_prs_list"])
            if n > 0:
                entry["prs"] = sum(entry["_prs_list"]) / n
                entry["mean_infection_rate"] = sum(entry["_mean_list"]) / n
                entry["std_infection_rate"] = sum(entry["_std_list"]) / n
            # Remove internal bookkeeping keys
            for k in ("_prs_list", "_mean_list", "_std_list"):
                entry.pop(k, None)

        return result

    def attack_propagation_curves_data(
        self,
        topology: str,
        heterogeneity_level: str = "high",
    ) -> Dict[str, Any]:
        """Compute propagation curve data for each attack type.

        Since the vulnerability map stores only aggregated statistics (not
        full time-series), this method synthesises representative curves
        from the stored mean infection rate and R₀ using a simple SIR-like
        model:  I(t) = I_final * (1 - exp(-r0 * t / T)).

        Parameters
        ----------
        topology : str
            Topology name.
        heterogeneity_level : str
            Heterogeneity level.  Default ``"high"``.

        Returns
        -------
        dict
            Structure::

                {
                    attack_type_value: {
                        "rounds": [0, 1, ..., T],
                        "mean_total_infection": [float, ...]
                    }
                }
        """
        import math

        vmap = self._require_map()
        cells = vmap.get_topology_slice(topology, heterogeneity_level)

        # Group cells by attack type; average over seed nodes
        by_attack: Dict[str, List] = {}
        for cell in cells:
            by_attack.setdefault(cell.attack_type, []).append(cell)

        T = 20  # default rounds
        result: Dict[str, Any] = {}

        for atk_val, atk_cells in by_attack.items():
            mean_I_final = sum(c.mean_infection_rate for c in atk_cells) / len(atk_cells)
            mean_r0 = sum(c.r0 for c in atk_cells) / len(atk_cells)
            r0_scale = max(0.1, mean_r0)

            rounds = list(range(T + 1))
            # Synthesised growth curve: logistic-like approximation
            curve = []
            for t in rounds:
                # I(t) = I_final / (1 + (I_final/I0 - 1) * exp(-r0_scale * t / T))
                # with I0 = 0.05 (small seed at t=0)
                I0 = 0.05
                if mean_I_final > 0:
                    val = mean_I_final / (
                        1.0 + (mean_I_final / max(I0, 1e-6) - 1.0)
                        * math.exp(-r0_scale * t / max(T, 1))
                    )
                    val = min(mean_I_final, max(I0 if t > 0 else 0.0, val))
                else:
                    val = 0.0
                curve.append(round(val, 6))

            result[atk_val] = {
                "rounds":                rounds,
                "mean_total_infection":  curve,
                "mean_final_rate":       mean_I_final,
                "r0":                    mean_r0,
            }

        return result

    def heterogeneity_transition_data(
        self,
        topology: str,
        attack_type: str,
    ) -> Dict[str, Any]:
        """Compute the HST (Heterogeneity Sensitivity Transition) data.

        Returns the final infection rate (mean ± std) as a function of
        heterogeneity level for a fixed topology and attack type.

        Parameters
        ----------
        topology : str
            Topology name.
        attack_type : str
            Attack type value string.

        Returns
        -------
        dict
            Structure::

                {
                    "levels": ["low", "medium", "high"],
                    "mean_infection": [float, ...],
                    "std_infection":  [float, ...],
                    "prs":            [float, ...],
                }
        """
        vmap = self._require_map()
        index = vmap._index

        topo_dict = index.get(topology, {})
        atk_dict = topo_dict.get(attack_type, {})

        if not atk_dict:
            return {"levels": [], "mean_infection": [], "std_infection": [], "prs": []}

        ordered_levels = self._level_order(list(atk_dict.keys()))
        mean_vals: List[float] = []
        std_vals:  List[float] = []
        prs_vals:  List[float] = []

        for level in ordered_levels:
            seed_cells = list(atk_dict[level].values())
            if seed_cells:
                mean_vals.append(
                    sum(c.mean_infection_rate for c in seed_cells) / len(seed_cells)
                )
                std_vals.append(
                    sum(c.std_infection_rate for c in seed_cells) / len(seed_cells)
                )
                prs_vals.append(
                    sum(c.prs for c in seed_cells) / len(seed_cells)
                )
            else:
                mean_vals.append(0.0)
                std_vals.append(0.0)
                prs_vals.append(0.0)

        return {
            "levels":          ordered_levels,
            "mean_infection":  mean_vals,
            "std_infection":   std_vals,
            "prs":             prs_vals,
        }

    def prs_comparison_table(
        self,
        heterogeneity_level: str = "high",
    ) -> List[dict]:
        """Build a flat PRS comparison table across topologies and attack types.

        Parameters
        ----------
        heterogeneity_level : str
            Heterogeneity level to filter on.  Default ``"high"``.

        Returns
        -------
        list[dict]
            Each entry: ``{"topology": str, "attack_type": str, "prs": float,
            "mean_infection_rate": float}``.
        """
        vmap = self._require_map()
        rows: List[dict] = []

        for topo, topo_dict in vmap._index.items():
            for atk, atk_dict in topo_dict.items():
                seed_cells = list(atk_dict.get(heterogeneity_level, {}).values())
                if not seed_cells:
                    continue
                avg_prs  = sum(c.prs for c in seed_cells) / len(seed_cells)
                avg_mean = sum(c.mean_infection_rate for c in seed_cells) / len(seed_cells)
                rows.append({
                    "topology":            topo,
                    "attack_type":         atk,
                    "prs":                 round(avg_prs, 6),
                    "mean_infection_rate": round(avg_mean, 6),
                })

        # Sort by PRS descending
        rows.sort(key=lambda r: r["prs"], reverse=True)
        return rows

    # ------------------------------------------------------------------
    # Plot methods (require matplotlib)
    # ------------------------------------------------------------------

    def plot_topology_heatmap(
        self,
        attack_type: str,
        heterogeneity_level: str = "high",
        save_path: Optional[str] = None,
    ) -> None:
        """Plot a topology heatmap: one subplot per topology.

        Each subplot shows a bar chart of mean infection rate per seed node,
        with the PRS annotated in the title.

        Parameters
        ----------
        attack_type : str
            Attack type value string.
        heterogeneity_level : str
            Heterogeneity level.  Default ``"high"``.
        save_path : str | None
            If provided, save the figure to this path instead of displaying.
        """
        self._require_matplotlib()
        data = self.topology_heatmap_data(attack_type, heterogeneity_level)

        if not data:
            logger.warning("topology_heatmap_data returned empty — nothing to plot.")
            return

        n_topos = len(data)
        fig, axes = plt.subplots(
            1, n_topos,
            figsize=(max(4, 4 * n_topos), 4),
            squeeze=False,
        )

        cmap = plt.get_cmap("YlOrRd")

        for ax, (topo_name, topo_data) in zip(axes[0], data.items()):
            node_ids     = list(topo_data["node_infection_levels"].keys())
            infect_rates = [topo_data["node_infection_levels"][n] for n in node_ids]
            colors = [cmap(v) for v in infect_rates]

            ax.bar(range(len(node_ids)), infect_rates, color=colors)
            ax.set_xticks(range(len(node_ids)))
            ax.set_xticklabels(node_ids, rotation=45, ha="right", fontsize=7)
            ax.set_ylim(0, 1)
            ax.set_ylabel("Mean Infection Rate")
            ax.set_title(
                f"{topo_name}\nPRS={topo_data['prs']:.3f}",
                fontsize=9,
            )
            ax.grid(axis="y", alpha=0.3)

        fig.suptitle(
            f"Topology Heatmap — attack: {attack_type}, level: {heterogeneity_level}",
            fontsize=11,
        )
        plt.tight_layout()

        if save_path:
            fig.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info("Topology heatmap saved to %s", save_path)
        else:
            plt.show()
        plt.close(fig)

    def plot_propagation_curves(
        self,
        topology: str,
        heterogeneity_level: str = "high",
        save_path: Optional[str] = None,
    ) -> None:
        """Plot time series of total infection for each attack type.

        Parameters
        ----------
        topology : str
            Topology name.
        heterogeneity_level : str
            Heterogeneity level.  Default ``"high"``.
        save_path : str | None
            If provided, save the figure to this path.
        """
        self._require_matplotlib()
        data = self.attack_propagation_curves_data(topology, heterogeneity_level)

        if not data:
            logger.warning("attack_propagation_curves_data returned empty — nothing to plot.")
            return

        fig, ax = plt.subplots(figsize=(8, 5))

        linestyles = ["-", "--", "-.", ":", (0, (3, 1, 1, 1))]
        markers    = ["o", "s", "^", "D", "v"]

        for idx, (atk_val, curve_data) in enumerate(sorted(data.items())):
            ls = linestyles[idx % len(linestyles)]
            mk = markers[idx % len(markers)]
            ax.plot(
                curve_data["rounds"],
                curve_data["mean_total_infection"],
                label=atk_val,
                linestyle=ls,
                marker=mk,
                markevery=max(1, len(curve_data["rounds"]) // 5),
                linewidth=1.8,
                markersize=5,
            )

        ax.set_xlabel("Round (t)")
        ax.set_ylabel("Mean Total Infection Rate")
        ax.set_ylim(0, 1.05)
        ax.set_title(f"Attack Propagation Curves — topology: {topology}, level: {heterogeneity_level}")
        ax.legend(fontsize=8, loc="upper left")
        ax.grid(alpha=0.3)

        plt.tight_layout()
        if save_path:
            fig.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info("Propagation curves saved to %s", save_path)
        else:
            plt.show()
        plt.close(fig)

    def plot_hst_transition(
        self,
        topology: str,
        attack_type: str,
        save_path: Optional[str] = None,
    ) -> None:
        """Plot infection rate vs. heterogeneity level (the HST figure).

        Shows mean ± std error bars across heterogeneity levels for a fixed
        topology and attack type.

        Parameters
        ----------
        topology : str
            Topology name.
        attack_type : str
            Attack type value string.
        save_path : str | None
            If provided, save the figure to this path.
        """
        self._require_matplotlib()
        data = self.heterogeneity_transition_data(topology, attack_type)

        if not data.get("levels"):
            logger.warning("heterogeneity_transition_data returned empty — nothing to plot.")
            return

        levels        = data["levels"]
        mean_vals     = data["mean_infection"]
        std_vals      = data["std_infection"]
        prs_vals      = data["prs"]

        fig, ax1 = plt.subplots(figsize=(7, 4))

        x = range(len(levels))
        ax1.errorbar(
            x,
            mean_vals,
            yerr=std_vals,
            fmt="-o",
            color="steelblue",
            capsize=5,
            linewidth=2,
            markersize=7,
            label="Mean infection rate ± std",
        )
        ax1.set_xlabel("Heterogeneity Level")
        ax1.set_ylabel("Mean Final Infection Rate", color="steelblue")
        ax1.set_xticks(list(x))
        ax1.set_xticklabels(levels)
        ax1.set_ylim(0, 1.05)
        ax1.tick_params(axis="y", labelcolor="steelblue")
        ax1.grid(alpha=0.3)

        # Secondary axis for PRS
        ax2 = ax1.twinx()
        ax2.plot(
            x, prs_vals,
            "--s",
            color="firebrick",
            linewidth=1.5,
            markersize=6,
            label="PRS",
        )
        ax2.set_ylabel("PRS", color="firebrick")
        ax2.set_ylim(0, 1.05)
        ax2.tick_params(axis="y", labelcolor="firebrick")

        fig.suptitle(
            f"HST Transition — topology: {topology}, attack: {attack_type}",
            fontsize=11,
        )

        # Combined legend
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", fontsize=8)

        plt.tight_layout()
        if save_path:
            fig.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info("HST transition plot saved to %s", save_path)
        else:
            plt.show()
        plt.close(fig)

    def plot_gaf_table(
        self,
        gaf_table: dict,
        save_path: Optional[str] = None,
    ) -> None:
        """Plot a GAF heatmap: topology × guardrail_config, coloured by GAF value.

        Parameters
        ----------
        gaf_table : dict
            A nested dict of the form::

                {
                    topology_name: {
                        guardrail_config: gaf_value (float)
                    }
                }

            or a ``GAFTable.to_dataframe()`` result.
        save_path : str | None
            If provided, save the figure to this path.
        """
        self._require_matplotlib()
        import numpy as np

        if not gaf_table:
            logger.warning("gaf_table is empty — nothing to plot.")
            return

        # Normalise: outer key = topology or config, inner = other dimension
        # Accept both {topology: {config: val}} and {config: {atk: val}} shapes.
        topologies   = sorted(gaf_table.keys())
        all_configs: set = set()
        for v in gaf_table.values():
            if isinstance(v, dict):
                all_configs.update(v.keys())
        configs = sorted(all_configs)

        if not configs:
            logger.warning("gaf_table has no inner keys — nothing to plot.")
            return

        # Build matrix
        matrix = np.zeros((len(topologies), len(configs)), dtype=float)
        for i, topo in enumerate(topologies):
            for j, cfg in enumerate(configs):
                raw = gaf_table.get(topo, {}).get(cfg, 0.0)
                if hasattr(raw, "gaf_value"):
                    raw = raw.gaf_value
                matrix[i, j] = float(raw)

        fig, ax = plt.subplots(
            figsize=(max(6, 1.5 * len(configs)), max(4, 0.8 * len(topologies)))
        )
        im = ax.imshow(matrix, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
        plt.colorbar(im, ax=ax, label="GAF value")

        ax.set_xticks(range(len(configs)))
        ax.set_xticklabels(configs, rotation=45, ha="right", fontsize=8)
        ax.set_yticks(range(len(topologies)))
        ax.set_yticklabels(topologies, fontsize=8)
        ax.set_xlabel("Guardrail Configuration")
        ax.set_ylabel("Topology")
        ax.set_title("Guardrail Attenuation Factor (GAF) Heatmap")

        # Annotate cells
        for i in range(len(topologies)):
            for j in range(len(configs)):
                val = matrix[i, j]
                color = "black" if 0.2 < val < 0.8 else "white"
                ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                        fontsize=7, color=color)

        plt.tight_layout()
        if save_path:
            fig.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info("GAF table plot saved to %s", save_path)
        else:
            plt.show()
        plt.close(fig)
