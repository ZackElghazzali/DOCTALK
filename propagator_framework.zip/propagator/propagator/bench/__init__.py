"""
propagator.bench
================
Benchmarking and live-integration utilities for the PROPAGATOR framework.

This sub-package provides non-invasive hooks into Microsoft Agent Framework
(MAF) 1.0 inter-agent messaging, a legacy hook for AutoGen (ag2, for backward
compatibility), and a purpose-built harness for the DocTalk multi-agent system.

Primary exports (MAF 1.0)
--------------------------
PropagatorMAFHook
    Multi-agent hook that attaches a ``ContextProvider`` to each MAF ``Agent``
    instance.  Intercepts every inbound message, runs guardrail checks, and
    builds an :class:`InterceptedMessage` log.

PropagatorContextProvider
    Single-agent ``ContextProvider`` subclass.  Can be attached directly via
    ``Agent(..., context_providers=[provider])``.

PropagatorMAFMiddleware
    Middleware factory for wrapping a single ``Agent`` with guardrail
    interception using the ``async (context, next) -> None`` pattern.

InterceptedMessage
    Dataclass holding the full record of a single intercepted message:
    sender/receiver IDs, content, anomaly score, quarantine status, check
    results, and round number.

DocTalkHarness
    Specialised harness that knows the DocTalk agent topology (orchestrator +
    five specialists) and provides helpers for:
    - Framework-agnostic graph construction (:meth:`build_graph`,
      :meth:`build_rewired_graph`)
    - MAF live hook attachment (:meth:`attach_hook`)
    - Full MAF workflow construction (:meth:`build_maf_workflow`)
    - Adversarial prompt generation

Legacy exports (AutoGen / ag2 — backward compatibility)
--------------------------------------------------------
PropagatorAutoGenHook
    Instance-level monkey-patching wrapper for AutoGen
    ``ConversableAgent.receive()``.  Retained for users still on ag2.
    New projects should use :class:`PropagatorMAFHook`.
"""

# MAF 1.0 — primary
from .maf_hook import (
    InterceptedMessage,
    PropagatorContextProvider,
    PropagatorMAFHook,
    PropagatorMAFMiddleware,
)

# DocTalk harness (MAF-native)
from .docTalk_harness import DocTalkHarness

# Legacy AutoGen hook — backward compatibility
from .autogen_hook import PropagatorAutoGenHook

__all__ = [
    # MAF (primary)
    "PropagatorMAFHook",
    "PropagatorContextProvider",
    "PropagatorMAFMiddleware",
    "InterceptedMessage",
    # DocTalk
    "DocTalkHarness",
    # Legacy
    "PropagatorAutoGenHook",
]
