"""
propagator.bench
================
Benchmarking utilities for the PROPAGATOR framework.

This sub-package provides non-invasive hooks into AutoGen (ag2) inter-agent
messaging and a purpose-built harness for the DocTalk multi-agent system.

Exports
-------
PropagatorAutoGenHook
    Instance-level monkey-patching wrapper for AutoGen ``ConversableAgent.receive()``.
    Intercepts every message, runs guardrail checks, and builds an
    :class:`InterceptedMessage` log.

InterceptedMessage
    Dataclass holding the full record of a single intercepted message:
    sender/receiver IDs, content, anomaly score, quarantine status, check
    results, and round number.

DocTalkHarness
    Specialised harness that knows the DocTalk agent topology (orchestrator +
    five specialists) and provides helpers for graph construction,
    adversarial prompt generation, and AutoGen hook attachment.
"""

from .autogen_hook import InterceptedMessage, PropagatorAutoGenHook
from .docTalk_harness import DocTalkHarness

__all__ = [
    "PropagatorAutoGenHook",
    "InterceptedMessage",
    "DocTalkHarness",
]
