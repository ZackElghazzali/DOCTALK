"""
propagator.bench.autogen_hook
=============================
Non-invasive hook into AutoGen (ag2 ≥ 0.9.x) inter-agent message-passing.

Design
------
AutoGen's :class:`ConversableAgent` exposes a ``receive()`` method that
is called whenever the agent receives a message from another agent.  This
module wraps that method **at the instance level** using
:func:`functools.wraps` + closure replacement, so the AutoGen source code
is never modified.

Degraded operation
------------------
If AutoGen is not installed, all hook operations are no-ops and a warning is
emitted.  Import the AutoGen type ``ConversableAgent`` only under
``TYPE_CHECKING`` to keep this module importable without AutoGen present.

Typical usage
-------------
::

    from propagator.bench import PropagatorAutoGenHook
    from propagator.graph import PropagatorGraph

    graph = PropagatorGraph(...)
    hook = PropagatorAutoGenHook(graph, guardrail_layer=layer)
    hook.attach({"orchestrator": orch_agent, "advice": advice_agent, ...})
    # ... run conversation ...
    log = hook.get_message_log()
    hook.detach()
"""

from __future__ import annotations

import functools
import logging
import time
import uuid
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from ..graph import PropagatorGraph
from ..guardrails import GuardrailLayer

if TYPE_CHECKING:
    # Only imported for type annotations; never executed at runtime.
    try:
        from autogen import ConversableAgent  # type: ignore[import]
    except ImportError:
        pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional AutoGen availability check
# ---------------------------------------------------------------------------

_AUTOGEN_AVAILABLE: bool = False
try:
    import autogen as _autogen_module  # type: ignore[import]
    _AUTOGEN_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# InterceptedMessage
# ---------------------------------------------------------------------------


@dataclass
class InterceptedMessage:
    """
    A single message intercepted by :class:`PropagatorAutoGenHook`.

    Attributes
    ----------
    message_id : str
        UUID v4 assigned at interception time.
    sender_id : str
        Node ID of the sending agent (matching a :class:`~propagator.graph.AgentNode`).
    receiver_id : str
        Node ID of the receiving agent.
    content : str
        Full message content as a string (dict-typed AutoGen messages are
        serialised with ``str()``).
    timestamp : float
        Unix timestamp (``time.time()``) at interception.
    anomaly_score : float
        Maximum anomaly score reported by any check, ∈ [0, 1].
        0.0 if no guardrail is present on this edge.
    quarantined : bool
        True if the guardrail decided BLOCK or QUARANTINE.
    guardrail_tier : str | None
        Tier name (e.g. ``"G2"``) of the guardrail that processed this message,
        or ``None`` if no guardrail was present.
    check_results : list[dict]
        Serialised :class:`~propagator.guardrails.CheckResult` dicts from
        each sub-check.
    round_number : int
        Monotonically increasing counter per (sender, receiver) pair,
        approximately tracking conversation rounds.
    """

    message_id: str
    sender_id: str
    receiver_id: str
    content: str
    timestamp: float
    anomaly_score: float
    quarantined: bool
    guardrail_tier: Optional[str]
    check_results: List[dict]
    round_number: int

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "message_id": self.message_id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "content": self.content,
            "timestamp": self.timestamp,
            "anomaly_score": self.anomaly_score,
            "quarantined": self.quarantined,
            "guardrail_tier": self.guardrail_tier,
            "check_results": list(self.check_results),
            "round_number": self.round_number,
        }

    def __repr__(self) -> str:
        return (
            f"InterceptedMessage(id={self.message_id[:8]}..., "
            f"{self.sender_id!r}→{self.receiver_id!r}, "
            f"score={self.anomaly_score:.3f}, "
            f"quarantined={self.quarantined})"
        )


# ---------------------------------------------------------------------------
# Safe-placeholder constant
# ---------------------------------------------------------------------------

_SAFE_PLACEHOLDER_CONTENT = (
    "[MESSAGE BLOCKED BY PROPAGATOR GUARDRAIL — anomalous content detected. "
    "The original message has been quarantined for review.]"
)


# ---------------------------------------------------------------------------
# PropagatorAutoGenHook
# ---------------------------------------------------------------------------


class PropagatorAutoGenHook:
    """
    Non-invasive hook into AutoGen (ag2) inter-agent message-passing.

    Wraps :meth:`ConversableAgent.receive` at the *instance level* using
    monkey-patching / decoration.  The original framework code is NOT
    modified.

    Parameters
    ----------
    graph : PropagatorGraph
        The PROPAGATOR graph model for this system.  Node IDs must match the
        keys passed to :meth:`attach`.
    guardrail_layer : GuardrailLayer | None
        Optional layer of edge guardrails.  When present, each intercepted
        message is checked against the guardrail on the corresponding edge.
    log_messages : bool
        Whether to store every intercepted message in the message log.
        Default ``True``.  Set to ``False`` for high-throughput production use
        where memory is a concern.
    block_on_quarantine : bool
        When ``True``, messages that receive a BLOCK / QUARANTINE decision are
        replaced with :data:`_SAFE_PLACEHOLDER_CONTENT` before being forwarded
        to the original ``receive()`` method.

    Usage
    -----
    ::

        hook = PropagatorAutoGenHook(graph, guardrail_layer)
        hook.attach({"orchestrator": orch, "advice": advice_agent})
        # … run your AutoGen conversation …
        log = hook.get_message_log()
        hook.detach()
    """

    def __init__(
        self,
        graph: PropagatorGraph,
        guardrail_layer: Optional[GuardrailLayer] = None,
        log_messages: bool = True,
        block_on_quarantine: bool = False,
    ) -> None:
        self.graph = graph
        self.guardrail_layer = guardrail_layer
        self.log_messages = log_messages
        self.block_on_quarantine = block_on_quarantine

        # Maps agent node_id → original receive() method
        self._original_receive_methods: Dict[str, Any] = {}
        # Maps (sender_id, receiver_id) → round counter
        self._round_counters: Dict[Tuple[str, str], int] = {}

        self._message_log: List[InterceptedMessage] = []
        self._quarantine_log: List[InterceptedMessage] = []
        self._attached: bool = False

        if not _AUTOGEN_AVAILABLE:
            warnings.warn(
                "AutoGen (ag2) is not installed. "
                "PropagatorAutoGenHook will operate in no-op degraded mode; "
                "attach() and detach() will be silent no-ops.",
                RuntimeWarning,
                stacklevel=2,
            )

    # ------------------------------------------------------------------
    # Attach / detach
    # ------------------------------------------------------------------

    def attach(self, agents: Dict[str, Any]) -> None:
        """
        Monkey-patch the ``receive()`` method of each agent in *agents*.

        Parameters
        ----------
        agents : dict[str, Any]
            Mapping from agent node_id (must match :class:`~propagator.graph.AgentNode`
            ``node_id`` values) to AutoGen :class:`ConversableAgent` instances.

        Raises
        ------
        RuntimeError
            If already attached.

        Notes
        -----
        If AutoGen is not installed, this method is a no-op.
        """
        if self._attached:
            raise RuntimeError("PropagatorAutoGenHook is already attached. Call detach() first.")

        if not _AUTOGEN_AVAILABLE:
            logger.debug("AutoGen not available; attach() is a no-op.")
            self._attached = True
            return

        for node_id, agent in agents.items():
            if not hasattr(agent, "receive"):
                logger.warning(
                    "Agent %r has no receive() method; skipping hook attachment.",
                    node_id,
                )
                continue

            original_receive = agent.receive
            self._original_receive_methods[node_id] = original_receive

            # Capture node_id in closure (critical — must NOT use late binding)
            wrapped = self._make_receive_wrapper(
                node_id=node_id,
                original_receive=original_receive,
            )
            # Bind the wrapped method to the agent instance
            agent.receive = wrapped

        self._attached = True
        logger.debug("PropagatorAutoGenHook attached to agents: %s", list(agents.keys()))

    def detach(self) -> None:
        """
        Restore all original ``receive()`` methods and clear internal state.

        Safe to call multiple times.
        """
        if not _AUTOGEN_AVAILABLE:
            self._attached = False
            return

        for node_id, original_method in self._original_receive_methods.items():
            # We don't hold a reference to the agent here, so we try to reach it
            # through the bound method's __self__.
            try:
                agent = original_method.__self__
                agent.receive = original_method
            except AttributeError:
                # Could be a function (unbound) — just log and continue
                logger.debug("Could not restore receive() for agent %r", node_id)

        self._original_receive_methods.clear()
        self._attached = False
        logger.debug("PropagatorAutoGenHook detached.")

    # ------------------------------------------------------------------
    # Core wrapper factory
    # ------------------------------------------------------------------

    def _make_receive_wrapper(
        self,
        node_id: str,
        original_receive: Any,
    ) -> Any:
        """
        Create a wrapped version of ``receive()`` for the agent with *node_id*.

        The wrapper:
        1. Extracts the sender's name and message content.
        2. Runs a guardrail check on the (sender → receiver) edge if one exists.
        3. Logs the :class:`InterceptedMessage`.
        4. Optionally replaces the message content with a safe placeholder.
        5. Calls the original ``receive()`` and returns its result.
        """
        hook = self  # capture self explicitly for the closure

        @functools.wraps(original_receive)
        def _wrapped_receive(
            message: Any,
            sender: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            receiver_id = node_id

            # ---- Determine sender identity --------------------------------
            sender_id: str
            if hasattr(sender, "name"):
                sender_id = str(sender.name)
            elif isinstance(sender, str):
                sender_id = sender
            else:
                sender_id = repr(sender)

            # ---- Extract content from message (AutoGen uses dict or str) --
            content: str
            if isinstance(message, dict):
                content = str(message.get("content", message))
            elif isinstance(message, str):
                content = message
            else:
                content = str(message)

            # ---- Guardrail check ------------------------------------------
            anomaly_score = 0.0
            quarantined = False
            guardrail_tier: Optional[str] = None
            check_results_dicts: List[dict] = []

            if hook.guardrail_layer is not None and (sender_id, receiver_id) in hook.guardrail_layer._edge_guards:
                decision = hook.guardrail_layer.evaluate_edge(sender_id, receiver_id, content)
                if decision is not None:
                    anomaly_score = decision.combined_anomaly_score
                    quarantined = decision.quarantined
                    guardrail_tier = decision.tier.value
                    check_results_dicts = [cr.to_dict() for cr in decision.check_results]
            elif hook.guardrail_layer is not None:
                # Edge exists in graph but no guardrail — still run passive score
                pass

            # ---- Round counter -------------------------------------------
            edge_key = (sender_id, receiver_id)
            round_num = hook._round_counters.get(edge_key, 0) + 1
            hook._round_counters[edge_key] = round_num

            # ---- Build InterceptedMessage --------------------------------
            intercepted = InterceptedMessage(
                message_id=str(uuid.uuid4()),
                sender_id=sender_id,
                receiver_id=receiver_id,
                content=content,
                timestamp=time.time(),
                anomaly_score=anomaly_score,
                quarantined=quarantined,
                guardrail_tier=guardrail_tier,
                check_results=check_results_dicts,
                round_number=round_num,
            )

            if hook.log_messages:
                hook._message_log.append(intercepted)
            if quarantined:
                hook._quarantine_log.append(intercepted)

            # ---- Optionally block -----------------------------------------
            if quarantined and hook.block_on_quarantine:
                logger.info(
                    "PROPAGATOR: message %s→%s quarantined (score=%.3f); replacing content.",
                    sender_id,
                    receiver_id,
                    anomaly_score,
                )
                if isinstance(message, dict):
                    message = dict(message)
                    message["content"] = _SAFE_PLACEHOLDER_CONTENT
                else:
                    message = _SAFE_PLACEHOLDER_CONTENT

            return original_receive(message, sender, *args, **kwargs)

        return _wrapped_receive

    # ------------------------------------------------------------------
    # Log accessors
    # ------------------------------------------------------------------

    def get_message_log(self) -> List[InterceptedMessage]:
        """Return the full intercepted message log (newest last)."""
        return list(self._message_log)

    def get_quarantine_log(self) -> List[InterceptedMessage]:
        """Return only messages that were quarantined."""
        return list(self._quarantine_log)

    def clear_logs(self) -> None:
        """Clear message and quarantine logs (does not affect attached state)."""
        self._message_log.clear()
        self._quarantine_log.clear()
        self._round_counters.clear()

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def extract_infection_signals(self) -> Dict[str, float]:
        """
        Estimate per-node infection level from the intercepted message log.

        Heuristic
        ---------
        For each agent *v*, the estimated infection level I_v is the fraction
        of messages **sent** by *v* that had ``anomaly_score > 0.3``.

        Returns
        -------
        dict[str, float]
            node_id → estimated I_i ∈ [0, 1].
        """
        sent_counts: Dict[str, int] = {}
        high_anomaly_counts: Dict[str, int] = {}

        for msg in self._message_log:
            sid = msg.sender_id
            sent_counts[sid] = sent_counts.get(sid, 0) + 1
            if msg.anomaly_score > 0.3:
                high_anomaly_counts[sid] = high_anomaly_counts.get(sid, 0) + 1

        result: Dict[str, float] = {}
        for node_id in sent_counts:
            total = sent_counts[node_id]
            high = high_anomaly_counts.get(node_id, 0)
            result[node_id] = high / total if total > 0 else 0.0

        # Include nodes that never sent (infection level = 0)
        for nid in self.graph.node_ids():
            result.setdefault(nid, 0.0)

        return result

    def build_empirical_transmission_rates(self) -> Dict[Tuple[str, str], float]:
        """
        Compute empirical per-edge transmission rate from the intercepted log.

        For each directed edge (u → v), the empirical rate is the fraction of
        messages sent from u to v that had ``anomaly_score > 0.3`` at v.

        Returns
        -------
        dict[(source_id, target_id), float]
            Empirical transmission rate ∈ [0, 1] per edge.
        """
        edge_totals: Dict[Tuple[str, str], int] = {}
        edge_high: Dict[Tuple[str, str], int] = {}

        for msg in self._message_log:
            key = (msg.sender_id, msg.receiver_id)
            edge_totals[key] = edge_totals.get(key, 0) + 1
            if msg.anomaly_score > 0.3:
                edge_high[key] = edge_high.get(key, 0) + 1

        result: Dict[Tuple[str, str], float] = {}
        for edge_key, total in edge_totals.items():
            high = edge_high.get(edge_key, 0)
            result[edge_key] = high / total if total > 0 else 0.0

        return result

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"PropagatorAutoGenHook("
            f"attached={self._attached}, "
            f"agents={list(self._original_receive_methods.keys())}, "
            f"log_size={len(self._message_log)}, "
            f"quarantined={len(self._quarantine_log)})"
        )
