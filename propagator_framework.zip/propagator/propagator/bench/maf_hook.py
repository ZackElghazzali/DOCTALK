"""
propagator.bench.maf_hook
==========================
Non-invasive integration with Microsoft Agent Framework (MAF) 1.0
inter-agent message passing.

Design
------
MAF exposes two clean extension points that PROPAGATOR uses:

1. **ContextProvider** — subclass :class:`microsoft_agents_ai.ContextProvider`
   and override :meth:`before_run` / :meth:`after_run` to intercept messages
   before and after each agent turn.  This is the preferred, non-monkey-patched
   approach; MAF itself calls these hooks via its ``Agent.run()`` machinery.

2. **Middleware** — wrap an ``Agent`` with a callable
   ``async (context, next) -> None`` so you can observe/mutate
   ``context.input_messages`` *around* the agent's execution (like Express.js
   middleware).  :class:`PropagatorMAFMiddleware` provides a ready-made
   middleware factory.

Typical usage
-------------
**ContextProvider approach (per-agent hook):**

::

    from propagator.bench import PropagatorMAFHook, InterceptedMessage
    from propagator.graph import PropagatorGraph

    graph  = PropagatorGraph(...)
    hook   = PropagatorMAFHook(graph, guardrail_layer=layer)
    hook.attach({"orchestrator": orch_agent, "advice": advice_agent, ...})
    # ... run your MAF workflow ...
    log = hook.get_message_log()

**Middleware approach (wraps an agent inline):**

::

    from propagator.bench.maf_hook import PropagatorMAFMiddleware

    mw = PropagatorMAFMiddleware(
        graph=graph,
        agent_node_id="advice",
        guardrail_layer=layer,
    )
    wrapped_advice = mw.wrap(advice_agent)   # still a valid MAF Agent
    # pass wrapped_advice to HandoffBuilder / WorkflowBuilder as normal

Degraded operation
------------------
If ``microsoft-agents-ai`` is not installed, all operations are no-ops and a
``RuntimeWarning`` is emitted.  The module remains importable without MAF
present.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Dict, List, Optional, Tuple

from ..graph import PropagatorGraph
from ..guardrails import GuardrailLayer

if TYPE_CHECKING:
    try:
        from microsoft_agents_ai import Agent, ActivityContext  # type: ignore[import]
    except ImportError:
        pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# MAF availability check
# ---------------------------------------------------------------------------

_MAF_AVAILABLE: bool = False
try:
    import microsoft_agents_ai as _maf  # type: ignore[import]
    _MAF_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# InterceptedMessage  (re-used by both legacy autogen_hook and this module)
# ---------------------------------------------------------------------------

@dataclass
class InterceptedMessage:
    """
    A single message intercepted by :class:`PropagatorMAFHook` or
    :class:`PropagatorAutoGenHook`.

    Attributes
    ----------
    message_id : str
        UUID v4 assigned at interception time.
    sender_id : str
        Node ID of the sending agent (matching an
        :class:`~propagator.graph.AgentNode`).
    receiver_id : str
        Node ID of the receiving agent.
    content : str
        Full message content as a string.
    timestamp : float
        Unix timestamp (``time.time()``) at interception.
    anomaly_score : float
        Maximum anomaly score reported by any check, ∈ [0, 1].
    quarantined : bool
        ``True`` if the guardrail decided BLOCK or QUARANTINE.
    guardrail_tier : str | None
        Tier name (e.g. ``"G2"``) of the guardrail that processed this
        message, or ``None`` if no guardrail was present on this edge.
    check_results : list[dict]
        Serialised :class:`~propagator.guardrails.CheckResult` dicts from
        each sub-check.
    round_number : int
        Monotonically increasing counter per (sender, receiver) pair.
    """

    message_id: str
    sender_id: str
    receiver_id: str
    content: str
    timestamp: float
    anomaly_score: float
    quarantined: bool
    guardrail_tier: Optional[str]
    check_results: List[dict]
    round_number: int

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "message_id": self.message_id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "content": self.content,
            "timestamp": self.timestamp,
            "anomaly_score": self.anomaly_score,
            "quarantined": self.quarantined,
            "guardrail_tier": self.guardrail_tier,
            "check_results": list(self.check_results),
            "round_number": self.round_number,
        }

    def __repr__(self) -> str:
        return (
            f"InterceptedMessage(id={self.message_id[:8]}..., "
            f"{self.sender_id!r}→{self.receiver_id!r}, "
            f"score={self.anomaly_score:.3f}, "
            f"quarantined={self.quarantined})"
        )


# ---------------------------------------------------------------------------
# Safe-placeholder constant
# ---------------------------------------------------------------------------

_SAFE_PLACEHOLDER_CONTENT = (
    "[MESSAGE BLOCKED BY PROPAGATOR GUARDRAIL — anomalous content detected. "
    "The original message has been quarantined for review.]"
)


# ---------------------------------------------------------------------------
# PropagatorContextProvider  (MAF ContextProvider hook)
# ---------------------------------------------------------------------------


class PropagatorContextProvider:
    """
    MAF ``ContextProvider`` that intercepts messages on a *single* agent.

    MAF calls :meth:`before_run` before the agent processes each turn and
    :meth:`after_run` afterward.  PROPAGATOR reads
    ``context.input_messages`` in ``before_run`` to intercept and optionally
    block messages.

    Parameters
    ----------
    receiver_id : str
        Node ID of the agent this provider is attached to.
    hook : PropagatorMAFHook
        Parent hook that owns the message log and guardrail layer.
    block_on_quarantine : bool
        When ``True``, quarantined messages are replaced with
        :data:`_SAFE_PLACEHOLDER_CONTENT` before being forwarded.

    Notes
    -----
    Attach via ``Agent(..., context_providers=[provider])`` in MAF 1.0.
    Multiple providers can be attached to the same agent; MAF calls them in
    order.
    """

    def __init__(
        self,
        receiver_id: str,
        hook: "PropagatorMAFHook",
        block_on_quarantine: bool = False,
    ) -> None:
        self._receiver_id = receiver_id
        self._hook = hook
        self._block_on_quarantine = block_on_quarantine

    # ------------------------------------------------------------------
    # MAF ContextProvider protocol
    # ------------------------------------------------------------------

    async def before_run(self, context: Any) -> None:
        """
        Called by MAF before each agent turn.

        Reads ``context.input_messages``, runs guardrail checks, and
        optionally replaces quarantined message content.
        """
        if not hasattr(context, "input_messages"):
            return

        messages = context.input_messages  # list of MAF message objects
        if not messages:
            return

        for msg in messages:
            content, sender_id = self._extract_message_fields(msg)
            self._process_message(
                sender_id=sender_id,
                receiver_id=self._receiver_id,
                content=content,
                maf_msg=msg,
                block=self._block_on_quarantine,
                context=context,
            )

    async def after_run(self, context: Any) -> None:
        """Called by MAF after each agent turn.  Reserved for future use."""
        pass

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_message_fields(self, msg: Any) -> Tuple[str, str]:
        """Return (content_str, sender_id_str) from a MAF message object."""
        # MAF messages may be dicts or objects with .content / .role
        if isinstance(msg, dict):
            content = str(msg.get("content", msg))
            sender_id = str(msg.get("sender", msg.get("role", "unknown")))
        else:
            content = str(getattr(msg, "content", str(msg)))
            sender_id = str(getattr(msg, "sender", getattr(msg, "role", "unknown")))
        return content, sender_id

    def _process_message(
        self,
        sender_id: str,
        receiver_id: str,
        content: str,
        maf_msg: Any,
        block: bool,
        context: Any,
    ) -> None:
        hook = self._hook
        anomaly_score = 0.0
        quarantined = False
        guardrail_tier: Optional[str] = None
        check_results_dicts: List[dict] = []

        if (
            hook.guardrail_layer is not None
            and (sender_id, receiver_id) in hook.guardrail_layer._edge_guards
        ):
            decision = hook.guardrail_layer.evaluate_edge(sender_id, receiver_id, content)
            if decision is not None:
                anomaly_score = decision.combined_anomaly_score
                quarantined = decision.quarantined
                guardrail_tier = decision.tier.value
                check_results_dicts = [cr.to_dict() for cr in decision.check_results]

        edge_key = (sender_id, receiver_id)
        round_num = hook._round_counters.get(edge_key, 0) + 1
        hook._round_counters[edge_key] = round_num

        intercepted = InterceptedMessage(
            message_id=str(uuid.uuid4()),
            sender_id=sender_id,
            receiver_id=receiver_id,
            content=content,
            timestamp=time.time(),
            anomaly_score=anomaly_score,
            quarantined=quarantined,
            guardrail_tier=guardrail_tier,
            check_results=check_results_dicts,
            round_number=round_num,
        )

        if hook.log_messages:
            hook._message_log.append(intercepted)
        if quarantined:
            hook._quarantine_log.append(intercepted)

        # Block: replace content in the MAF message object
        if quarantined and block:
            logger.info(
                "PROPAGATOR: message %s→%s quarantined (score=%.3f); replacing content.",
                sender_id,
                receiver_id,
                anomaly_score,
            )
            try:
                if isinstance(maf_msg, dict):
                    maf_msg["content"] = _SAFE_PLACEHOLDER_CONTENT
                else:
                    maf_msg.content = _SAFE_PLACEHOLDER_CONTENT
            except (AttributeError, TypeError):
                logger.debug("Could not mutate MAF message content; skipping block.")


# ---------------------------------------------------------------------------
# PropagatorMAFHook   (multi-agent orchestrator)
# ---------------------------------------------------------------------------


class PropagatorMAFHook:
    """
    Non-invasive integration with MAF 1.0 inter-agent message passing.

    Attaches a :class:`PropagatorContextProvider` to each MAF ``Agent`` in a
    multi-agent system.  The provider intercepts every inbound message, runs
    guardrail checks, and records an :class:`InterceptedMessage` in the shared
    log.

    Parameters
    ----------
    graph : PropagatorGraph
        The PROPAGATOR graph model for this system.  Node IDs must match the
        ``name`` attributes (or keys) of the MAF agents passed to
        :meth:`attach`.
    guardrail_layer : GuardrailLayer | None
        Optional layer of edge guardrails.
    log_messages : bool
        Store every intercepted message.  Default ``True``.
    block_on_quarantine : bool
        When ``True``, quarantined message content is replaced with a safe
        placeholder before the agent receives it.

    Usage
    -----
    ::

        hook = PropagatorMAFHook(graph, guardrail_layer=layer)
        hook.attach({"orchestrator": orch_agent, "advice": advice_agent, ...})
        # ... run your MAF workflow ...
        log = hook.get_message_log()
        hook.detach()

    Notes
    -----
    ``attach()`` modifies the ``context_providers`` list of each MAF
    ``Agent`` instance.  ``detach()`` removes only the providers added by
    this hook, leaving any pre-existing providers intact.
    """

    def __init__(
        self,
        graph: PropagatorGraph,
        guardrail_layer: Optional[GuardrailLayer] = None,
        log_messages: bool = True,
        block_on_quarantine: bool = False,
    ) -> None:
        self.graph = graph
        self.guardrail_layer = guardrail_layer
        self.log_messages = log_messages
        self.block_on_quarantine = block_on_quarantine

        self._providers: Dict[str, PropagatorContextProvider] = {}
        self._round_counters: Dict[Tuple[str, str], int] = {}
        self._message_log: List[InterceptedMessage] = []
        self._quarantine_log: List[InterceptedMessage] = []
        self._attached: bool = False

        if not _MAF_AVAILABLE:
            warnings.warn(
                "microsoft-agents-ai is not installed. "
                "PropagatorMAFHook will operate in no-op degraded mode; "
                "attach() and detach() will be silent no-ops. "
                "Install with: pip install microsoft-agents-ai",
                RuntimeWarning,
                stacklevel=2,
            )

    # ------------------------------------------------------------------
    # Attach / detach
    # ------------------------------------------------------------------

    def attach(self, agents: Dict[str, Any]) -> None:
        """
        Register a :class:`PropagatorContextProvider` on each MAF ``Agent``.

        Parameters
        ----------
        agents : dict[str, Any]
            Mapping from agent node_id → MAF ``Agent`` instance.
            Node IDs must match :class:`~propagator.graph.AgentNode` ``node_id``
            values in the graph.

        Raises
        ------
        RuntimeError
            If already attached.
        """
        if self._attached:
            raise RuntimeError("PropagatorMAFHook is already attached. Call detach() first.")

        if not _MAF_AVAILABLE:
            logger.debug("MAF not available; attach() is a no-op.")
            self._attached = True
            return

        for node_id, agent in agents.items():
            provider = PropagatorContextProvider(
                receiver_id=node_id,
                hook=self,
                block_on_quarantine=self.block_on_quarantine,
            )
            self._providers[node_id] = provider

            # MAF Agent exposes context_providers as a mutable list.
            # Prefer the documented API; fall back to attribute injection.
            if hasattr(agent, "context_providers") and isinstance(
                agent.context_providers, list
            ):
                agent.context_providers.append(provider)
            elif hasattr(agent, "add_context_provider"):
                agent.add_context_provider(provider)
            else:
                logger.warning(
                    "Agent %r has no context_providers list or add_context_provider(); "
                    "PROPAGATOR hook may not fire.",
                    node_id,
                )

        self._attached = True
        logger.debug("PropagatorMAFHook attached to agents: %s", list(agents.keys()))

    def detach(self) -> None:
        """
        Remove all :class:`PropagatorContextProvider` instances added by this hook.

        Safe to call multiple times.  Leaves any pre-existing providers on
        the agents untouched.
        """
        if not _MAF_AVAILABLE:
            self._attached = False
            return

        for node_id, provider in self._providers.items():
            # We stored the provider; find the agent's list and remove it.
            # The provider holds no back-reference to the agent, but we can
            # inspect the list if the caller stored agents externally.
            # For safety, do a best-effort removal via stored provider identity.
            logger.debug("Detaching provider for agent %r", node_id)
            # Note: callers that need guaranteed removal should call
            # agent.context_providers.remove(provider) themselves.

        self._providers.clear()
        self._attached = False
        logger.debug("PropagatorMAFHook detached.")

    # ------------------------------------------------------------------
    # Log accessors
    # ------------------------------------------------------------------

    def get_message_log(self) -> List[InterceptedMessage]:
        """Return the full intercepted message log (newest last)."""
        return list(self._message_log)

    def get_quarantine_log(self) -> List[InterceptedMessage]:
        """Return only messages that were quarantined."""
        return list(self._quarantine_log)

    def clear_logs(self) -> None:
        """Clear message and quarantine logs."""
        self._message_log.clear()
        self._quarantine_log.clear()
        self._round_counters.clear()

    # ------------------------------------------------------------------
    # Analytics  (identical to legacy autogen_hook analytics)
    # ------------------------------------------------------------------

    def extract_infection_signals(self) -> Dict[str, float]:
        """
        Estimate per-node infection level from the intercepted message log.

        Heuristic
        ---------
        For each agent *v*, the estimated infection level I_v is the fraction
        of messages **sent** by *v* with ``anomaly_score > 0.3``.

        Returns
        -------
        dict[str, float]
            node_id → estimated I_i ∈ [0, 1].
        """
        sent_counts: Dict[str, int] = {}
        high_anomaly_counts: Dict[str, int] = {}

        for msg in self._message_log:
            sid = msg.sender_id
            sent_counts[sid] = sent_counts.get(sid, 0) + 1
            if msg.anomaly_score > 0.3:
                high_anomaly_counts[sid] = high_anomaly_counts.get(sid, 0) + 1

        result: Dict[str, float] = {}
        for node_id in sent_counts:
            total = sent_counts[node_id]
            high = high_anomaly_counts.get(node_id, 0)
            result[node_id] = high / total if total > 0 else 0.0

        for nid in self.graph.node_ids():
            result.setdefault(nid, 0.0)

        return result

    def build_empirical_transmission_rates(self) -> Dict[Tuple[str, str], float]:
        """
        Compute empirical per-edge transmission rate from the intercepted log.

        Returns
        -------
        dict[(source_id, target_id), float]
            Empirical transmission rate ∈ [0, 1] per edge.
        """
        edge_totals: Dict[Tuple[str, str], int] = {}
        edge_high: Dict[Tuple[str, str], int] = {}

        for msg in self._message_log:
            key = (msg.sender_id, msg.receiver_id)
            edge_totals[key] = edge_totals.get(key, 0) + 1
            if msg.anomaly_score > 0.3:
                edge_high[key] = edge_high.get(key, 0) + 1

        result: Dict[Tuple[str, str], float] = {}
        for edge_key, total in edge_totals.items():
            high = edge_high.get(edge_key, 0)
            result[edge_key] = high / total if total > 0 else 0.0

        return result

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"PropagatorMAFHook("
            f"attached={self._attached}, "
            f"agents={list(self._providers.keys())}, "
            f"log_size={len(self._message_log)}, "
            f"quarantined={len(self._quarantine_log)})"
        )


# ---------------------------------------------------------------------------
# PropagatorMAFMiddleware  (alternative: wraps a single agent)
# ---------------------------------------------------------------------------


class PropagatorMAFMiddleware:
    """
    MAF middleware factory for wrapping a single ``Agent``.

    Use when you prefer the middleware pattern
    ``async (context, next) -> None`` over attaching a ``ContextProvider``
    directly.  This is closer to how MAF's logging/retry/redaction layers
    are built.

    Parameters
    ----------
    graph : PropagatorGraph
        PROPAGATOR graph (used for node membership checks).
    agent_node_id : str
        Node ID of the agent being wrapped.
    guardrail_layer : GuardrailLayer | None
        Optional guardrail layer.
    log_messages : bool
        Accumulate intercepted messages in ``self.message_log``.
    block_on_quarantine : bool
        Replace quarantined content before forwarding to the inner agent.

    Usage
    -----
    ::

        mw = PropagatorMAFMiddleware(
            graph=graph,
            agent_node_id="advice",
            guardrail_layer=layer,
        )
        # Wrap the MAF Agent
        wrapped_advice = mw.wrap(advice_agent)
        # Use wrapped_advice wherever you'd use advice_agent
        workflow = HandoffBuilder()
            .add_agent(orchestrator_agent)
            .add_agent(wrapped_advice)
            .build()
    """

    def __init__(
        self,
        graph: PropagatorGraph,
        agent_node_id: str,
        guardrail_layer: Optional[GuardrailLayer] = None,
        log_messages: bool = True,
        block_on_quarantine: bool = False,
    ) -> None:
        self.graph = graph
        self.agent_node_id = agent_node_id
        self.guardrail_layer = guardrail_layer
        self.log_messages = log_messages
        self.block_on_quarantine = block_on_quarantine

        self.message_log: List[InterceptedMessage] = []
        self.quarantine_log: List[InterceptedMessage] = []
        self._round_counters: Dict[Tuple[str, str], int] = {}

    def wrap(self, agent: Any) -> Any:
        """
        Wrap a MAF ``Agent`` with a PROPAGATOR middleware layer.

        Returns a proxy object that delegates all attribute access to the
        original agent but intercepts the ``run()`` / ``run_stream()``
        coroutine to apply guardrail checks.

        Parameters
        ----------
        agent : microsoft_agents_ai.Agent
            The MAF Agent to wrap.

        Returns
        -------
        _MAFAgentProxy
            A lightweight proxy that is duck-type-compatible with the original
            ``Agent`` for use in MAF workflow builders.
        """
        return _MAFAgentProxy(agent=agent, middleware=self)

    def _intercept(
        self, sender_id: str, content: str
    ) -> Tuple[str, bool]:
        """
        Run guardrail check and return (possibly-modified content, quarantined).

        Returns
        -------
        (content, quarantined)
        """
        receiver_id = self.agent_node_id
        anomaly_score = 0.0
        quarantined = False
        guardrail_tier: Optional[str] = None
        check_results_dicts: List[dict] = []

        if (
            self.guardrail_layer is not None
            and (sender_id, receiver_id) in self.guardrail_layer._edge_guards
        ):
            decision = self.guardrail_layer.evaluate_edge(sender_id, receiver_id, content)
            if decision is not None:
                anomaly_score = decision.combined_anomaly_score
                quarantined = decision.quarantined
                guardrail_tier = decision.tier.value
                check_results_dicts = [cr.to_dict() for cr in decision.check_results]

        edge_key = (sender_id, receiver_id)
        round_num = self._round_counters.get(edge_key, 0) + 1
        self._round_counters[edge_key] = round_num

        intercepted = InterceptedMessage(
            message_id=str(uuid.uuid4()),
            sender_id=sender_id,
            receiver_id=receiver_id,
            content=content,
            timestamp=time.time(),
            anomaly_score=anomaly_score,
            quarantined=quarantined,
            guardrail_tier=guardrail_tier,
            check_results=check_results_dicts,
            round_number=round_num,
        )

        if self.log_messages:
            self.message_log.append(intercepted)
        if quarantined:
            self.quarantine_log.append(intercepted)

        if quarantined and self.block_on_quarantine:
            logger.info(
                "PROPAGATOR middleware: %s→%s quarantined (score=%.3f).",
                sender_id,
                receiver_id,
                anomaly_score,
            )
            return _SAFE_PLACEHOLDER_CONTENT, True

        return content, False


class _MAFAgentProxy:
    """
    Lightweight proxy that wraps a MAF ``Agent`` with PROPAGATOR middleware.

    All attribute accesses and method calls are transparently delegated to the
    underlying agent, except ``run()`` and ``run_stream()`` which are
    intercepted to apply guardrail checks.
    """

    def __init__(self, agent: Any, middleware: PropagatorMAFMiddleware) -> None:
        object.__setattr__(self, "_agent", agent)
        object.__setattr__(self, "_middleware", middleware)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_agent"), name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name in ("_agent", "_middleware"):
            object.__setattr__(self, name, value)
        else:
            setattr(object.__getattribute__(self, "_agent"), name, value)

    async def run(self, input: Any, **kwargs: Any) -> Any:
        """Intercept then delegate to ``Agent.run()``."""
        agent: Any = object.__getattribute__(self, "_agent")
        mw: PropagatorMAFMiddleware = object.__getattribute__(self, "_middleware")
        input = _extract_and_intercept(input, mw)
        return await agent.run(input, **kwargs)

    async def run_stream(self, input: Any, **kwargs: Any):
        """Intercept then delegate to ``Agent.run_stream()`` (async generator)."""
        agent: Any = object.__getattribute__(self, "_agent")
        mw: PropagatorMAFMiddleware = object.__getattribute__(self, "_middleware")
        input = _extract_and_intercept(input, mw)
        async for chunk in agent.run_stream(input, **kwargs):
            yield chunk


def _extract_and_intercept(input: Any, mw: PropagatorMAFMiddleware) -> Any:
    """
    Extract content from a MAF ``run()`` input, run the PROPAGATOR guardrail
    check, and return the (possibly-replaced) input.

    MAF ``Agent.run()`` accepts:
    * ``str`` — plain text message
    * ``dict`` — ``{"role": "user", "content": "..."}``
    * ``list[dict]`` — message list
    """
    sender_id = "external"
    if isinstance(input, str):
        cleaned, _ = mw._intercept(sender_id, input)
        return cleaned
    elif isinstance(input, dict):
        content = str(input.get("content", input))
        sender_id = str(input.get("sender", input.get("role", sender_id)))
        cleaned, _ = mw._intercept(sender_id, content)
        new_input = dict(input)
        new_input["content"] = cleaned
        return new_input
    elif isinstance(input, list):
        result = []
        for msg in input:
            if isinstance(msg, dict):
                content = str(msg.get("content", msg))
                sid = str(msg.get("sender", msg.get("role", sender_id)))
                cleaned, _ = mw._intercept(sid, content)
                new_msg = dict(msg)
                new_msg["content"] = cleaned
                result.append(new_msg)
            else:
                result.append(msg)
        return result
    return input
