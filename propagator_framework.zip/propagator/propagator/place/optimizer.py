"""
propagator.place.optimizer
===========================
Budget-constrained, importance-weighted, imperfect-guard placement optimizer.

Problem statement
-----------------
Given:
  - A directed agent communication graph G = (V, E, μ, β)
  - A total budget B
  - Guard costs c(e) per edge
  - Guard miss rates m(e) per edge (imperfect guards multiply β_e by m_e)
  - Utility costs U(e) = FPR_e × legitimate_traffic_e

Objective:
  Minimise F(S) = Σ_i μ_i · π_i(S)   subject to:
      Σ_{e∈S} c(e) ≤ B
      Σ_{e∈S} U(e) ≤ utility_budget

where π_i(S) is the steady-state infection probability of node i under guard
set S (computed via :func:`~propagator.metrics.compute_blast_radius`).

Methods implemented
-------------------
* ``guard_everything``      — upper bound baseline: guard every edge
* ``guard_nothing``         — lower bound baseline: guard no edges
* ``random``                — random selection up to budget
* ``degree_centrality``     — guard highest in-degree target edges first
* ``min_vertex_cut``        — guard edges incident to min-vertex-cut nodes
* ``provenance_heuristic``  — block all paths from entry-point to high-importance nodes
* ``greedy_submodular``     — greedy marginal-gain / cost ratio (primary method)

Safeguards JSON output
----------------------
Every :class:`PlacementResult` has a ``safeguards_json`` field ready for
direct use as DocTalk's ``safeguards.json``::

    {
        "inter_agent_safeguards": {
            "agent_transitions": [
                {
                    "message_source": "advice",
                    "message_destination": "orchestrator",
                    "check_method": "llm",
                    "action": "block",
                    "tier": "G2"
                }
            ]
        }
    }
"""

from __future__ import annotations

import logging
import random as _random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple

import networkx as nx

from ..graph import PropagatorGraph
from ..guardrails import GuardrailTier, EdgeGuardrail, GuardrailLayer
from ..guardrails.guardrail import GuardrailConfig

logger = logging.getLogger(__name__)



# ---------------------------------------------------------------------------
# Local BlastRadiusResult and helpers
# (defined here to avoid circular imports with propagator.metrics)
# ---------------------------------------------------------------------------


@dataclass
class BlastRadiusResult:
    """
    Result of a placement blast-radius computation.

    F(S) = Sigma_i mu_i * pi_i(S), where pi_i is the steady-state infection
    probability of node i under guard set S.
    """

    blast_radius: float
    guard_set: Set
    node_risk: Dict[str, float]
    total_importance: float
    normalised: float = 0.0

    def to_dict(self) -> dict:
        return {
            "blast_radius": self.blast_radius,
            "guard_set": [list(e) for e in self.guard_set],
            "node_risk": dict(self.node_risk),
            "total_importance": self.total_importance,
            "normalised": self.normalised,
        }


def _compute_blast_radius(
    graph: PropagatorGraph,
    guard_set: Set[Tuple[str, str]],
    attack_type: str = "prompt_injection",
    miss_rates: Optional[Dict[Tuple[str, str], float]] = None,
    entry_point_infection: float = 1.0,
    n_steps: int = 20,
) -> BlastRadiusResult:
    """
    Compute expected blast radius F(S) for a given guard set.

    Runs a deterministic SIR-style propagation, attenuating each guarded
    edge transmission probability by its miss rate.
    """
    import numpy as np

    node_ids = graph.node_ids()
    if not node_ids:
        return BlastRadiusResult(
            blast_radius=0.0,
            guard_set=set(guard_set),
            node_risk={},
            total_importance=0.0,
            normalised=0.0,
        )

    n = len(node_ids)
    idx = {nid: i for i, nid in enumerate(node_ids)}
    default_miss_rate = 0.15  # G2 default

    # W[i, j] = prob j infects i
    W = np.zeros((n, n), dtype=float)
    for (src, tgt), edge in graph._edges.items():
        i, j = idx.get(src), idx.get(tgt)
        if i is None or j is None:
            continue
        try:
            base_p = graph.transmission_probability(src, tgt, attack_type)
        except Exception:
            base_p = edge.weight * 0.3

        if (src, tgt) in guard_set:
            mr = (
                miss_rates.get((src, tgt), default_miss_rate)
                if miss_rates else default_miss_rate
            )
            W[i, j] = base_p * mr
        else:
            W[i, j] = base_p

    I = np.zeros(n, dtype=float)
    for nid in node_ids:
        node = graph._nodes[nid]
        if node.is_entry_point:
            I[idx[nid]] = entry_point_infection

    beta = 0.3
    gamma = 0.0

    for _ in range(n_steps):
        dI = np.zeros(n, dtype=float)
        for i in range(n):
            incoming = float(np.dot(W[i, :], I) * (1.0 - I[i]))
            dI[i] = beta * incoming - gamma * I[i]
        I = np.clip(I + dI, 0.0, 1.0)

    importances = np.array(
        [graph._nodes[nid].importance for nid in node_ids], dtype=float
    )
    node_risk = {nid: float(I[idx[nid]]) for nid in node_ids}
    total_importance = float(importances.sum())
    blast_radius = float(np.dot(importances, I))
    normalised = blast_radius / total_importance if total_importance > 0 else 0.0

    return BlastRadiusResult(
        blast_radius=blast_radius,
        guard_set=set(guard_set),
        node_risk=node_risk,
        total_importance=total_importance,
        normalised=normalised,
    )


def _compute_structural_indices(
    graph: PropagatorGraph,
    attack_type: str = "prompt_injection",
) -> Dict[str, Dict[str, float]]:
    """
    Compute per-node structural risk indices.

    Returns dict[node_id, dict[index_name, value]] with keys:
    betweenness, in_degree, out_degree, pagerank, resistance,
    importance, structural_risk, reachability.
    """
    G = graph._graph
    node_ids = graph.node_ids()
    n = len(node_ids)

    if n == 0:
        return {}

    try:
        betweenness = nx.betweenness_centrality(G, normalized=True)
    except Exception:
        betweenness = {nid: 0.0 for nid in node_ids}

    try:
        pagerank = nx.pagerank(G, alpha=0.85, max_iter=500)
    except Exception:
        pagerank = {nid: 1.0 / n for nid in node_ids}

    in_degrees = dict(G.in_degree())
    out_degrees = dict(G.out_degree())
    denom = max(1, n - 1)

    result: Dict[str, Dict[str, float]] = {}
    for nid in node_ids:
        node = graph._nodes[nid]
        resistance = graph.get_resistance_score(nid, attack_type)
        importance = node.importance
        pr = pagerank.get(nid, 0.0)
        bt = betweenness.get(nid, 0.0)

        try:
            reachable = len(nx.descendants(G, nid)) / denom
        except Exception:
            reachable = 0.0

        structural_risk = importance * (1.0 - resistance) * (pr + bt) / 2.0

        result[nid] = {
            "betweenness": float(bt),
            "in_degree": float(in_degrees.get(nid, 0)) / denom,
            "out_degree": float(out_degrees.get(nid, 0)) / denom,
            "pagerank": float(pr),
            "resistance": float(resistance),
            "importance": float(importance),
            "structural_risk": float(structural_risk),
            "reachability": float(reachable),
        }

    return result



# ---------------------------------------------------------------------------
# PlacementMethod
# ---------------------------------------------------------------------------


class PlacementMethod(str, Enum):
    """Enumeration of supported guard placement strategies."""

    GUARD_EVERYTHING = "guard_everything"
    """Upper bound: guard every edge in the graph."""

    GUARD_NOTHING = "guard_nothing"
    """Lower bound: guard no edges (baseline)."""

    RANDOM = "random"
    """Random selection of edges up to budget."""

    DEGREE_CENTRALITY = "degree_centrality"
    """Guard edges whose target node has the highest in-degree."""

    MIN_VERTEX_CUT = "min_vertex_cut"
    """Guard edges incident to nodes in the minimum vertex cut."""

    PROVENANCE_HEURISTIC = "provenance_heuristic"
    """Block the first edge of every path from an entry point to a high-importance node."""

    GREEDY_SUBMODULAR = "greedy_submodular"
    """
    Greedy submodular approximation (primary method).
    Iteratively add the edge with the highest marginal blast-radius
    reduction per unit cost until the budget or utility cap is reached.
    """

    ILP_EXACT = "ilp_exact"
    """Exact ILP solver (small graphs only; not included in run_all_baselines)."""


# ---------------------------------------------------------------------------
# PlacementResult
# ---------------------------------------------------------------------------


@dataclass
class PlacementResult:
    """
    Result of a guard placement optimisation.

    Attributes
    ----------
    method : PlacementMethod
        The method that produced this result.
    guard_set : set[tuple[str, str]]
        Set of (source_id, target_id) edge tuples that have guards placed.
    budget_used : float
        Total cost Σ_{e∈S} c(e) consumed.
    blast_radius : float
        Weighted expected damage F(S) = Σ_i μ_i · π_i(S).
    blast_radius_reduction : float
        Reduction relative to the ``guard_nothing`` baseline:
        (F(∅) - F(S)) / F(∅) · 100 %.
    utility_loss : float
        Estimated utility loss Σ_{e∈S} U(e).
    safeguards_json : dict
        Ready-to-deploy ``safeguards.json`` config for DocTalk.
    """

    method: PlacementMethod
    guard_set: Set[Tuple[str, str]]
    budget_used: float
    blast_radius: float
    blast_radius_reduction: float  # as fraction, e.g. 0.45 = 45% reduction
    utility_loss: float
    safeguards_json: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "method": self.method.value,
            "guard_set": [list(e) for e in self.guard_set],
            "budget_used": self.budget_used,
            "blast_radius": self.blast_radius,
            "blast_radius_reduction": self.blast_radius_reduction,
            "utility_loss": self.utility_loss,
            "safeguards_json": self.safeguards_json,
            "metadata": dict(self.metadata),
        }

    def __repr__(self) -> str:
        return (
            f"PlacementResult(method={self.method.value!r}, "
            f"guards={len(self.guard_set)}, "
            f"blast={self.blast_radius:.4f}, "
            f"reduction={self.blast_radius_reduction:.2%})"
        )


# ---------------------------------------------------------------------------
# GuardPlacementOptimizer
# ---------------------------------------------------------------------------


class GuardPlacementOptimizer:
    """
    Budget-constrained, importance-weighted, imperfect-guard placement optimizer.

    Objective
    ---------
    Minimise F(S) = Σ_i μ_i · π_i(S)

    Subject to:
        Σ_{e∈S} cost(e) ≤ B
        Σ_{e∈S} utility_cost(e) ≤ utility_budget_fraction · Σ_e utility_cost(e)

    Guards are **imperfect**: placing a guard on edge e multiplies its
    transmission probability β_e by the tier's miss rate m_e ∈ (0, 1].

    Parameters
    ----------
    graph : PropagatorGraph
        The agent communication graph.
    budget : float
        Total deployment budget B.
    guard_tier : GuardrailTier
        Tier used for all placed guards (default G2).
    edge_costs : dict[(str,str), float] | None
        Per-edge deployment costs.  Defaults to 1.0 for all edges.
    edge_utility_costs : dict[(str,str), float] | None
        Per-edge utility cost (FPR × legitimate traffic).
        Defaults to 0.05 for all edges.
    utility_budget_fraction : float
        Maximum acceptable fraction of total utility cost (default 0.05 = 5%).
    attack_type : str
        Attack type label for resistance score lookups (default
        ``"prompt_injection"``).
    """

    def __init__(
        self,
        graph: PropagatorGraph,
        budget: float,
        guard_tier: GuardrailTier = GuardrailTier.G2,
        edge_costs: Optional[Dict[Tuple[str, str], float]] = None,
        edge_utility_costs: Optional[Dict[Tuple[str, str], float]] = None,
        utility_budget_fraction: float = 0.05,
        attack_type: str = "prompt_injection",
    ) -> None:
        self.graph = graph
        self.budget = budget
        self.guard_tier = guard_tier
        self.attack_type = attack_type
        self.utility_budget_fraction = utility_budget_fraction

        all_edges: List[Tuple[str, str]] = graph.edge_list()

        # Normalise costs
        self._edge_costs: Dict[Tuple[str, str], float] = {
            e: float(edge_costs[e]) if edge_costs and e in edge_costs else 1.0
            for e in all_edges
        }
        self._edge_utility_costs: Dict[Tuple[str, str], float] = {
            e: float(edge_utility_costs[e]) if edge_utility_costs and e in edge_utility_costs else 0.05
            for e in all_edges
        }

        self._total_utility = sum(self._edge_utility_costs.values())
        # Apply utility cap only when explicit utility costs were provided.
        # With default uniform costs the cap is set to inf so the budget
        # constraint (not utility) is the binding constraint.
        if edge_utility_costs is not None:
            self._utility_cap = (
                utility_budget_fraction * self._total_utility
                if self._total_utility > 0 else float("inf")
            )
        else:
            self._utility_cap = float("inf")

        # Miss rates from the chosen tier (via GuardrailConfig)
        _tier_miss_rate = GuardrailConfig.from_tier(guard_tier).miss_rate
        self._miss_rates: Dict[Tuple[str, str], float] = {
            e: _tier_miss_rate for e in all_edges
        }

        # Cache baseline blast radius (no guards)
        self._baseline_br: Optional[BlastRadiusResult] = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _blast_radius(self, guard_set: Set[Tuple[str, str]]) -> float:
        """Compute blast radius for *guard_set*."""
        result = _compute_blast_radius(
            graph=self.graph,
            guard_set=guard_set,
            attack_type=self.attack_type,
            miss_rates=self._miss_rates,
        )
        return result.blast_radius

    def _baseline_blast_radius(self) -> float:
        """Cached blast radius for the guard-nothing baseline."""
        if self._baseline_br is None:
            self._baseline_br = _compute_blast_radius(
                graph=self.graph,
                guard_set=set(),
                attack_type=self.attack_type,
                miss_rates=self._miss_rates,
            )
        return self._baseline_br.blast_radius

    def _compute_marginal_gain(
        self,
        current_set: Set[Tuple[str, str]],
        candidate_edge: Tuple[str, str],
    ) -> float:
        """
        Marginal blast-radius reduction from adding *candidate_edge* to *current_set*.

        Returns
        -------
        float
            ΔF = F(S) - F(S ∪ {e}) ≥ 0.  A larger value is better.
        """
        current_br = self._blast_radius(current_set)
        new_set = current_set | {candidate_edge}
        new_br = self._blast_radius(new_set)
        return max(0.0, current_br - new_br)

    def _build_result(
        self,
        method: PlacementMethod,
        guard_set: Set[Tuple[str, str]],
        baseline_br: Optional[float] = None,
    ) -> PlacementResult:
        """Construct a :class:`PlacementResult` from a guard set."""
        if baseline_br is None:
            baseline_br = self._baseline_blast_radius()

        br = self._blast_radius(guard_set)
        budget_used = sum(self._edge_costs.get(e, 1.0) for e in guard_set)
        utility_loss = sum(self._edge_utility_costs.get(e, 0.05) for e in guard_set)

        if baseline_br > 0.0:
            reduction = max(0.0, (baseline_br - br) / baseline_br)
        else:
            reduction = 0.0

        safeguards_json = self._build_safeguards_json(guard_set)

        return PlacementResult(
            method=method,
            guard_set=set(guard_set),
            budget_used=budget_used,
            blast_radius=br,
            blast_radius_reduction=reduction,
            utility_loss=utility_loss,
            safeguards_json=safeguards_json,
        )

    def _build_safeguards_json(
        self, guard_set: Set[Tuple[str, str]]
    ) -> dict:
        """Generate DocTalk-compatible ``safeguards.json`` for *guard_set*."""
        transitions = []
        for source_id, target_id in sorted(guard_set):
            transitions.append({
                "message_source": source_id,
                "message_destination": target_id,
                "check_method": "llm",
                "action": "block",
                "tier": self.guard_tier.value,
            })
        return {
            "inter_agent_safeguards": {
                "agent_transitions": transitions,
            }
        }

    def _is_within_utility_budget(
        self, guard_set: Set[Tuple[str, str]]
    ) -> bool:
        """Return True if the guard set respects the utility cap."""
        utility = sum(self._edge_utility_costs.get(e, 0.05) for e in guard_set)
        return utility <= self._utility_cap

    # ------------------------------------------------------------------
    # Optimisation methods
    # ------------------------------------------------------------------

    def optimize_guard_nothing(self) -> PlacementResult:
        """
        Lower-bound baseline: guard no edges.

        Returns a :class:`PlacementResult` with an empty guard set.
        """
        return self._build_result(PlacementMethod.GUARD_NOTHING, set())

    def optimize_guard_everything(self) -> PlacementResult:
        """
        Upper-bound baseline: guard every edge in the graph.

        Ignores the budget constraint (reports actual cost).
        """
        all_edges = set(self.graph.edge_list())
        return self._build_result(PlacementMethod.GUARD_EVERYTHING, all_edges)

    def optimize_random(self, seed: Optional[int] = None) -> PlacementResult:
        """
        Random guard placement up to budget.

        Shuffles all edges and greedily adds them (by random order) until the
        budget is exhausted or all edges are covered.

        Parameters
        ----------
        seed : int | None
            Optional random seed for reproducibility.
        """
        rng = _random.Random(seed)
        all_edges = list(self.graph.edge_list())
        rng.shuffle(all_edges)

        guard_set: Set[Tuple[str, str]] = set()
        cost_used = 0.0

        for edge in all_edges:
            cost = self._edge_costs.get(edge, 1.0)
            if cost_used + cost <= self.budget:
                trial_set = guard_set | {edge}
                if self._is_within_utility_budget(trial_set):
                    guard_set.add(edge)
                    cost_used += cost

        return self._build_result(PlacementMethod.RANDOM, guard_set)

    def optimize_degree_centrality(self) -> PlacementResult:
        """
        Guard edges by decreasing in-degree of their target node.

        Edges targeting high-in-degree nodes are guarded first (they see more
        message traffic and represent higher blast-radius reduction potential).
        """
        in_degrees: Dict[str, int] = {}
        for nid in self.graph.node_ids():
            in_degrees[nid] = len(self.graph.get_predecessors(nid))

        # Sort edges by in-degree of target node (descending), then by cost (ascending)
        all_edges = list(self.graph.edge_list())
        all_edges.sort(key=lambda e: (-in_degrees.get(e[1], 0), self._edge_costs.get(e, 1.0)))

        guard_set: Set[Tuple[str, str]] = set()
        cost_used = 0.0

        for edge in all_edges:
            cost = self._edge_costs.get(edge, 1.0)
            if cost_used + cost <= self.budget:
                trial_set = guard_set | {edge}
                if self._is_within_utility_budget(trial_set):
                    guard_set.add(edge)
                    cost_used += cost

        return self._build_result(PlacementMethod.DEGREE_CENTRALITY, guard_set)

    def optimize_min_vertex_cut(self) -> PlacementResult:
        """
        Guard edges incident to minimum vertex-cut nodes.

        Uses NetworkX to find all minimum vertex cuts between entry-point
        nodes (sources) and high-importance nodes (sinks).  Edges leading
        *into* cut nodes are guarded first.

        Falls back to degree-centrality ordering if no entry point / sink pair
        can be identified.
        """
        G = self.graph._graph

        # Identify sources (entry points) and sinks (high-importance)
        sources = [
            nid for nid in self.graph.node_ids()
            if self.graph._nodes[nid].is_entry_point
        ]
        sinks = [
            nid for nid in self.graph.node_ids()
            if self.graph._nodes[nid].importance >= float(3)  # CODE_EXECUTION+
        ]

        cut_nodes: Set[str] = set()

        if sources and sinks:
            for src in sources:
                for snk in sinks:
                    if src == snk:
                        continue
                    try:
                        # NetworkX minimum node cut
                        cut = nx.minimum_node_cut(G, src, snk)
                        cut_nodes.update(cut)
                    except (nx.NetworkXError, nx.exception.NodeNotFound):
                        pass

        if not cut_nodes:
            # Fallback: use in-degree ordering
            logger.debug(
                "min_vertex_cut: no valid source/sink pairs found; "
                "falling back to degree_centrality order."
            )
            return self.optimize_degree_centrality()

        # Collect edges whose target is a cut node, sorted by cost
        candidate_edges = [
            e for e in self.graph.edge_list() if e[1] in cut_nodes
        ]
        candidate_edges.sort(key=lambda e: self._edge_costs.get(e, 1.0))

        # Supplement with remaining edges (by in-degree) if budget allows
        remaining = [e for e in self.graph.edge_list() if e not in candidate_edges]
        in_degrees = {nid: len(self.graph.get_predecessors(nid)) for nid in self.graph.node_ids()}
        remaining.sort(key=lambda e: (-in_degrees.get(e[1], 0), self._edge_costs.get(e, 1.0)))

        ordered_edges = candidate_edges + remaining

        guard_set: Set[Tuple[str, str]] = set()
        cost_used = 0.0

        for edge in ordered_edges:
            cost = self._edge_costs.get(edge, 1.0)
            if cost_used + cost <= self.budget:
                trial_set = guard_set | {edge}
                if self._is_within_utility_budget(trial_set):
                    guard_set.add(edge)
                    cost_used += cost

        result = self._build_result(PlacementMethod.MIN_VERTEX_CUT, guard_set)
        result.metadata["cut_nodes"] = sorted(cut_nodes)
        return result

    def optimize_provenance_heuristic(self) -> PlacementResult:
        """
        Provenance heuristic: block the first edge of every path from an
        entry-point node to a high-importance (μ ≥ 3) node.

        Rationale: "Never let untrusted-tainted data reach a dangerous tool."
        The *first* edge is the choke point closest to the source, minimising
        disruption to the rest of the pipeline.

        If the budget is insufficient to guard all first-edges, they are
        prioritised by the importance of the downstream sink (descending).
        """
        G = self.graph._graph

        entry_points = [
            nid for nid in self.graph.node_ids()
            if self.graph._nodes[nid].is_entry_point
        ]
        high_importance_nodes = [
            nid for nid in self.graph.node_ids()
            if self.graph._nodes[nid].importance >= 3.0
        ]

        # Collect candidate first-edges (entry_point → first hop toward danger)
        first_edges: Dict[Tuple[str, str], float] = {}  # edge → max sink importance

        for ep in entry_points:
            for hi in high_importance_nodes:
                if ep == hi:
                    continue
                try:
                    paths = list(nx.all_simple_paths(G, ep, hi, cutoff=6))
                except (nx.NetworkXError, nx.NodeNotFound):
                    paths = []
                for path in paths:
                    if len(path) < 2:
                        continue
                    first_edge = (path[0], path[1])
                    sink_importance = self.graph._nodes[hi].importance
                    existing = first_edges.get(first_edge, 0.0)
                    first_edges[first_edge] = max(existing, sink_importance)

        if not first_edges:
            # No paths found — fallback to degree centrality
            logger.debug(
                "provenance_heuristic: no entry→high-importance paths found; "
                "falling back to degree_centrality."
            )
            result = self.optimize_degree_centrality()
            result.method = PlacementMethod.PROVENANCE_HEURISTIC
            return result

        # Sort by sink importance (descending), then cost (ascending)
        ordered = sorted(
            first_edges.items(),
            key=lambda item: (-item[1], self._edge_costs.get(item[0], 1.0)),
        )

        guard_set: Set[Tuple[str, str]] = set()
        cost_used = 0.0

        for edge, _imp in ordered:
            if edge not in self.graph.edge_list():
                continue
            cost = self._edge_costs.get(edge, 1.0)
            if cost_used + cost <= self.budget:
                trial_set = guard_set | {edge}
                if self._is_within_utility_budget(trial_set):
                    guard_set.add(edge)
                    cost_used += cost

        result = self._build_result(PlacementMethod.PROVENANCE_HEURISTIC, guard_set)
        result.metadata["first_edges_considered"] = len(first_edges)
        return result

    def optimize_greedy(self) -> PlacementResult:
        """
        Greedy submodular approximation (primary method).

        At each iteration, compute the marginal blast-radius reduction per
        unit cost (ΔF / c_e) for every remaining candidate edge.  Add the
        edge with the highest ratio until the budget or utility cap is hit.

        Provides a (1 - 1/e) ≈ 0.63 approximation guarantee if the objective
        is submodular and monotone.

        Notes
        -----
        For graphs with strong cycles the objective may not be perfectly
        submodular; the greedy heuristic is still a strong practical baseline.

        Returns
        -------
        PlacementResult
        """
        all_edges = list(self.graph.edge_list())
        baseline_br = self._baseline_blast_radius()

        if baseline_br == 0.0:
            # Nothing to protect
            return self._build_result(PlacementMethod.GREEDY_SUBMODULAR, set(), baseline_br)

        guard_set: Set[Tuple[str, str]] = set()
        remaining: Set[Tuple[str, str]] = set(all_edges)
        cost_used = 0.0

        while remaining:
            # Find the edge with the highest marginal gain per unit cost
            best_edge: Optional[Tuple[str, str]] = None
            best_ratio = -1.0

            for edge in list(remaining):
                cost = self._edge_costs.get(edge, 1.0)
                if cost_used + cost > self.budget:
                    # Would exceed budget — skip but keep in remaining for
                    # potential smaller-cost edges
                    continue
                trial_set = guard_set | {edge}
                if not self._is_within_utility_budget(trial_set):
                    continue
                gain = self._compute_marginal_gain(guard_set, edge)
                ratio = gain / cost if cost > 0 else gain
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_edge = edge

            if best_edge is None:
                # No feasible edge can be added
                break

            guard_set.add(best_edge)
            remaining.discard(best_edge)
            cost_used += self._edge_costs.get(best_edge, 1.0)

            logger.debug(
                "Greedy: added %s (ratio=%.4f, cost_used=%.1f/%.1f)",
                best_edge,
                best_ratio,
                cost_used,
                self.budget,
            )

        return self._build_result(
            PlacementMethod.GREEDY_SUBMODULAR, guard_set, baseline_br
        )

    # ------------------------------------------------------------------
    # Batch and analysis methods
    # ------------------------------------------------------------------

    def run_all_baselines(self) -> Dict[PlacementMethod, PlacementResult]:
        """
        Run all placement methods except :attr:`PlacementMethod.ILP_EXACT`.

        Returns
        -------
        dict[PlacementMethod, PlacementResult]
        """
        results: Dict[PlacementMethod, PlacementResult] = {}
        baseline_br = self._baseline_blast_radius()

        methods = [
            (PlacementMethod.GUARD_NOTHING, self.optimize_guard_nothing),
            (PlacementMethod.GUARD_EVERYTHING, self.optimize_guard_everything),
            (PlacementMethod.RANDOM, lambda: self.optimize_random(seed=42)),
            (PlacementMethod.DEGREE_CENTRALITY, self.optimize_degree_centrality),
            (PlacementMethod.MIN_VERTEX_CUT, self.optimize_min_vertex_cut),
            (PlacementMethod.PROVENANCE_HEURISTIC, self.optimize_provenance_heuristic),
            (PlacementMethod.GREEDY_SUBMODULAR, self.optimize_greedy),
        ]

        for method, fn in methods:
            try:
                results[method] = fn()
                logger.debug(
                    "run_all_baselines: %s → blast=%.4f, reduction=%.2%%",
                    method.value,
                    results[method].blast_radius,
                    results[method].blast_radius_reduction * 100,
                )
            except Exception as exc:
                logger.error("run_all_baselines: %s raised %r", method.value, exc)

        return results

    def compute_optimality_gap(
        self,
        greedy_result: PlacementResult,
        exact_result: Optional[PlacementResult] = None,
    ) -> float:
        """
        Estimate the optimality gap of the greedy solution.

        If *exact_result* is provided:
            gap = (F(S_greedy) - F(S_exact)) / F(S_exact)

        If not provided (large graph), estimate via sampling:
            Sample 200 random guard sets of the same size as the greedy set
            and use the best as a proxy for the optimum.

        Parameters
        ----------
        greedy_result : PlacementResult
            The greedy optimisation result.
        exact_result : PlacementResult | None
            Optional exact ILP result.

        Returns
        -------
        float
            Optimality gap ∈ [0, 1].  0 = greedy is optimal.
        """
        if exact_result is not None:
            denom = exact_result.blast_radius
            if denom == 0.0:
                return 0.0
            gap = (greedy_result.blast_radius - denom) / denom
            return max(0.0, float(gap))

        # Sampling estimate
        k = len(greedy_result.guard_set)
        if k == 0:
            return 0.0

        all_edges = self.graph.edge_list()
        if k >= len(all_edges):
            return 0.0

        rng = _random.Random(2025)
        best_br = greedy_result.blast_radius

        for _ in range(200):
            sample = set(rng.sample(all_edges, k))
            br = self._blast_radius(sample)
            if br < best_br:
                best_br = br

        denom = best_br if best_br > 0 else greedy_result.blast_radius
        if denom == 0.0:
            return 0.0
        gap = (greedy_result.blast_radius - best_br) / denom
        return max(0.0, float(gap))

    def security_utility_curve(
        self,
        budget_steps: int = 10,
    ) -> List[dict]:
        """
        Sweep the budget from 0 to the maximum (cost of all edges) and
        compute (blast_radius_reduction, utility_loss) for the greedy method
        at each budget level.

        Parameters
        ----------
        budget_steps : int
            Number of evenly-spaced budget levels to evaluate (default 10).

        Returns
        -------
        list[dict]
            List of dicts, each with keys:
            ``budget``, ``blast_radius``, ``blast_radius_reduction``,
            ``utility_loss``, ``n_guards``.
        """
        total_cost = sum(self._edge_costs.values())
        if total_cost == 0 or budget_steps < 1:
            return []

        step_size = total_cost / budget_steps
        curve: List[dict] = []

        saved_budget = self.budget

        for i in range(budget_steps + 1):
            test_budget = i * step_size
            self.budget = test_budget
            result = self.optimize_greedy()
            curve.append({
                "budget": test_budget,
                "blast_radius": result.blast_radius,
                "blast_radius_reduction": result.blast_radius_reduction,
                "utility_loss": result.utility_loss,
                "n_guards": len(result.guard_set),
            })

        self.budget = saved_budget
        return curve


# ---------------------------------------------------------------------------
# predict_placement_from_structural (cheap predictor)
# ---------------------------------------------------------------------------


def predict_placement_from_structural(
    graph: PropagatorGraph,
    budget: int,
    tier: GuardrailTier = GuardrailTier.G2,
) -> Set[Tuple[str, str]]:
    """
    Cheap predictor that estimates the near-optimal guard placement using
    only single-agent structural indices (no multi-agent simulation runs).

    Algorithm
    ---------
    1. Compute per-node structural risk indices via
       :func:`~propagator.metrics.compute_structural_indices`.
    2. For each directed edge (u → v), compute an *edge priority score*:

       .. code-block:: none

           priority(u, v) = structural_risk(u) × (1 - resistance(v)) × importance(v) × w(u,v)

    3. Sort edges by priority (descending).
    4. Greedily pick edges (cost 1.0 each) until *budget* is reached.

    The predictor runs in O(n + m) time and is suitable as a fast pre-filter
    before the full greedy optimiser.

    Parameters
    ----------
    graph : PropagatorGraph
        The agent communication graph.
    budget : int
        Maximum number of edges to guard (each costs 1.0).
    tier : GuardrailTier
        Tier for the guardrails (affects miss-rate interpretation).

    Returns
    -------
    set[tuple[str, str]]
        Predicted guard set (source_id, target_id) pairs.
    """
    indices = _compute_structural_indices(graph)

    edge_scores: List[Tuple[float, Tuple[str, str]]] = []

    for (src, tgt), edge in graph._edges.items():
        src_risk = indices.get(src, {}).get("structural_risk", 0.0)
        tgt_resistance = indices.get(tgt, {}).get("resistance", 1.0)
        tgt_importance = indices.get(tgt, {}).get("importance", 1.0)
        weight = edge.weight

        priority = src_risk * (1.0 - tgt_resistance) * tgt_importance * weight
        edge_scores.append((priority, (src, tgt)))

    # Sort by priority descending
    edge_scores.sort(key=lambda x: -x[0])

    guard_set: Set[Tuple[str, str]] = set()
    for _, edge in edge_scores[:budget]:
        guard_set.add(edge)

    return guard_set
