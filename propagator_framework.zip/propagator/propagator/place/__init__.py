"""
propagator.place
================
Budget-constrained guard placement optimisation for the PROPAGATOR framework.

Provides:

* :class:`PlacementMethod` — enumeration of placement strategies (greedy
  submodular, degree centrality, min-vertex-cut, provenance heuristic, etc.).
* :class:`GuardPlacementOptimizer` — primary optimizer that accepts a
  :class:`~propagator.graph.PropagatorGraph`, a budget, and a guardrail tier
  and exposes a full suite of placement strategies plus a
  security-utility trade-off curve.
* :class:`PlacementResult` — rich result type with guard set, cost, blast
  radius, blast-radius reduction, and ready-to-deploy ``safeguards.json``.
* :func:`predict_placement_from_structural` — O(n + m) cheap predictor using
  only structural indices.

Typical usage
-------------
>>> from propagator.graph import TopologyFactory
>>> from propagator.place import GuardPlacementOptimizer, PlacementMethod
>>> g = TopologyFactory.star(n_leaves=6)
>>> opt = GuardPlacementOptimizer(g, budget=4)
>>> result = opt.optimize_greedy()
>>> print(result)
>>> safeguards = result.safeguards_json
"""

from .optimizer import (
    GuardPlacementOptimizer,
    PlacementMethod,
    PlacementResult,
    predict_placement_from_structural,
)

__all__ = [
    "GuardPlacementOptimizer",
    "PlacementMethod",
    "PlacementResult",
    "predict_placement_from_structural",
]
