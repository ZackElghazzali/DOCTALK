"""
propagator.metrics
==================
Risk and structural metrics for the PROPAGATOR framework.

Provides:

* :func:`compute_prs` — Propagation Risk Score.
* :func:`compute_gaf` — Guardrail Attenuation Factor.
* :func:`compute_structural_indices` — structural graph metrics (clustering,
  centrality, diameter, etc.).
* :func:`compute_blast_radius` — expected number of agents infected from a
  given seed node.
* Supporting classes: :class:`PRSResult`, :class:`PRSMatrix`,
  :class:`GAFResult`, :class:`GAFTable`.
"""

from __future__ import annotations

from typing import Dict, Optional

from .gaf import GAFResult, GAFTable, build_gaf_table, compute_gaf, compute_gaf_table
from .prs import (
    PRSMatrix,
    PRSResult,
    build_prs_matrix,
    compute_prs,
    compute_prs_matrix,
    compute_weighted_prs,
)


# ---------------------------------------------------------------------------
# compute_structural_indices
# ---------------------------------------------------------------------------

def compute_structural_indices(graph) -> Dict[str, float]:
    """Compute structural graph metrics for a :class:`~propagator.graph.PropagatorGraph`.

    Metrics returned
    ----------------
    * ``n_nodes``       — number of agent nodes.
    * ``n_edges``       — number of directed edges.
    * ``density``       — graph density (edges / max possible edges).
    * ``avg_in_degree`` — average in-degree.
    * ``avg_out_degree``— average out-degree.
    * ``max_in_degree`` — maximum in-degree.
    * ``max_out_degree``— maximum out-degree.
    * ``clustering``    — average clustering coefficient (undirected view).
    * ``diameter``      — longest shortest path (0 if graph is disconnected).
    * ``avg_path_length``— average shortest path length (0 if disconnected).
    * ``is_strongly_connected`` — 1.0 if strongly connected, else 0.0.

    Parameters
    ----------
    graph : PropagatorGraph
        The topology to analyse.

    Returns
    -------
    dict[str, float]
    """
    try:
        import networkx as nx
    except ImportError:
        return {}

    g = graph._graph  # type: ignore[attr-defined]
    n = g.number_of_nodes()
    e = g.number_of_edges()

    in_degrees  = [d for _, d in g.in_degree()]
    out_degrees = [d for _, d in g.out_degree()]

    density = nx.density(g)
    avg_in  = (sum(in_degrees)  / n) if n > 0 else 0.0
    avg_out = (sum(out_degrees) / n) if n > 0 else 0.0
    max_in  = max(in_degrees,  default=0)
    max_out = max(out_degrees, default=0)

    # Clustering on undirected view
    ug = g.to_undirected()
    clustering = nx.average_clustering(ug) if n > 0 else 0.0

    # Diameter / avg path length — only for (weakly) connected graphs
    diameter   = 0.0
    avg_path   = 0.0
    if n > 0 and nx.is_weakly_connected(g):
        try:
            # Compute on undirected version for robustness
            diameter  = float(nx.diameter(ug))
            avg_path  = float(nx.average_shortest_path_length(ug))
        except Exception:
            diameter = 0.0
            avg_path = 0.0

    is_sc = float(nx.is_strongly_connected(g)) if n > 0 else 0.0

    return {
        "n_nodes":               float(n),
        "n_edges":               float(e),
        "density":               density,
        "avg_in_degree":         avg_in,
        "avg_out_degree":        avg_out,
        "max_in_degree":         float(max_in),
        "max_out_degree":        float(max_out),
        "clustering":            clustering,
        "diameter":              diameter,
        "avg_path_length":       avg_path,
        "is_strongly_connected": is_sc,
    }


# ---------------------------------------------------------------------------
# compute_blast_radius
# ---------------------------------------------------------------------------

def compute_blast_radius(
    graph,
    seed_node: str,
    attack_type: Optional[str] = None,
    beta: float = 0.3,
) -> float:
    """Estimate the blast radius from *seed_node* on *graph*.

    The blast radius BR(v) is the expected number of nodes that would be
    infected given an injection originating at *seed_node*, computed from the
    reachable subgraph weighted by transmission probabilities.

    Formula
    -------
    .. code-block:: none

        BR(v) = Σ_{u reachable from v} Π_{e on path} p(e)

    For efficiency the sum is approximated by the size of the reachable
    subgraph multiplied by the mean edge transmission weight along paths.

    Parameters
    ----------
    graph : PropagatorGraph
        The topology to analyse.
    seed_node : str
        Source node identifier.
    attack_type : str | None
        If provided, the attack-type-specific transmission probability is
        used via ``graph.transmission_probability``.  When ``None``, raw
        edge weights are used.
    beta : float
        Base infection rate β, used to scale transmission probabilities.

    Returns
    -------
    float
        Expected blast radius (number of nodes), ∈ [0, N].
    """
    try:
        import networkx as nx
    except ImportError:
        return 0.0

    g = graph._graph  # type: ignore[attr-defined]
    n_total = g.number_of_nodes()

    if seed_node not in g:
        return 0.0

    # BFS / DFS to find reachable nodes and accumulate path weights
    reachable_weights: Dict[str, float] = {seed_node: 1.0}
    queue = [seed_node]
    visited = {seed_node}

    while queue:
        current = queue.pop(0)
        current_weight = reachable_weights[current]
        for successor in g.successors(current):
            if successor not in visited:
                # Edge transmission probability
                if attack_type is not None:
                    try:
                        edge_p = graph.transmission_probability(
                            current, successor, attack_type=attack_type
                        )
                    except Exception:
                        edge_p = g[current][successor].get("weight", 1.0) * beta
                else:
                    edge_p = g[current][successor].get("weight", 1.0) * beta

                new_weight = current_weight * max(0.0, min(1.0, edge_p))
                if new_weight > 0.001:   # prune negligible paths
                    reachable_weights[successor] = new_weight
                    visited.add(successor)
                    queue.append(successor)

    # Blast radius = expected number of infected nodes (sum of path probabilities)
    # Exclude the seed node itself (already infected)
    blast = sum(w for node, w in reachable_weights.items() if node != seed_node)
    return float(min(blast, n_total))


__all__ = [
    # PRS
    "PRSResult",
    "PRSMatrix",
    "compute_prs",
    "compute_prs_matrix",
    "compute_weighted_prs",
    "build_prs_matrix",
    # GAF
    "GAFResult",
    "GAFTable",
    "compute_gaf",
    "compute_gaf_table",
    "build_gaf_table",
    # Structural
    "compute_structural_indices",
    "compute_blast_radius",
]
