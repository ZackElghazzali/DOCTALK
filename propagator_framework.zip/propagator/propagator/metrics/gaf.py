"""
propagator.metrics.gaf
======================
Guardrail Attenuation Factor (GAF) computation.

GAF(τ, α, g) = 1 - PRS(τ, α | g) / PRS(τ, α | G0)

GAF=0.65 means the guardrail configuration g reduces risk by 65% relative
to the no-guardrail baseline G0.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

from ..sim import AttackType
from .prs import PRSMatrix, PRSResult


# ---------------------------------------------------------------------------
# GAFResult
# ---------------------------------------------------------------------------


@dataclass
class GAFResult:
    """
    Result of a single GAF computation for one (topology, attack_type,
    guardrail_config) triple.

    Attributes
    ----------
    topology_name : str
        Identifier of the topology.
    attack_type : AttackType
        The attack type this GAF was computed for.
    guardrail_config : str
        Name / identifier of the guardrail configuration.
    gaf_value : float
        GAF ∈ [0, 1].  0 = no attenuation; 1 = full attenuation.
    baseline_prs : float
        PRS of the no-guardrail baseline (G0).
    guarded_prs : float
        PRS under the guardrail configuration g.
    """

    topology_name: str
    attack_type: AttackType
    guardrail_config: str
    gaf_value: float
    baseline_prs: float
    guarded_prs: float

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "topology_name": self.topology_name,
            "attack_type": self.attack_type.value
            if hasattr(self.attack_type, "value")
            else str(self.attack_type),
            "guardrail_config": self.guardrail_config,
            "gaf_value": self.gaf_value,
            "baseline_prs": self.baseline_prs,
            "guarded_prs": self.guarded_prs,
        }

    def __repr__(self) -> str:
        return (
            f"GAFResult(topology={self.topology_name!r}, "
            f"attack={self.attack_type}, config={self.guardrail_config!r}, "
            f"gaf={self.gaf_value:.4f})"
        )


# ---------------------------------------------------------------------------
# GAFTable
# ---------------------------------------------------------------------------


class GAFTable:
    """
    Full topology × attack_type × guardrail_config → GAFResult tensor.

    Attributes
    ----------
    topology_name : str
        Topology this table is for.
    data : dict[str, dict[AttackType, GAFResult]]
        Outer key: guardrail config name.
        Inner key: attack type.
        Value: GAFResult.
    """

    def __init__(
        self,
        topology_name: str,
        data: Optional[Dict[str, Dict[AttackType, GAFResult]]] = None,
    ) -> None:
        self.topology_name = topology_name
        self.data: Dict[str, Dict[AttackType, GAFResult]] = data or {}

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get(
        self, guardrail_config: str, attack_type: AttackType
    ) -> Optional[GAFResult]:
        """Retrieve a single GAFResult or None if not present."""
        return self.data.get(guardrail_config, {}).get(attack_type)

    def mean_gaf_for_config(self, guardrail_config: str) -> float:
        """Mean GAF across all attack types for a given guardrail config."""
        config_data = self.data.get(guardrail_config, {})
        if not config_data:
            return 0.0
        values = [r.gaf_value for r in config_data.values()]
        return float(np.mean(values))

    def best_config_per_topology(self) -> Dict[str, str]:
        """
        Return {topology_name: best_guardrail_config} where best is
        defined by highest mean GAF across attack types.

        Returns
        -------
        dict[str, str]
            Single-entry dict since this table is for one topology.
        """
        if not self.data:
            return {self.topology_name: ""}

        best_config = max(
            self.data.keys(),
            key=lambda cfg: self.mean_gaf_for_config(cfg),
        )
        return {self.topology_name: best_config}

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dataframe(self) -> dict:
        """
        Return a nested dict suitable for pandas DataFrame construction.

        Structure
        ---------
        ``{guardrail_config: {attack_type_str: gaf_value}}``

        Example::

            import pandas as pd
            df = pd.DataFrame(gaf_table.to_dataframe())
        """
        result: dict = {}
        for config, attack_dict in self.data.items():
            result[config] = {
                (
                    at.value if hasattr(at, "value") else str(at)
                ): gaf_result.gaf_value
                for at, gaf_result in attack_dict.items()
            }
        return result

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "topology_name": self.topology_name,
            "data": {
                config: {
                    (at.value if hasattr(at, "value") else str(at)): gaf_r.to_dict()
                    for at, gaf_r in attack_dict.items()
                }
                for config, attack_dict in self.data.items()
            },
        }

    def __repr__(self) -> str:
        n_configs = len(self.data)
        n_attacks = len(next(iter(self.data.values()), {}))
        return (
            f"GAFTable(topology={self.topology_name!r}, "
            f"configs={n_configs}, attacks={n_attacks})"
        )


# ---------------------------------------------------------------------------
# compute_gaf
# ---------------------------------------------------------------------------


def compute_gaf(
    baseline_prs: PRSResult,
    guarded_prs: PRSResult,
    guardrail_config_name: str,
) -> GAFResult:
    """
    Compute GAF for a single (attack_type, guardrail_config) pair.

    GAF(τ, α, g) = 1 - PRS(τ, α | g) / PRS(τ, α | G0)

    Parameters
    ----------
    baseline_prs : PRSResult
        PRS under the no-guardrail baseline G0.
    guarded_prs : PRSResult
        PRS under guardrail configuration g.
    guardrail_config_name : str
        Name of the guardrail configuration.

    Returns
    -------
    GAFResult

    Notes
    -----
    - If ``baseline_prs.prs_value`` is 0, GAF is defined as 0.0 (baseline
      is already risk-free; guardrails add no measurable benefit).
    - GAF is clamped to [0, 1].  A negative GAF (guardrail increases risk)
      is clamped to 0.
    """
    if baseline_prs.prs_value <= 0.0:
        gaf_value = 0.0
    else:
        gaf_value = 1.0 - guarded_prs.prs_value / baseline_prs.prs_value
        gaf_value = float(np.clip(gaf_value, 0.0, 1.0))

    # Validate that both results refer to the same context
    topology = baseline_prs.topology_name
    attack_type = baseline_prs.attack_type

    return GAFResult(
        topology_name=topology,
        attack_type=attack_type,
        guardrail_config=guardrail_config_name,
        gaf_value=gaf_value,
        baseline_prs=baseline_prs.prs_value,
        guarded_prs=guarded_prs.prs_value,
    )


# ---------------------------------------------------------------------------
# compute_gaf_table
# ---------------------------------------------------------------------------


def compute_gaf_table(
    baseline_matrix: PRSMatrix,
    guarded_matrices: Dict[str, PRSMatrix],
) -> Dict[str, Dict[AttackType, GAFResult]]:
    """
    Compute the full GAF table for all guardrail configs vs baseline.

    Parameters
    ----------
    baseline_matrix : PRSMatrix
        PRS results under the no-guardrail baseline (G0).
    guarded_matrices : dict[str, PRSMatrix]
        Mapping from guardrail config name → PRSMatrix under that config.

    Returns
    -------
    dict[str, dict[AttackType, GAFResult]]
        Outer key: guardrail config name.
        Inner key: attack type.
        Value: GAFResult.
    """
    table: Dict[str, Dict[AttackType, GAFResult]] = {}

    for config_name, guarded_matrix in guarded_matrices.items():
        table[config_name] = {}

        # Iterate over attack types present in the baseline
        for attack_type, baseline_prs in baseline_matrix.prs_by_attack.items():
            guarded_prs = guarded_matrix.prs_by_attack.get(attack_type)

            if guarded_prs is None:
                # Guardrail matrix doesn't have this attack type — assume no
                # change (GAF = 0).
                guarded_prs_result = PRSResult(
                    topology_name=guarded_matrix.topology_name,
                    attack_type=attack_type,
                    prs_value=baseline_prs.prs_value,
                    mean_final_rate=baseline_prs.mean_final_rate,
                    mean_peak_velocity=baseline_prs.mean_peak_velocity,
                    severity_weight=baseline_prs.severity_weight,
                    n_trials=0,
                    seed_nodes=[],
                )
            else:
                guarded_prs_result = guarded_prs

            table[config_name][attack_type] = compute_gaf(
                baseline_prs=baseline_prs,
                guarded_prs=guarded_prs_result,
                guardrail_config_name=config_name,
            )

    return table


# ---------------------------------------------------------------------------
# build_gaf_table (convenience factory)
# ---------------------------------------------------------------------------


def build_gaf_table(
    baseline_matrix: PRSMatrix,
    guarded_matrices: Dict[str, PRSMatrix],
) -> GAFTable:
    """
    Convenience factory that builds a :class:`GAFTable` from PRSMatrix objects.

    Parameters
    ----------
    baseline_matrix : PRSMatrix
        PRS results under the no-guardrail baseline.
    guarded_matrices : dict[str, PRSMatrix]
        Mapping from guardrail config name → PRSMatrix under that config.

    Returns
    -------
    GAFTable
    """
    raw = compute_gaf_table(baseline_matrix, guarded_matrices)
    return GAFTable(topology_name=baseline_matrix.topology_name, data=raw)
