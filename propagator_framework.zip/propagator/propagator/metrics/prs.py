"""
propagator.metrics.prs
======================
Propagation Risk Score (PRS) computation.

PRS(τ, α) = μ_Ī * λ_α * V_peak

Where:
  μ_Ī     = mean final infection rate averaged over seed nodes
  λ_α     = severity weight for attack type α (from ATTACK_SEVERITY_WEIGHTS)
  V_peak  = mean peak propagation velocity (max rate of Σ_i dI_i/dt)

PRS is clamped to [0, 1].
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from ..sim import AttackResult, AttackType, ATTACK_SEVERITY_WEIGHTS


# ---------------------------------------------------------------------------
# PRSResult
# ---------------------------------------------------------------------------


@dataclass
class PRSResult:
    """
    Result of a single PRS computation for one (topology, attack_type) pair.

    Attributes
    ----------
    topology_name : str
        Identifier of the topology / graph configuration.
    attack_type : AttackType
        The attack type this PRS was computed for.
    prs_value : float
        Final PRS ∈ [0, 1].
    mean_final_rate : float
        Mean final infection rate μ_Ī averaged over seed nodes, ∈ [0, 1].
    mean_peak_velocity : float
        Mean peak propagation velocity V_peak (max Σ dI/dt over time).
    severity_weight : float
        λ_α – severity weight for this attack type.
    n_trials : int
        Number of simulation trials that contributed to this estimate.
    seed_nodes : list[str]
        Node IDs used as seeds across the trials.
    """

    topology_name: str
    attack_type: AttackType
    prs_value: float
    mean_final_rate: float
    mean_peak_velocity: float
    severity_weight: float
    n_trials: int
    seed_nodes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "topology_name": self.topology_name,
            "attack_type": self.attack_type.value
            if hasattr(self.attack_type, "value")
            else str(self.attack_type),
            "prs_value": self.prs_value,
            "mean_final_rate": self.mean_final_rate,
            "mean_peak_velocity": self.mean_peak_velocity,
            "severity_weight": self.severity_weight,
            "n_trials": self.n_trials,
            "seed_nodes": list(self.seed_nodes),
        }

    def __repr__(self) -> str:
        return (
            f"PRSResult(topology={self.topology_name!r}, "
            f"attack={self.attack_type}, prs={self.prs_value:.4f})"
        )


# ---------------------------------------------------------------------------
# PRSMatrix
# ---------------------------------------------------------------------------


@dataclass
class PRSMatrix:
    """
    Container for PRS results across all attack types for a single topology.

    Attributes
    ----------
    topology_name : str
        Identifier of the topology.
    prs_by_attack : dict[AttackType, PRSResult]
        Per-attack-type PRS results.
    attack_weights : dict[AttackType, float] | None
        Optional empirical frequency priors used for weighted_prs.
    """

    topology_name: str
    prs_by_attack: Dict[AttackType, PRSResult]
    attack_weights: Optional[Dict[AttackType, float]] = None

    @property
    def weighted_prs(self) -> float:
        """Weighted average PRS across attack types."""
        return compute_weighted_prs(self.prs_by_attack, self.attack_weights)

    @property
    def max_prs(self) -> float:
        """Worst-case PRS across all attack types."""
        if not self.prs_by_attack:
            return 0.0
        return max(r.prs_value for r in self.prs_by_attack.values())

    @property
    def mean_prs(self) -> float:
        """Unweighted mean PRS across all attack types."""
        if not self.prs_by_attack:
            return 0.0
        values = [r.prs_value for r in self.prs_by_attack.values()]
        return float(np.mean(values))

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "topology_name": self.topology_name,
            "prs_by_attack": {
                (
                    k.value if hasattr(k, "value") else str(k)
                ): v.to_dict()
                for k, v in self.prs_by_attack.items()
            },
            "attack_weights": {
                (k.value if hasattr(k, "value") else str(k)): w
                for k, w in (self.attack_weights or {}).items()
            },
            "weighted_prs": self.weighted_prs,
            "max_prs": self.max_prs,
            "mean_prs": self.mean_prs,
        }

    def __repr__(self) -> str:
        return (
            f"PRSMatrix(topology={self.topology_name!r}, "
            f"n_attacks={len(self.prs_by_attack)}, "
            f"weighted_prs={self.weighted_prs:.4f})"
        )


# ---------------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------------


def _peak_velocity(infection_counts: np.ndarray) -> float:
    """
    Compute peak propagation velocity from a 1-D array of cumulative
    infection counts over discrete time steps.

    Parameters
    ----------
    infection_counts : np.ndarray
        Array of shape (T,) where T is the number of time steps and
        each element is the *total* number of infected agents at that step.
        May also be fractional (infection rate per agent).

    Returns
    -------
    float
        Maximum discrete first-difference (dI/dt), ≥ 0.
    """
    if infection_counts is None or len(infection_counts) < 2:
        return 0.0
    diffs = np.diff(infection_counts.astype(float))
    peak = float(np.max(diffs))
    return max(0.0, peak)


def _extract_from_attack_result(
    attack_result: AttackResult,
) -> Tuple[float, float, List[str]]:
    """
    Extract (mean_final_rate, mean_peak_velocity, seed_nodes) from an
    :class:`AttackResult`.

    The function is intentionally defensive: it handles both the case where
    AttackResult stores time-series data and the case where it stores only
    summary statistics.

    Returns
    -------
    tuple[float, float, list[str]]
        (mean_final_rate, mean_peak_velocity, seed_nodes)
    """
    seed_nodes: List[str] = []

    # ---- Final infection rate -----------------------------------------------
    # Prefer ``final_infection_rate`` attribute; fall back to other conventions.
    if hasattr(attack_result, "final_infection_rate"):
        mean_final_rate = float(attack_result.final_infection_rate)
    elif hasattr(attack_result, "infection_rate"):
        mean_final_rate = float(attack_result.infection_rate)
    elif hasattr(attack_result, "mean_final_rate"):
        mean_final_rate = float(attack_result.mean_final_rate)
    elif hasattr(attack_result, "n_infected") and hasattr(attack_result, "n_agents"):
        n_inf = getattr(attack_result, "n_infected", 0)
        n_agents = getattr(attack_result, "n_agents", 1)
        mean_final_rate = n_inf / max(1, n_agents)
    else:
        # Try to derive from infection_timeline if available
        mean_final_rate = _derive_final_rate(attack_result)

    mean_final_rate = float(np.clip(mean_final_rate, 0.0, 1.0))

    # ---- Peak velocity -------------------------------------------------------
    mean_peak_velocity = _derive_peak_velocity(attack_result)

    # ---- Seed nodes ----------------------------------------------------------
    for attr in ("seed_node", "seed_nodes", "seeds", "entry_node", "entry_nodes"):
        val = getattr(attack_result, attr, None)
        if val is not None:
            if isinstance(val, str):
                seed_nodes = [val]
            elif hasattr(val, "__iter__"):
                seed_nodes = list(val)
            break

    return mean_final_rate, mean_peak_velocity, seed_nodes


def _derive_final_rate(attack_result: AttackResult) -> float:
    """Fallback: extract final infection rate from timeline attributes."""
    for attr in (
        "infection_timeline",
        "infected_counts",
        "infected_over_time",
        "time_series",
    ):
        timeline = getattr(attack_result, attr, None)
        if timeline is not None:
            arr = np.asarray(timeline, dtype=float)
            if arr.ndim == 2:
                # shape (T, N) → sum over agents per step, then normalise
                totals = arr.sum(axis=1)
                n_agents = arr.shape[1]
                if n_agents > 0:
                    return float(totals[-1] / n_agents)
            elif arr.ndim == 1 and len(arr) > 0:
                # Already a scalar-per-step: last value is final rate
                return float(arr[-1])
    # Last resort
    return 0.0


def _derive_peak_velocity(attack_result: AttackResult) -> float:
    """Extract or estimate peak propagation velocity from an AttackResult."""
    # Direct attribute
    for attr in ("peak_velocity", "max_velocity", "mean_peak_velocity"):
        val = getattr(attack_result, attr, None)
        if val is not None:
            return float(val)

    # Derive from time series
    for attr in (
        "infection_timeline",
        "infected_counts",
        "infected_over_time",
        "time_series",
    ):
        timeline = getattr(attack_result, attr, None)
        if timeline is not None:
            arr = np.asarray(timeline, dtype=float)
            if arr.ndim == 2:
                totals = arr.sum(axis=1)
                return _peak_velocity(totals)
            elif arr.ndim == 1 and len(arr) > 0:
                return _peak_velocity(arr)

    # Fallback: approximate from final rate (assume linear spread)
    final_rate = getattr(attack_result, "final_infection_rate", None)
    if final_rate is not None:
        n_steps = getattr(attack_result, "n_steps", 10)
        return float(final_rate) / max(1, n_steps)

    return 0.0


# ---------------------------------------------------------------------------
# compute_prs
# ---------------------------------------------------------------------------


def compute_prs(
    attack_result: AttackResult,
    attack_type: AttackType,
    topology_name: str = "unknown",
) -> PRSResult:
    """
    Compute PRS for a single simulation result.

    PRS(τ, α) = μ_Ī * λ_α * V_peak

    The result is clamped to [0, 1].

    Parameters
    ----------
    attack_result : AttackResult
        The simulation result from which infection metrics are extracted.
    attack_type : AttackType
        The attack type used in the simulation.
    topology_name : str
        Name of the topology being evaluated.

    Returns
    -------
    PRSResult
        Computed PRS and its components.
    """
    mean_final_rate, mean_peak_velocity, seed_nodes = _extract_from_attack_result(
        attack_result
    )

    # Severity weight from global table; default to 1.0 if not found
    severity_weight = float(
        ATTACK_SEVERITY_WEIGHTS.get(attack_type, 1.0)
        if hasattr(ATTACK_SEVERITY_WEIGHTS, "get")
        else 1.0
    )

    # PRS = μ_Ī * λ_α * V_peak
    # V_peak is already in [0, n_agents] or [0, 1] depending on representation;
    # we normalise to [0, 1] by clamping the product.
    raw_prs = mean_final_rate * severity_weight * mean_peak_velocity

    # Clamp to [0, 1]
    prs_value = float(np.clip(raw_prs, 0.0, 1.0))

    # If PRS collapses to 0 but there is actual infection, apply a floor
    # based solely on the infection rate (represents a static-snapshot score)
    if prs_value == 0.0 and mean_final_rate > 0.0:
        prs_value = float(np.clip(mean_final_rate * severity_weight, 0.0, 1.0))

    n_trials = int(getattr(attack_result, "n_trials", 1))

    return PRSResult(
        topology_name=topology_name,
        attack_type=attack_type,
        prs_value=prs_value,
        mean_final_rate=mean_final_rate,
        mean_peak_velocity=mean_peak_velocity,
        severity_weight=severity_weight,
        n_trials=n_trials,
        seed_nodes=seed_nodes,
    )


# ---------------------------------------------------------------------------
# compute_prs_matrix
# ---------------------------------------------------------------------------


def compute_prs_matrix(
    results: Dict[Tuple[AttackType, str], AttackResult],
    topology_name: str,
) -> Dict[AttackType, PRSResult]:
    """
    Compute PRS for all (attack_type, seed) combos and average over seeds
    per attack type.

    Parameters
    ----------
    results : dict[(AttackType, str), AttackResult]
        Mapping from (attack_type, seed_node_id) → simulation result.
    topology_name : str
        Name of the topology being evaluated.

    Returns
    -------
    dict[AttackType, PRSResult]
        Per-attack-type averaged PRSResult.
    """
    if not results:
        return {}

    # Group by attack type
    by_attack: Dict[AttackType, List[Tuple[str, AttackResult]]] = {}
    for (attack_type, seed_node), attack_result in results.items():
        by_attack.setdefault(attack_type, []).append((seed_node, attack_result))

    averaged: Dict[AttackType, PRSResult] = {}

    for attack_type, seed_results in by_attack.items():
        # Compute PRS for each seed individually
        per_seed_prs: List[PRSResult] = []
        all_seeds: List[str] = []
        total_trials: int = 0

        for seed_node, attack_result in seed_results:
            prs_r = compute_prs(attack_result, attack_type, topology_name)
            per_seed_prs.append(prs_r)
            all_seeds.extend(prs_r.seed_nodes if prs_r.seed_nodes else [seed_node])
            total_trials += prs_r.n_trials

        # Average the component metrics, then recompute PRS from averaged components
        avg_final_rate = float(np.mean([r.mean_final_rate for r in per_seed_prs]))
        avg_peak_vel = float(np.mean([r.mean_peak_velocity for r in per_seed_prs]))
        severity_weight = per_seed_prs[0].severity_weight  # same for all seeds

        raw_prs = avg_final_rate * severity_weight * avg_peak_vel
        prs_value = float(np.clip(raw_prs, 0.0, 1.0))

        if prs_value == 0.0 and avg_final_rate > 0.0:
            prs_value = float(np.clip(avg_final_rate * severity_weight, 0.0, 1.0))

        averaged[attack_type] = PRSResult(
            topology_name=topology_name,
            attack_type=attack_type,
            prs_value=prs_value,
            mean_final_rate=avg_final_rate,
            mean_peak_velocity=avg_peak_vel,
            severity_weight=severity_weight,
            n_trials=total_trials,
            seed_nodes=all_seeds,
        )

    return averaged


# ---------------------------------------------------------------------------
# compute_weighted_prs
# ---------------------------------------------------------------------------


def compute_weighted_prs(
    prs_by_attack: Dict[AttackType, PRSResult],
    attack_weights: Optional[Dict[AttackType, float]] = None,
) -> float:
    """
    Compute the weighted average PRS across attack types.

    PRS_weighted(τ) = Σ_α w_α * PRS(τ, α)

    Parameters
    ----------
    prs_by_attack : dict[AttackType, PRSResult]
        Per-attack-type PRS results.
    attack_weights : dict[AttackType, float] | None
        Empirical attack frequency priors.  If ``None`` or a weight is
        missing for a particular attack type, equal weights are used
        (i.e. 1 / |attack_types|).

    Returns
    -------
    float
        Weighted average PRS ∈ [0, 1].
    """
    if not prs_by_attack:
        return 0.0

    attack_types = list(prs_by_attack.keys())
    n = len(attack_types)

    # Build weight vector
    weights: List[float] = []
    for at in attack_types:
        if attack_weights is not None and at in attack_weights:
            weights.append(float(attack_weights[at]))
        else:
            weights.append(1.0 / n)

    # Normalise weights so they sum to 1
    w_sum = sum(weights)
    if w_sum <= 0:
        weights = [1.0 / n] * n
        w_sum = 1.0
    weights = [w / w_sum for w in weights]

    prs_values = [prs_by_attack[at].prs_value for at in attack_types]
    weighted = float(np.dot(weights, prs_values))
    return float(np.clip(weighted, 0.0, 1.0))


# ---------------------------------------------------------------------------
# build_prs_matrix (convenience constructor)
# ---------------------------------------------------------------------------


def build_prs_matrix(
    results: Dict[Tuple[AttackType, str], AttackResult],
    topology_name: str,
    attack_weights: Optional[Dict[AttackType, float]] = None,
) -> PRSMatrix:
    """
    Convenience factory that builds a :class:`PRSMatrix` from raw results.

    Parameters
    ----------
    results : dict[(AttackType, str), AttackResult]
        Mapping from (attack_type, seed_node_id) → simulation result.
    topology_name : str
        Name of the topology.
    attack_weights : dict[AttackType, float] | None
        Optional empirical frequency priors.

    Returns
    -------
    PRSMatrix
    """
    prs_by_attack = compute_prs_matrix(results, topology_name)
    return PRSMatrix(
        topology_name=topology_name,
        prs_by_attack=prs_by_attack,
        attack_weights=attack_weights,
    )
