"""
propagator.metrics.blast_radius
================================
Importance-weighted blast radius computation.

blast_radius(S) = Σ_i μ_i * π_i(S)

where π_i(S) = P(agent i compromised | guards on edge set S) is estimated
as the maximum-probability path from any entry point to node i through the
transmission graph, with guarded edges attenuated by a miss-rate factor.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

import networkx as nx
import numpy as np

from ..graph import PropagatorGraph

logger = logging.getLogger(__name__)

# Default probability that a guard misses an attack (attenuates transmission)
_DEFAULT_GUARD_MISS_RATE: float = 0.1


# ---------------------------------------------------------------------------
# BlastRadiusResult
# ---------------------------------------------------------------------------


@dataclass
class BlastRadiusResult:
    """
    Result of a blast-radius computation.

    Attributes
    ----------
    guard_set : set[tuple[str, str]]
        The set of guarded edges (source_id, target_id).
    importance_weighted_radius : float
        Σ_i μ_i * π_i  — primary metric.
    worst_case_radius : float
        max_i (μ_i * π_i).
    per_node_compromise_prob : dict[str, float]
        π_i for every agent node i.
    budget_used : float
        Sum of edge utility costs consumed by the guard set.
        Set to 0.0 if costs were not provided.
    """

    guard_set: Set[Tuple[str, str]]
    importance_weighted_radius: float
    worst_case_radius: float
    per_node_compromise_prob: Dict[str, float]
    budget_used: float = 0.0

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "guard_set": [[s, t] for s, t in sorted(self.guard_set)],
            "importance_weighted_radius": self.importance_weighted_radius,
            "worst_case_radius": self.worst_case_radius,
            "per_node_compromise_prob": dict(self.per_node_compromise_prob),
            "budget_used": self.budget_used,
        }

    def __repr__(self) -> str:
        return (
            f"BlastRadiusResult("
            f"iwr={self.importance_weighted_radius:.4f}, "
            f"worst={self.worst_case_radius:.4f}, "
            f"guards={len(self.guard_set)})"
        )


# ---------------------------------------------------------------------------
# Graph accessors (shared helpers, similar to structural.py)
# ---------------------------------------------------------------------------


def _get_nodes(graph: PropagatorGraph):
    for attr in ("nodes", "agents", "agent_nodes", "vertices"):
        val = getattr(graph, attr, None)
        if val is not None:
            if callable(val):
                return list(val())
            if hasattr(val, "values"):
                return list(val.values())
            return list(val)
    try:
        return list(graph)
    except TypeError:
        return []


def _get_edges(graph: PropagatorGraph):
    for attr in ("edges", "links", "connections", "agent_edges"):
        val = getattr(graph, attr, None)
        if val is not None:
            if callable(val):
                return list(val())
            if hasattr(val, "values"):
                return list(val.values())
            return list(val)
    return []


def _node_id(node) -> str:
    for attr in ("node_id", "id", "name", "agent_id"):
        val = getattr(node, attr, None)
        if val is not None:
            return str(val)
    return str(node)


def _node_importance(node) -> float:
    for attr in ("importance", "severity", "weight", "mu"):
        val = getattr(node, attr, None)
        if val is not None:
            try:
                return float(val)
            except (TypeError, ValueError):
                pass
    return 1.0


def _node_is_entry(node) -> bool:
    for attr in ("is_entry_point", "entry_point", "is_entry"):
        val = getattr(node, attr, None)
        if val is not None:
            return bool(val)
    role = getattr(node, "role", None)
    if role is not None and "entry" in str(role).lower():
        return True
    return False


def _edge_components(edge) -> Tuple[str, str, float]:
    if isinstance(edge, (tuple, list)):
        if len(edge) >= 3:
            return str(edge[0]), str(edge[1]), float(edge[2])
        elif len(edge) == 2:
            return str(edge[0]), str(edge[1]), 1.0
    src = str(
        getattr(edge, "source_id", None)
        or getattr(edge, "source", None)
        or getattr(edge, "src", None)
        or ""
    )
    tgt = str(
        getattr(edge, "target_id", None)
        or getattr(edge, "target", None)
        or getattr(edge, "tgt", None)
        or ""
    )
    weight = float(getattr(edge, "weight", 1.0) or 1.0)
    return src, tgt, weight


# ---------------------------------------------------------------------------
# Core computation
# ---------------------------------------------------------------------------


def _build_graph_for_blast(
    graph: PropagatorGraph,
    guard_set: Set[Tuple[str, str]],
    guard_miss_rate: float,
) -> Tuple[nx.DiGraph, Dict[str, float], List[str]]:
    """
    Build a NetworkX DiGraph with log-probability edge weights for
    shortest-path (Bellman-Ford / Dijkstra) computation.

    Edge weight = -log(transmission_prob), where guarded edges have their
    transmission multiplied by ``guard_miss_rate``.

    Returns
    -------
    (G, importances, entry_nodes)
    """
    G = nx.DiGraph()
    importances: Dict[str, float] = {}
    entry_nodes: List[str] = []

    nodes = _get_nodes(graph)
    for node in nodes:
        nid = _node_id(node)
        imp = _node_importance(node)
        is_entry = _node_is_entry(node)
        G.add_node(nid, importance=imp, is_entry_point=is_entry)
        importances[nid] = imp
        if is_entry:
            entry_nodes.append(nid)

    edges = _get_edges(graph)
    for edge in edges:
        src, tgt, weight = _edge_components(edge)
        if src not in G or tgt not in G:
            continue

        # Apply guard miss rate if this edge is guarded
        effective_weight = weight
        if (src, tgt) in guard_set:
            effective_weight = weight * guard_miss_rate

        # Clamp to avoid log(0)
        effective_weight = max(1e-12, min(1.0, effective_weight))

        # Negative log for shortest-path computation
        log_w = -math.log(effective_weight)
        G.add_edge(src, tgt, log_weight=log_w, prob=effective_weight)

    return G, importances, entry_nodes


def _max_prob_paths(
    G: nx.DiGraph,
    entry_nodes: List[str],
) -> Dict[str, float]:
    """
    For each node, find the maximum probability path from any entry point.

    Uses Dijkstra on reversed graph in -log(prob) space (shortest path =
    highest probability).

    Parameters
    ----------
    G : nx.DiGraph
        Graph with 'log_weight' attributes on edges.
    entry_nodes : list[str]
        Source nodes representing untrusted entry points.

    Returns
    -------
    dict[str, float]
        Mapping node_id → maximum compromise probability ∈ [0, 1].
    """
    node_ids = list(G.nodes())
    max_probs: Dict[str, float] = {nid: 0.0 for nid in node_ids}

    # Entry points are compromised with probability 1
    for ep in entry_nodes:
        if ep in max_probs:
            max_probs[ep] = 1.0

    if not entry_nodes:
        return max_probs

    # Use a virtual super-source connected to all entry points with weight 1
    # (log_weight = 0) for a single-source shortest-path computation.
    SUPER_SOURCE = "__super_source__"
    G_aug = G.copy()
    G_aug.add_node(SUPER_SOURCE)
    for ep in entry_nodes:
        G_aug.add_edge(SUPER_SOURCE, ep, log_weight=0.0)

    try:
        distances = nx.single_source_dijkstra_path_length(
            G_aug, SUPER_SOURCE, weight="log_weight"
        )
    except nx.NetworkXError as exc:
        logger.warning("Dijkstra failed: %s", exc)
        return max_probs

    for nid in node_ids:
        if nid in distances:
            neg_log_p = distances[nid]
            prob = math.exp(-neg_log_p)
            max_probs[nid] = float(np.clip(prob, 0.0, 1.0))

    return max_probs


# ---------------------------------------------------------------------------
# compute_blast_radius
# ---------------------------------------------------------------------------


def compute_blast_radius(
    graph: PropagatorGraph,
    guard_set: Set[Tuple[str, str]],
    entry_points: Optional[List[str]] = None,
    guard_miss_rate: float = _DEFAULT_GUARD_MISS_RATE,
    utility_costs: Optional[Dict[Tuple[str, str], float]] = None,
) -> BlastRadiusResult:
    """
    Compute the importance-weighted blast radius under a guard set.

    blast_radius(S) = Σ_i μ_i * π_i(S)

    π_i(S) is estimated as the maximum probability of any path from any
    entry point to node i, where:
    - Unguarded edges retain their transmission weight.
    - Guarded edges (in ``guard_set``) are attenuated by ``guard_miss_rate``.

    Parameters
    ----------
    graph : PropagatorGraph
        The MAS transmission graph.
    guard_set : set[tuple[str, str]]
        Edges on which guards are deployed, as (source_id, target_id) pairs.
    entry_points : list[str] | None
        Override which nodes are entry points.  If ``None``, uses nodes
        marked ``is_entry_point=True`` in the graph.
    guard_miss_rate : float
        Probability that a guard fails to block an attack on a guarded edge.
        Defaults to 0.1 (90% blocking effectiveness).
    utility_costs : dict[tuple[str,str], float] | None
        Optional cost map for computing ``budget_used``.

    Returns
    -------
    BlastRadiusResult
    """
    G, importances, graph_entry_nodes = _build_graph_for_blast(
        graph, guard_set, guard_miss_rate
    )

    # Override entry points if provided
    if entry_points is not None:
        effective_entries = [ep for ep in entry_points if ep in G]
    else:
        effective_entries = graph_entry_nodes

    # Fallback: if still no entry points, use nodes with no incoming edges
    if not effective_entries:
        effective_entries = [n for n in G.nodes() if G.in_degree(n) == 0]
    if not effective_entries and len(G) > 0:
        # Use the first node as a last resort
        effective_entries = [next(iter(G.nodes()))]

    per_node_prob = _max_prob_paths(G, effective_entries)

    # importance-weighted radius
    iwr = 0.0
    worst_case = 0.0
    for nid, prob in per_node_prob.items():
        imp = importances.get(nid, 1.0)
        contrib = imp * prob
        iwr += contrib
        if contrib > worst_case:
            worst_case = contrib

    # Budget used
    budget_used = 0.0
    if utility_costs:
        for edge in guard_set:
            budget_used += utility_costs.get(edge, 0.0)

    return BlastRadiusResult(
        guard_set=set(guard_set),
        importance_weighted_radius=float(iwr),
        worst_case_radius=float(worst_case),
        per_node_compromise_prob=per_node_prob,
        budget_used=float(budget_used),
    )


# ---------------------------------------------------------------------------
# SecurityUtilityCurve
# ---------------------------------------------------------------------------


class SecurityUtilityCurve:
    """
    Computes a security-utility Pareto frontier by evaluating blast radius
    reductions across multiple guard placement strategies.

    Methods
    -------
    compute(graph, placement_sets, utility_costs) → list[dict]
        Evaluate each placement set and return points on the curve.
    """

    def compute(
        self,
        graph: PropagatorGraph,
        placement_sets: List[Tuple[str, Set[Tuple[str, str]]]],
        utility_costs: Dict[Tuple[str, str], float],
        guard_miss_rate: float = _DEFAULT_GUARD_MISS_RATE,
    ) -> List[dict]:
        """
        Evaluate blast radius and utility cost for each placement strategy.

        Parameters
        ----------
        graph : PropagatorGraph
            The transmission graph.
        placement_sets : list[tuple[str, set[tuple[str,str]]]]
            Each element is (method_name, guard_edge_set).
        utility_costs : dict[tuple[str,str], float]
            Cost of deploying a guard on each edge.
        guard_miss_rate : float
            Guard miss rate passed through to ``compute_blast_radius``.

        Returns
        -------
        list[dict]
            Each dict has keys:
            - ``method_name`` (str)
            - ``blast_radius`` (float)
            - ``blast_radius_reduction`` (float, relative to no-guard baseline)
            - ``utility_loss`` (float, total guard deployment cost)
            - ``budget_used`` (float)
            - ``n_guards`` (int)
        """
        if not placement_sets:
            return []

        # Compute no-guard baseline
        baseline = compute_blast_radius(
            graph=graph,
            guard_set=set(),
            utility_costs=utility_costs,
            guard_miss_rate=guard_miss_rate,
        )
        baseline_iwr = baseline.importance_weighted_radius

        results: List[dict] = []

        for method_name, guard_set in placement_sets:
            result = compute_blast_radius(
                graph=graph,
                guard_set=guard_set,
                utility_costs=utility_costs,
                guard_miss_rate=guard_miss_rate,
            )

            # Relative blast radius reduction
            if baseline_iwr > 0:
                reduction = (baseline_iwr - result.importance_weighted_radius) / baseline_iwr
            else:
                reduction = 0.0
            reduction = float(np.clip(reduction, 0.0, 1.0))

            # Utility loss = sum of costs for placed guards
            utility_loss = sum(utility_costs.get(e, 0.0) for e in guard_set)

            results.append({
                "method_name": method_name,
                "blast_radius": result.importance_weighted_radius,
                "blast_radius_reduction": reduction,
                "utility_loss": float(utility_loss),
                "budget_used": result.budget_used,
                "n_guards": len(guard_set),
                "worst_case_radius": result.worst_case_radius,
            })

        return results
