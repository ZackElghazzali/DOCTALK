"""
propagator.metrics.hst
=======================
Heterogeneous Screening Threshold (HST) computation.

HST tests whether the spread of R₀ values across topologies exceeds a
threshold ε_dist, indicating that heterogeneity in model/topology resistance
is large enough to matter for security guarantees.
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# HSTResult
# ---------------------------------------------------------------------------


@dataclass
class HSTResult:
    """
    Result of a single HST computation for one heterogeneity level.

    Attributes
    ----------
    sigma_sq_r : float
        Variance of resistance scores at this heterogeneity level.
    topology_spread : float
        D(σ²) = max_τ R₀(τ) − min_τ R₀(τ)  — range of R₀ values.
    epsilon_dist : float
        Threshold value εdist used for the test.
    threshold_exceeded : bool
        True if topology_spread > epsilon_dist.
    r0_by_topology : dict[str, float]
        R₀ value per topology at this level.
    measurement_power : dict
        Statistical power analysis: effect_size, n_trials, ci_95.
    """

    sigma_sq_r: float
    topology_spread: float
    epsilon_dist: float
    threshold_exceeded: bool
    r0_by_topology: Dict[str, float]
    measurement_power: Dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "sigma_sq_r": self.sigma_sq_r,
            "topology_spread": self.topology_spread,
            "epsilon_dist": self.epsilon_dist,
            "threshold_exceeded": self.threshold_exceeded,
            "r0_by_topology": dict(self.r0_by_topology),
            "measurement_power": dict(self.measurement_power),
        }

    def __repr__(self) -> str:
        exceeded = "EXCEEDED" if self.threshold_exceeded else "ok"
        return (
            f"HSTResult(spread={self.topology_spread:.4f}, "
            f"ε={self.epsilon_dist:.4f}, σ²={self.sigma_sq_r:.4f}, "
            f"threshold={exceeded})"
        )


# ---------------------------------------------------------------------------
# Bootstrap CI helper
# ---------------------------------------------------------------------------


def _bootstrap_ci(
    values: List[float],
    n_bootstrap: int = 500,
    ci_level: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float]:
    """
    Compute a bootstrap confidence interval for the range (max − min)
    of ``values``.

    Parameters
    ----------
    values : list[float]
        The data to bootstrap over.
    n_bootstrap : int
        Number of bootstrap resamples.
    ci_level : float
        Confidence level (e.g. 0.95 for 95% CI).
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    (lower, upper) tuple of floats.
    """
    rng = np.random.default_rng(seed)
    n = len(values)
    if n < 2:
        point = float(values[0]) if values else 0.0
        return point, point

    arr = np.array(values, dtype=float)
    boot_ranges = []
    for _ in range(n_bootstrap):
        sample = rng.choice(arr, size=n, replace=True)
        boot_ranges.append(float(sample.max() - sample.min()))

    alpha = 1.0 - ci_level
    lower = float(np.percentile(boot_ranges, 100 * alpha / 2))
    upper = float(np.percentile(boot_ranges, 100 * (1 - alpha / 2)))
    return lower, upper


# ---------------------------------------------------------------------------
# compute_hst
# ---------------------------------------------------------------------------


def compute_hst(
    r0_by_topology: Dict[str, float],
    resistance_scores_by_level: Dict[str, List[float]],
    epsilon_dist: float = 0.1,
) -> HSTResult:
    """
    Compute the Heterogeneous Screening Threshold for a set of topologies.

    Parameters
    ----------
    r0_by_topology : dict[str, float]
        Mapping from topology name → R₀ value (basic reproduction number /
        propagation rate) at this heterogeneity level.
    resistance_scores_by_level : dict[str, List[float]]
        Mapping from topology name → list of resistance scores at this level.
        Used to compute σ²_r (variance of resistance).
    epsilon_dist : float
        Threshold ε_dist: if topology_spread > epsilon_dist, the threshold
        is exceeded, indicating significant heterogeneity.

    Returns
    -------
    HSTResult

    Notes
    -----
    - If ``r0_by_topology`` is empty, all metrics default to 0.
    - ``measurement_power`` includes:
      - ``effect_size``: topology_spread / epsilon_dist
      - ``n_trials``: total number of resistance scores available
      - ``ci_95``: 95% bootstrap CI on the topology spread as [lower, upper]
    """
    if not r0_by_topology:
        return HSTResult(
            sigma_sq_r=0.0,
            topology_spread=0.0,
            epsilon_dist=epsilon_dist,
            threshold_exceeded=False,
            r0_by_topology={},
            measurement_power={"effect_size": 0.0, "n_trials": 0, "ci_95": [0.0, 0.0]},
        )

    r0_values = list(r0_by_topology.values())

    # Topology spread D(σ²) = max_τ R₀(τ) − min_τ R₀(τ)
    topology_spread = float(max(r0_values) - min(r0_values))
    threshold_exceeded = topology_spread > epsilon_dist

    # σ²_r = variance of resistance scores pooled across topologies
    all_resistance_scores: List[float] = []
    for scores in resistance_scores_by_level.values():
        all_resistance_scores.extend(float(s) for s in scores)

    if len(all_resistance_scores) >= 2:
        sigma_sq_r = float(np.var(all_resistance_scores, ddof=1))
    elif len(all_resistance_scores) == 1:
        sigma_sq_r = 0.0
    else:
        sigma_sq_r = 0.0

    # Measurement power
    effect_size = topology_spread / max(epsilon_dist, 1e-12)
    n_trials = len(all_resistance_scores)

    ci_lower, ci_upper = _bootstrap_ci(r0_values, n_bootstrap=500)

    measurement_power = {
        "effect_size": float(effect_size),
        "n_trials": n_trials,
        "ci_95": [ci_lower, ci_upper],
    }

    return HSTResult(
        sigma_sq_r=sigma_sq_r,
        topology_spread=topology_spread,
        epsilon_dist=epsilon_dist,
        threshold_exceeded=threshold_exceeded,
        r0_by_topology=dict(r0_by_topology),
        measurement_power=measurement_power,
    )


# ---------------------------------------------------------------------------
# sweep_hst
# ---------------------------------------------------------------------------


def sweep_hst(
    r0_by_level: Dict[str, Dict[str, float]],
    resistance_by_level: Dict[str, List[float]],
    epsilon_dist: float = 0.1,
) -> List[HSTResult]:
    """
    Sweep HST computation across multiple heterogeneity levels.

    Parameters
    ----------
    r0_by_level : dict[str, dict[str, float]]
        Outer key: heterogeneity level label (e.g. 'V0', 'V1', 'V2').
        Inner dict: topology_name → R₀ value at that level.
    resistance_by_level : dict[str, list[float]]
        Mapping from heterogeneity level label → list of resistance scores
        for all topologies/agents at that level.
    epsilon_dist : float
        Threshold ε_dist passed to every ``compute_hst`` call.

    Returns
    -------
    list[HSTResult]
        One HSTResult per level, in the order of ``r0_by_level`` keys.

    Notes
    -----
    Levels present in ``r0_by_level`` but absent in ``resistance_by_level``
    are evaluated with an empty resistance list.
    """
    results: List[HSTResult] = []

    for level, r0_by_topology in r0_by_level.items():
        resistance_scores = resistance_by_level.get(level, [])
        # Wrap into the dict-of-lists format expected by compute_hst
        resistance_by_topology: Dict[str, List[float]] = {level: resistance_scores}

        hst = compute_hst(
            r0_by_topology=r0_by_topology,
            resistance_scores_by_level=resistance_by_topology,
            epsilon_dist=epsilon_dist,
        )
        results.append(hst)

    return results
