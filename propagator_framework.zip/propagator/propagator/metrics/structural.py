"""
propagator.metrics.structural
==============================
Structural vulnerability indices for a PropagatorGraph.

Three indices are computed:

1. **Weighted Algebraic Connectivity** (λ̃₂)
   Second-smallest eigenvalue of the weighted Laplacian L_w = D_w - W.
   Higher λ̃₂ → faster propagation / more connected.

2. **Max-Flow Attack Budget** (F)
   For each (entry_point → high-importance) pair, the maximum flow through
   the transmission-weight graph (weights used as capacities).

3. **Minimum Vertex Cut** (κ(G))
   Minimum number of agents that must be removed to disconnect the graph.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, Optional, Set, Tuple

import networkx as nx
import numpy as np

from ..graph import PropagatorGraph

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# StructuralIndices
# ---------------------------------------------------------------------------


@dataclass
class StructuralIndices:
    """
    Container for the three structural vulnerability indices of a graph.

    Attributes
    ----------
    weighted_algebraic_connectivity : float
        λ̃₂ — second-smallest eigenvalue of the weighted Laplacian.
        Higher values indicate faster potential propagation.
    max_flow_budget : dict[(str, str), float]
        Max-flow values for each (source, sink) pair examined.
    max_flow_global : float
        The maximum over all (source, sink) pairs.
    min_vertex_cut : set[str]
        Set of critical node IDs whose removal disconnects the graph.
    min_vertex_cut_size : int
        Cardinality of the minimum vertex cut.
    """

    weighted_algebraic_connectivity: float
    max_flow_budget: Dict[Tuple[str, str], float]
    max_flow_global: float
    min_vertex_cut: Set[str]
    min_vertex_cut_size: int

    @property
    def topology_risk_fingerprint(self) -> dict:
        """
        Return a compact summary dict suitable for logging / comparison.

        Keys
        ----
        lambda2 : float
            Weighted algebraic connectivity.
        max_flow : float
            Global maximum flow budget.
        min_cut_size : int
            Minimum vertex cut size.
        risk_tier : str
            Heuristic risk tier: 'low' | 'medium' | 'high'.
        """
        predicted = predict_prs_from_structural(
            self, n_agents=max(1, len(self.max_flow_budget) + 1)
        )
        if predicted < 0.3:
            risk_tier = "low"
        elif predicted < 0.6:
            risk_tier = "medium"
        else:
            risk_tier = "high"

        return {
            "lambda2": self.weighted_algebraic_connectivity,
            "max_flow": self.max_flow_global,
            "min_cut_size": self.min_vertex_cut_size,
            "predicted_prs": predicted,
            "risk_tier": risk_tier,
        }

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "weighted_algebraic_connectivity": self.weighted_algebraic_connectivity,
            "max_flow_budget": {
                f"{src}->{snk}": val
                for (src, snk), val in self.max_flow_budget.items()
            },
            "max_flow_global": self.max_flow_global,
            "min_vertex_cut": sorted(self.min_vertex_cut),
            "min_vertex_cut_size": self.min_vertex_cut_size,
            "topology_risk_fingerprint": self.topology_risk_fingerprint,
        }

    def __repr__(self) -> str:
        return (
            f"StructuralIndices("
            f"λ̃₂={self.weighted_algebraic_connectivity:.4f}, "
            f"max_flow={self.max_flow_global:.4f}, "
            f"min_cut={self.min_vertex_cut_size})"
        )


# ---------------------------------------------------------------------------
# Weighted Laplacian helpers
# ---------------------------------------------------------------------------


def _build_weighted_adjacency(graph: PropagatorGraph) -> Tuple[np.ndarray, list]:
    """
    Build the weighted adjacency matrix W and node-order list from the graph.

    Parameters
    ----------
    graph : PropagatorGraph

    Returns
    -------
    (W, node_ids) where W.shape = (N, N) and node_ids is the ordered list.
    """
    # Resolve node list: try common attributes
    nodes = _get_nodes(graph)
    node_ids = [_node_id(n) for n in nodes]
    n = len(node_ids)

    if n == 0:
        return np.zeros((0, 0)), []

    idx = {nid: i for i, nid in enumerate(node_ids)}
    W = np.zeros((n, n), dtype=float)

    edges = _get_edges(graph)
    for edge in edges:
        src, tgt, weight = _edge_components(edge)
        if src in idx and tgt in idx:
            W[idx[src], idx[tgt]] += weight

    return W, node_ids


def _weighted_laplacian(W: np.ndarray) -> np.ndarray:
    """
    Compute the weighted Laplacian L_w = D_w - W.

    D_w is the diagonal out-degree matrix: D_ii = Σ_j W_ij.
    For spectral analysis we use the symmetric version on the undirected
    projection (W_sym = (W + Wᵀ) / 2).
    """
    W_sym = (W + W.T) / 2.0
    degrees = W_sym.sum(axis=1)
    D = np.diag(degrees)
    return D - W_sym


def _weighted_algebraic_connectivity(W: np.ndarray) -> float:
    """
    Compute λ̃₂ = second-smallest eigenvalue of the weighted Laplacian.

    Returns 0.0 for graphs with fewer than 2 nodes.
    """
    n = W.shape[0]
    if n < 2:
        return 0.0

    L = _weighted_laplacian(W)
    try:
        eigenvalues = np.linalg.eigvalsh(L)
        eigenvalues_sorted = np.sort(eigenvalues)
        # The smallest eigenvalue should be ~0 (connected component);
        # return the second-smallest.
        if len(eigenvalues_sorted) >= 2:
            return float(max(0.0, eigenvalues_sorted[1]))
        return 0.0
    except np.linalg.LinAlgError as exc:
        logger.warning("Eigenvalue computation failed: %s", exc)
        return 0.0


# ---------------------------------------------------------------------------
# Max-flow helpers
# ---------------------------------------------------------------------------


def _build_networkx_graph(graph: PropagatorGraph) -> nx.DiGraph:
    """Build a NetworkX DiGraph with 'capacity' edge attributes."""
    G = nx.DiGraph()
    nodes = _get_nodes(graph)
    for node in nodes:
        nid = _node_id(node)
        importance = _node_importance(node)
        is_entry = _node_is_entry(node)
        G.add_node(nid, importance=importance, is_entry_point=is_entry)

    edges = _get_edges(graph)
    for edge in edges:
        src, tgt, weight = _edge_components(edge)
        if src in G and tgt in G:
            # If a parallel edge already exists, keep the maximum capacity
            if G.has_edge(src, tgt):
                G[src][tgt]["capacity"] = max(G[src][tgt]["capacity"], weight)
            else:
                G.add_edge(src, tgt, capacity=max(weight, 1e-9))

    return G


def _compute_max_flows(
    G: nx.DiGraph,
    entry_nodes: list,
    target_nodes: list,
    max_pairs: int = 50,
) -> Tuple[Dict[Tuple[str, str], float], float]:
    """
    Compute max-flow for up to ``max_pairs`` (entry → target) pairs.

    Returns
    -------
    (flow_dict, global_max_flow)
    """
    flow_dict: Dict[Tuple[str, str], float] = {}
    global_max = 0.0

    pairs_computed = 0
    for src in entry_nodes:
        for tgt in target_nodes:
            if src == tgt:
                continue
            if pairs_computed >= max_pairs:
                break
            try:
                flow_val, _ = nx.maximum_flow(G, src, tgt, capacity="capacity")
                flow_dict[(src, tgt)] = float(flow_val)
                global_max = max(global_max, float(flow_val))
            except (nx.NetworkXError, nx.exception.NetworkXUnfeasible) as exc:
                logger.debug("max_flow(%s→%s) failed: %s", src, tgt, exc)
                flow_dict[(src, tgt)] = 0.0
            pairs_computed += 1

    return flow_dict, global_max


# ---------------------------------------------------------------------------
# Min vertex cut helpers
# ---------------------------------------------------------------------------


def _compute_min_vertex_cut(G: nx.DiGraph) -> Set[str]:
    """
    Compute the minimum vertex cut using networkx.

    For directed graphs, converts to undirected for connectivity purposes,
    which is conservative (may under-estimate cut for DAGs).
    Falls back gracefully if the graph is already disconnected.
    """
    if len(G) < 2:
        return set()

    UG = G.to_undirected()

    # Already disconnected → cut is empty (no nodes need to be removed)
    if not nx.is_connected(UG):
        return set()

    try:
        cut = nx.minimum_node_cut(UG)
        return {str(n) for n in cut}
    except nx.NetworkXError as exc:
        logger.warning("minimum_node_cut failed: %s", exc)
        return set()


# ---------------------------------------------------------------------------
# Graph attribute accessors (defensive, handles multiple representations)
# ---------------------------------------------------------------------------


def _get_nodes(graph: PropagatorGraph):
    """Return an iterable of node objects from a PropagatorGraph."""
    for attr in ("nodes", "agents", "agent_nodes", "vertices"):
        val = getattr(graph, attr, None)
        if val is not None:
            if callable(val):
                return list(val())
            if hasattr(val, "values"):
                return list(val.values())
            return list(val)
    # Try to iterate the graph directly (some implementations support this)
    try:
        return list(graph)
    except TypeError:
        return []


def _get_edges(graph: PropagatorGraph):
    """Return an iterable of edge objects from a PropagatorGraph."""
    for attr in ("edges", "links", "connections", "agent_edges"):
        val = getattr(graph, attr, None)
        if val is not None:
            if callable(val):
                return list(val())
            if hasattr(val, "values"):
                return list(val.values())
            return list(val)
    return []


def _node_id(node) -> str:
    """Extract string ID from a node object."""
    for attr in ("node_id", "id", "name", "agent_id"):
        val = getattr(node, attr, None)
        if val is not None:
            return str(val)
    return str(node)


def _node_importance(node) -> float:
    """Extract importance/severity from a node object."""
    for attr in ("importance", "severity", "weight", "mu"):
        val = getattr(node, attr, None)
        if val is not None:
            try:
                return float(val)
            except (TypeError, ValueError):
                pass
    return 1.0


def _node_is_entry(node) -> bool:
    """Determine whether a node is an entry point."""
    for attr in ("is_entry_point", "entry_point", "is_entry"):
        val = getattr(node, attr, None)
        if val is not None:
            return bool(val)
    role = getattr(node, "role", None)
    if role is not None:
        role_str = str(role).lower()
        if "entry" in role_str:
            return True
    return False


def _edge_components(edge) -> Tuple[str, str, float]:
    """Extract (source_id, target_id, weight) from an edge object."""
    # Tuple/list representation
    if isinstance(edge, (tuple, list)):
        if len(edge) >= 3:
            return str(edge[0]), str(edge[1]), float(edge[2])
        elif len(edge) == 2:
            return str(edge[0]), str(edge[1]), 1.0

    src = str(
        getattr(edge, "source_id", None)
        or getattr(edge, "source", None)
        or getattr(edge, "src", None)
        or ""
    )
    tgt = str(
        getattr(edge, "target_id", None)
        or getattr(edge, "target", None)
        or getattr(edge, "tgt", None)
        or ""
    )
    weight = float(getattr(edge, "weight", 1.0) or 1.0)
    return src, tgt, weight


# ---------------------------------------------------------------------------
# compute_structural_indices
# ---------------------------------------------------------------------------


def compute_structural_indices(graph: PropagatorGraph) -> StructuralIndices:
    """
    Compute all three structural vulnerability indices for a PropagatorGraph.

    Parameters
    ----------
    graph : PropagatorGraph
        The MAS graph to analyse.

    Returns
    -------
    StructuralIndices

    Notes
    -----
    - For graphs with 0 or 1 nodes, all indices default to safe/trivial values.
    - Disconnected graphs return an empty minimum vertex cut and λ̃₂ = 0.
    - Max-flow computation is limited to at most 50 (entry, target) pairs to
      keep runtime tractable for large graphs.
    """
    nodes = _get_nodes(graph)
    n = len(nodes)

    # Degenerate case
    if n == 0:
        return StructuralIndices(
            weighted_algebraic_connectivity=0.0,
            max_flow_budget={},
            max_flow_global=0.0,
            min_vertex_cut=set(),
            min_vertex_cut_size=0,
        )

    # ---- 1. Weighted Algebraic Connectivity ---------------------------------
    W, node_ids = _build_weighted_adjacency(graph)
    lambda2 = _weighted_algebraic_connectivity(W)

    # ---- 2. Max-Flow Attack Budget ------------------------------------------
    G_nx = _build_networkx_graph(graph)

    entry_nodes = [
        nid for nid in node_ids
        if G_nx.nodes[nid].get("is_entry_point", False)
    ] if node_ids else []

    # High-importance nodes: top 25% by importance, or all if few nodes
    importances = {
        nid: G_nx.nodes[nid].get("importance", 1.0)
        for nid in (node_ids or [])
        if nid in G_nx
    }

    if importances:
        threshold = float(np.percentile(list(importances.values()), 75))
        high_importance = [
            nid for nid, imp in importances.items() if imp >= threshold
        ]
    else:
        high_importance = list(node_ids or [])

    # Fallback: if no entry nodes, use all nodes as potential sources
    if not entry_nodes:
        entry_nodes = list(node_ids[:min(5, len(node_ids))])

    if not high_importance:
        high_importance = list(node_ids[:min(5, len(node_ids))])

    flow_dict, global_max_flow = _compute_max_flows(
        G_nx, entry_nodes, high_importance, max_pairs=50
    )

    # ---- 3. Minimum Vertex Cut ----------------------------------------------
    min_cut = _compute_min_vertex_cut(G_nx)

    return StructuralIndices(
        weighted_algebraic_connectivity=lambda2,
        max_flow_budget=flow_dict,
        max_flow_global=global_max_flow,
        min_vertex_cut=min_cut,
        min_vertex_cut_size=len(min_cut),
    )


# ---------------------------------------------------------------------------
# predict_prs_from_structural
# ---------------------------------------------------------------------------


def predict_prs_from_structural(
    indices: StructuralIndices,
    n_agents: int,
) -> float:
    """
    Predict a PRS value from structural indices via a simple heuristic.

    Formula
    -------
    .. code-block:: none

        prs = 0.3 * (λ̃₂ / n_agents)
            + 0.4 * max_flow_global
            + 0.3 * (1 / max(1, min_vertex_cut_size))

    The result is clamped to [0, 1].

    Parameters
    ----------
    indices : StructuralIndices
        Pre-computed structural indices.
    n_agents : int
        Total number of agents in the topology (denominator for λ̃₂).

    Returns
    -------
    float
        Predicted PRS ∈ [0, 1].
    """
    n = max(1, n_agents)
    lambda2_term = indices.weighted_algebraic_connectivity / n
    max_flow_term = float(np.clip(indices.max_flow_global, 0.0, 1.0))
    cut_term = 1.0 / max(1, indices.min_vertex_cut_size)

    prs = 0.3 * lambda2_term + 0.4 * max_flow_term + 0.3 * cut_term
    return float(np.clip(prs, 0.0, 1.0))
