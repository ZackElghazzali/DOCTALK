"""
propagator.graph.graph
======================
:class:`PropagatorGraph` — the central graph abstraction for PROPAGATOR.

Backed by :class:`networkx.DiGraph`, this class manages the typed directed
weighted graph G = (V, E, H, W, μ, c) and provides all graph-level
analytics required by downstream propagation algorithms.
"""

from __future__ import annotations

import copy
from typing import ClassVar, Dict, List, Optional, Tuple

import networkx as nx
import numpy as np

from .core import (
    AgentEdge,
    AgentNode,
    ContextMode,
    HeterogeneityEmbedding,
    compute_heterogeneity_embedding,
    resistance_score_from_embedding,
)


class PropagatorGraph:
    """
    Typed, directed, weighted graph over LLM agents.

    Attributes
    ----------
    name : str
        Human-readable graph name (used in serialisation / reporting).

    Internal state
    --------------
    _graph : nx.DiGraph
        Underlying NetworkX directed graph.
    _nodes : dict[str, AgentNode]
        Fast node lookup by node_id.
    _edges : dict[tuple[str, str], AgentEdge]
        Fast edge lookup by (source_id, target_id).
    _embeddings : dict[str, HeterogeneityEmbedding]
        Cached heterogeneity embeddings H(v).
    _resistance_scores : dict[str, dict[str, float]]
        Calibrated resistance scores per node per attack type.
        Falls back to embedding-derived estimate when not set.
    """

    # Version tag stored in serialised snapshots
    _SCHEMA_VERSION: ClassVar[str] = "1.0"

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, name: str = "unnamed") -> None:
        self.name: str                                  = name
        self._graph:            nx.DiGraph              = nx.DiGraph()
        self._nodes:            Dict[str, AgentNode]    = {}
        self._edges:            Dict[Tuple[str, str], AgentEdge] = {}
        self._embeddings:       Dict[str, HeterogeneityEmbedding] = {}
        self._resistance_scores: Dict[str, Dict[str, float]]      = {}

    # ------------------------------------------------------------------
    # Node operations
    # ------------------------------------------------------------------

    def add_agent(self, node: AgentNode) -> None:
        """
        Add an :class:`AgentNode` to the graph.

        Computes and caches the heterogeneity embedding for the node.

        Parameters
        ----------
        node : AgentNode
            The agent to add.

        Raises
        ------
        ValueError
            If a node with the same ``node_id`` already exists.
        """
        if node.node_id in self._nodes:
            raise ValueError(
                f"Agent with node_id {node.node_id!r} already exists. "
                "Use remove_agent() first to replace it."
            )
        self._nodes[node.node_id] = node
        self._graph.add_node(
            node.node_id,
            role=node.role.value,
            importance=node.importance,
            hardening_level=node.hardening_level,
            is_entry_point=node.is_entry_point,
        )
        # Compute and cache embedding
        emb = compute_heterogeneity_embedding(node)
        self._embeddings[node.node_id] = emb

    def remove_agent(self, node_id: str) -> None:
        """
        Remove an agent node (and all incident edges) from the graph.

        Parameters
        ----------
        node_id : str
            Identifier of the node to remove.

        Raises
        ------
        KeyError
            If ``node_id`` is not in the graph.
        """
        self._require_node(node_id)
        # Remove all incident edges from internal dict
        to_remove = [
            key for key in self._edges
            if key[0] == node_id or key[1] == node_id
        ]
        for key in to_remove:
            del self._edges[key]
        self._graph.remove_node(node_id)
        del self._nodes[node_id]
        self._embeddings.pop(node_id, None)
        self._resistance_scores.pop(node_id, None)

    def get_agent(self, node_id: str) -> AgentNode:
        """
        Retrieve an :class:`AgentNode` by id.

        Raises
        ------
        KeyError
            If the node is not found.
        """
        self._require_node(node_id)
        return self._nodes[node_id]

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------

    def add_edge(self, edge: AgentEdge) -> None:
        """
        Add a directed communication edge.

        Parameters
        ----------
        edge : AgentEdge
            The edge to add.

        Raises
        ------
        KeyError
            If either endpoint is not in the graph.
        ValueError
            If the edge already exists.
        """
        self._require_node(edge.source_id)
        self._require_node(edge.target_id)
        key = (edge.source_id, edge.target_id)
        if key in self._edges:
            raise ValueError(
                f"Edge {edge.source_id!r} → {edge.target_id!r} already exists. "
                "Remove it first."
            )
        self._edges[key] = edge
        self._graph.add_edge(
            edge.source_id,
            edge.target_id,
            weight=edge.weight,
            context_mode=edge.context_mode.value,
        )

    def remove_edge(self, source_id: str, target_id: str) -> None:
        """
        Remove a directed edge.

        Raises
        ------
        KeyError
            If the edge does not exist.
        """
        key = (source_id, target_id)
        if key not in self._edges:
            raise KeyError(
                f"Edge {source_id!r} → {target_id!r} not found."
            )
        del self._edges[key]
        self._graph.remove_edge(source_id, target_id)

    def get_edge(self, source_id: str, target_id: str) -> AgentEdge:
        """
        Retrieve an :class:`AgentEdge` by endpoint ids.

        Raises
        ------
        KeyError
            If the edge is not found.
        """
        key = (source_id, target_id)
        if key not in self._edges:
            raise KeyError(
                f"Edge {source_id!r} → {target_id!r} not found."
            )
        return self._edges[key]

    # ------------------------------------------------------------------
    # Neighbourhood queries
    # ------------------------------------------------------------------

    def get_neighbors(self, node_id: str) -> List[str]:
        """
        Return the list of outgoing (successor) neighbour ids.

        Parameters
        ----------
        node_id : str
            Source node.
        """
        self._require_node(node_id)
        return list(self._graph.successors(node_id))

    def get_predecessors(self, node_id: str) -> List[str]:
        """
        Return the list of incoming (predecessor) neighbour ids.

        Parameters
        ----------
        node_id : str
            Target node.
        """
        self._require_node(node_id)
        return list(self._graph.predecessors(node_id))

    # ------------------------------------------------------------------
    # Resistance scores
    # ------------------------------------------------------------------

    def set_resistance_score(
        self,
        node_id: str,
        attack_type: str,
        score: float,
    ) -> None:
        """
        Set a calibrated resistance score r_i for *node_id* against *attack_type*.

        Parameters
        ----------
        node_id : str
            Agent node identifier.
        attack_type : str
            Arbitrary attack-type label (e.g. ``"prompt_injection"``).
        score : float
            Resistance value ∈ [0, 1].

        Raises
        ------
        KeyError
            If *node_id* is not in the graph.
        ValueError
            If *score* is outside [0, 1].
        """
        self._require_node(node_id)
        if not (0.0 <= score <= 1.0):
            raise ValueError(f"Resistance score must be in [0, 1]; got {score!r}")
        self._resistance_scores.setdefault(node_id, {})[attack_type] = score

    def get_resistance_score(
        self,
        node_id: str,
        attack_type: str,
    ) -> float:
        """
        Get the resistance score r_i for *node_id* against *attack_type*.

        Returns the calibrated value if one has been set via
        :meth:`set_resistance_score`, otherwise falls back to the
        embedding-derived estimate via :func:`resistance_score_from_embedding`.

        Parameters
        ----------
        node_id : str
            Agent node identifier.
        attack_type : str
            Attack-type label.

        Returns
        -------
        float
            Resistance score ∈ [0, 1].
        """
        self._require_node(node_id)
        calibrated = self._resistance_scores.get(node_id, {})
        if attack_type in calibrated:
            return calibrated[attack_type]
        # Fallback: embedding-based estimate
        emb = self._embeddings[node_id]
        node = self._nodes[node_id]
        return resistance_score_from_embedding(emb, node.hardening_level)

    # ------------------------------------------------------------------
    # Transmission probability
    # ------------------------------------------------------------------

    def transmission_probability(
        self,
        source_id: str,
        target_id: str,
        attack_type: str,
        semantic_similarity: float = 1.0,
    ) -> float:
        """
        Compute the transmission probability p_{ij} along edge (i → j).

        Formula
        -------
        .. code-block:: none

            p_ij = (1 - r_j) * s_ij * w_ij

        where:
          - r_j  = resistance score of the target node for *attack_type*
          - s_ij = ``semantic_similarity`` (payload relevance to target context)
          - w_ij = edge weight W(e)

        If ``context_mode`` on the edge is :attr:`ContextMode.SHARED`, the
        result is multiplied by 1.2 (full shared context amplifies propagation),
        capped at 1.0.

        Parameters
        ----------
        source_id : str
            Origin agent.
        target_id : str
            Destination agent.
        attack_type : str
            Attack type label for resistance lookup.
        semantic_similarity : float
            Semantic similarity s_{ij} ∈ [0, 1]. Defaults to 1.0
            (worst-case / fully relevant payload).

        Returns
        -------
        float
            Transmission probability ∈ [0, 1].

        Raises
        ------
        KeyError
            If the edge does not exist.
        ValueError
            If *semantic_similarity* is outside [0, 1].
        """
        if not (0.0 <= semantic_similarity <= 1.0):
            raise ValueError(
                f"semantic_similarity must be in [0, 1]; got {semantic_similarity!r}"
            )
        edge = self.get_edge(source_id, target_id)
        r_j = self.get_resistance_score(target_id, attack_type)
        w_ij = edge.weight
        s_ij = semantic_similarity

        p = (1.0 - r_j) * s_ij * w_ij

        if edge.context_mode == ContextMode.SHARED:
            p = min(1.0, p * 1.2)

        return float(p)

    # ------------------------------------------------------------------
    # Matrix representations
    # ------------------------------------------------------------------

    def adjacency_matrix(self, weighted: bool = True) -> np.ndarray:
        """
        Return the (ordered) adjacency matrix of the graph.

        Parameters
        ----------
        weighted : bool
            If True (default), entry A[i,j] = transmission weight W(e_{ij}).
            If False, A[i,j] ∈ {0, 1}.

        Returns
        -------
        np.ndarray
            Square matrix of shape (|V|, |V|).
        """
        node_ids = self.node_ids()
        n = len(node_ids)
        idx = {nid: i for i, nid in enumerate(node_ids)}
        A = np.zeros((n, n), dtype=float)
        for (src, tgt), edge in self._edges.items():
            i, j = idx[src], idx[tgt]
            A[i, j] = edge.weight if weighted else 1.0
        return A

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def heterogeneity_variance(self) -> float:
        """
        Compute the variance σ²(r) of resistance scores across all nodes.

        If calibrated scores are available (for any attack type), uses
        the mean resistance per node and then computes variance across nodes.
        Otherwise falls back to embedding-derived scores.

        Returns
        -------
        float
            Variance of per-node resistance estimates.
        """
        node_ids = self.node_ids()
        if not node_ids:
            return 0.0

        scores: List[float] = []
        for nid in node_ids:
            calibrated = self._resistance_scores.get(nid, {})
            if calibrated:
                # Average over all attack types for this node
                node_score = float(np.mean(list(calibrated.values())))
            else:
                emb = self._embeddings[nid]
                node = self._nodes[nid]
                node_score = resistance_score_from_embedding(emb, node.hardening_level)
            scores.append(node_score)

        return float(np.var(scores))

    # ------------------------------------------------------------------
    # Collection accessors
    # ------------------------------------------------------------------

    def node_ids(self) -> List[str]:
        """Return all node ids in insertion order."""
        return list(self._nodes.keys())

    def edge_list(self) -> List[Tuple[str, str]]:
        """Return all (source, target) edge pairs."""
        return list(self._edges.keys())

    def get_embedding(self, node_id: str) -> HeterogeneityEmbedding:
        """
        Return the cached heterogeneity embedding for *node_id*.

        Raises
        ------
        KeyError
            If *node_id* is not in the graph.
        """
        self._require_node(node_id)
        return self._embeddings[node_id]

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Return a JSON-serialisable snapshot of the graph.

        The snapshot includes all nodes, edges, embeddings, and calibrated
        resistance scores so that the graph can be fully reconstructed.
        """
        return {
            "_schema_version": self._SCHEMA_VERSION,
            "name":  self.name,
            "nodes": [n.to_dict() for n in self._nodes.values()],
            "edges": [e.to_dict() for e in self._edges.values()],
            "embeddings": {
                nid: emb.to_dict()
                for nid, emb in self._embeddings.items()
            },
            "resistance_scores": {
                nid: dict(scores)
                for nid, scores in self._resistance_scores.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict) -> "PropagatorGraph":
        """
        Reconstruct a :class:`PropagatorGraph` from a previously serialised dict.

        Parameters
        ----------
        data : dict
            Dict as produced by :meth:`to_dict`.

        Returns
        -------
        PropagatorGraph
            Fully reconstructed graph (embeddings re-loaded from stored values,
            not recomputed, to preserve calibrated divergences).
        """
        graph = cls(name=data.get("name", "unnamed"))

        # Re-add nodes (do not recompute embeddings yet — will restore below)
        for node_data in data.get("nodes", []):
            node = AgentNode.from_dict(node_data)
            # Add without triggering embedding computation
            graph._nodes[node.node_id] = node
            graph._graph.add_node(
                node.node_id,
                role=node.role.value,
                importance=node.importance,
                hardening_level=node.hardening_level,
                is_entry_point=node.is_entry_point,
            )

        # Restore stored embeddings
        for nid, emb_data in data.get("embeddings", {}).items():
            graph._embeddings[nid] = HeterogeneityEmbedding.from_dict(emb_data)

        # Fill any missing embeddings (e.g. partial snapshots)
        for nid, node in graph._nodes.items():
            if nid not in graph._embeddings:
                graph._embeddings[nid] = compute_heterogeneity_embedding(node)

        # Re-add edges
        for edge_data in data.get("edges", []):
            edge = AgentEdge.from_dict(edge_data)
            key = (edge.source_id, edge.target_id)
            graph._edges[key] = edge
            graph._graph.add_edge(
                edge.source_id,
                edge.target_id,
                weight=edge.weight,
                context_mode=edge.context_mode.value,
            )

        # Restore calibrated resistance scores
        for nid, scores in data.get("resistance_scores", {}).items():
            graph._resistance_scores[nid] = dict(scores)

        return graph

    def copy(self) -> "PropagatorGraph":
        """Return a deep copy of this graph."""
        return PropagatorGraph.from_dict(self.to_dict())

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._nodes)

    def __contains__(self, node_id: str) -> bool:
        return node_id in self._nodes

    def __repr__(self) -> str:
        return (
            f"PropagatorGraph(name={self.name!r}, "
            f"nodes={len(self._nodes)}, edges={len(self._edges)})"
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _require_node(self, node_id: str) -> None:
        """Raise :class:`KeyError` if *node_id* is not in the graph."""
        if node_id not in self._nodes:
            raise KeyError(
                f"Agent {node_id!r} not found in graph {self.name!r}. "
                f"Known nodes: {list(self._nodes.keys())}"
            )
