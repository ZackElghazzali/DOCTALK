"""
propagator.graph
================
Topology-aware graph model for the PROPAGATOR framework.

Formalises a multi-agent LLM system as a typed directed weighted graph
G = (V, E, H, W, μ, c) and provides:

* Core data types (:class:`AgentNode`, :class:`AgentEdge`,
  :class:`HeterogeneityEmbedding`, enumerations).
* :class:`PropagatorGraph` — the central graph class backed by NetworkX.
* :class:`TopologyFactory` — factory methods for 8 canonical MAS topologies.
* Utility functions: :func:`compute_heterogeneity_embedding`,
  :func:`resistance_score_from_embedding`.

Quick start
-----------
>>> from propagator.graph import TopologyFactory, PropagatorGraph
>>> g = TopologyFactory.chain(n=4)
>>> g.transmission_probability("agent_0", "agent_1", attack_type="prompt_injection")
"""

from .core import (
    AgentEdge,
    AgentNode,
    AgentRole,
    ContextMode,
    FineTuningDomain,
    HeterogeneityEmbedding,
    ImportanceTier,
    ModelFamily,
    TOOL_ACCESS_KEYS,
    compute_heterogeneity_embedding,
    resistance_score_from_embedding,
)
from .graph import PropagatorGraph
from .topologies import TopologyFactory

__all__ = [
    # Enumerations
    "AgentRole",
    "ModelFamily",
    "FineTuningDomain",
    "ContextMode",
    "ImportanceTier",
    # Data classes
    "AgentNode",
    "AgentEdge",
    "HeterogeneityEmbedding",
    # Graph
    "PropagatorGraph",
    # Factory
    "TopologyFactory",
    # Functions
    "compute_heterogeneity_embedding",
    "resistance_score_from_embedding",
    # Constants
    "TOOL_ACCESS_KEYS",
]
