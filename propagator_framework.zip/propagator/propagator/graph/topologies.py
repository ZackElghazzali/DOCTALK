"""
propagator.graph.topologies
============================
:class:`TopologyFactory` — factory methods for the 8 canonical MAS topologies.

Each method returns a fully initialised :class:`~propagator.graph.graph.PropagatorGraph`
whose nodes have varied hardening levels and model families so that the
heterogeneity embedding is non-trivial out of the box.
"""

from __future__ import annotations

import random
from itertools import product
from typing import Dict, List, Optional

from .core import (
    AgentEdge,
    AgentNode,
    AgentRole,
    ContextMode,
    FineTuningDomain,
    ImportanceTier,
    ModelFamily,
)
from .graph import PropagatorGraph

# ---------------------------------------------------------------------------
# Default node-generation helpers
# ---------------------------------------------------------------------------

# Cycle through these so that default graphs are heterogeneous
_DEFAULT_MODEL_FAMILIES: List[ModelFamily] = [
    ModelFamily.GPT4O,
    ModelFamily.CLAUDE35,
    ModelFamily.LLAMA33,
    ModelFamily.GEMMA2,
    ModelFamily.QWEN25,
    ModelFamily.MISTRAL,
    ModelFamily.GEMMA,
    ModelFamily.CUSTOM,
]

_DEFAULT_DOMAINS: List[FineTuningDomain] = [
    FineTuningDomain.GENERAL,
    FineTuningDomain.CODE,
    FineTuningDomain.LEGAL,
    FineTuningDomain.MEDICAL,
    FineTuningDomain.FINANCIAL,
    FineTuningDomain.CUSTOM,
]

_HARDENING_CYCLE = [0, 1, 2, 0, 1, 2]


def _make_default_node(
    node_id: str,
    index: int,
    role: AgentRole = AgentRole.SPECIALIST,
    importance: Optional[float] = None,
    is_entry_point: bool = False,
    hardening_level: Optional[int] = None,
    model_family: Optional[ModelFamily] = None,
    fine_tuning_domain: Optional[FineTuningDomain] = None,
    system_prompt: str = "",
    tool_access: Optional[Dict[str, bool]] = None,
    extra_metadata: Optional[Dict] = None,
) -> AgentNode:
    """Construct a default :class:`AgentNode` with varied properties."""
    mf  = model_family      or _DEFAULT_MODEL_FAMILIES[index % len(_DEFAULT_MODEL_FAMILIES)]
    ft  = fine_tuning_domain or _DEFAULT_DOMAINS[index % len(_DEFAULT_DOMAINS)]
    hl  = hardening_level   if hardening_level is not None else _HARDENING_CYCLE[index % 3]
    imp = importance        if importance is not None else float(ImportanceTier.READ_ONLY)
    return AgentNode(
        node_id=node_id,
        role=role,
        model_family=mf,
        system_prompt=system_prompt or f"System prompt for agent {node_id}.",
        fine_tuning_domain=ft,
        tool_access=tool_access or {},
        importance=imp,
        is_entry_point=is_entry_point,
        hardening_level=hl,
        metadata=extra_metadata or {},
    )


def _node_from_config(
    node_id: str,
    index: int,
    cfg: Optional[Dict],
) -> AgentNode:
    """
    Build a node from an optional config dict.

    *cfg* may contain any of: node_id (overrides), role, model_family,
    importance, hardening_level, is_entry_point, fine_tuning_domain,
    system_prompt, tool_access, metadata.
    Unspecified fields fall back to :func:`_make_default_node` defaults.
    """
    if cfg is None:
        return _make_default_node(node_id, index)

    resolved_id = cfg.get("node_id", node_id)

    role = AgentRole(cfg["role"]) if "role" in cfg else AgentRole.SPECIALIST
    mf   = ModelFamily(cfg["model_family"]) if "model_family" in cfg else None
    ft   = FineTuningDomain(cfg["fine_tuning_domain"]) if "fine_tuning_domain" in cfg else None
    hl   = cfg.get("hardening_level")
    imp  = cfg.get("importance")
    ep   = bool(cfg.get("is_entry_point", False))
    sp   = cfg.get("system_prompt", "")
    ta   = cfg.get("tool_access")
    meta = cfg.get("metadata", {})

    return _make_default_node(
        node_id=resolved_id,
        index=index,
        role=role,
        importance=imp,
        is_entry_point=ep,
        hardening_level=hl,
        model_family=mf,
        fine_tuning_domain=ft,
        system_prompt=sp,
        tool_access=ta,
        extra_metadata=meta,
    )


def _build_nodes(
    node_ids: List[str],
    agent_configs: Optional[List[Optional[Dict]]],
) -> List[AgentNode]:
    """Zip node_ids with optional config dicts."""
    configs = agent_configs or [None] * len(node_ids)
    # Pad/trim to match node_ids length
    while len(configs) < len(node_ids):
        configs.append(None)
    return [
        _node_from_config(nid, i, cfg)
        for i, (nid, cfg) in enumerate(zip(node_ids, configs))
    ]


def _add_edge(
    graph: PropagatorGraph,
    source: str,
    target: str,
    weight: float = 1.0,
    context_mode: ContextMode = ContextMode.LOCAL,
) -> None:
    """Convenience wrapper to add an :class:`AgentEdge`."""
    graph.add_edge(
        AgentEdge(
            source_id=source,
            target_id=target,
            weight=weight,
            context_mode=context_mode,
        )
    )


# ---------------------------------------------------------------------------
# TopologyFactory
# ---------------------------------------------------------------------------

class TopologyFactory:
    """
    Factory class providing class methods for generating canonical MAS topologies.

    All methods return a :class:`~propagator.graph.graph.PropagatorGraph` that is
    ready for use with propagation algorithms.

    When ``agent_configs`` is provided, each element is a dict with any of:
    ``node_id``, ``role``, ``model_family``, ``importance``, ``hardening_level``,
    ``is_entry_point``, ``fine_tuning_domain``, ``system_prompt``, ``tool_access``,
    ``metadata``.  Missing fields are filled with heterogeneous defaults.
    """

    # ------------------------------------------------------------------
    # 1. Chain
    # ------------------------------------------------------------------

    @classmethod
    def chain(
        cls,
        n: int,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Linear chain topology: v₀ → v₁ → … → v_{n-1}.

        Parameters
        ----------
        n : int
            Number of agents (≥ 2).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.

        Returns
        -------
        PropagatorGraph
        """
        if n < 2:
            raise ValueError(f"Chain topology requires n ≥ 2; got {n}")

        node_ids = [f"agent_{i}" for i in range(n)]
        graph = PropagatorGraph(name=f"chain_n{n}")
        nodes = _build_nodes(node_ids, agent_configs)
        # Mark first node as entry point
        nodes[0].is_entry_point = True

        for node in nodes:
            graph.add_agent(node)

        for i in range(n - 1):
            _add_edge(graph, node_ids[i], node_ids[i + 1])

        return graph

    # ------------------------------------------------------------------
    # 2. Star
    # ------------------------------------------------------------------

    @classmethod
    def star(
        cls,
        n_leaves: int,
        bidirectional: bool = True,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Star topology with a central hub and *n_leaves* leaf nodes.

        Node ids: hub = ``"hub"``, leaves = ``"leaf_0"`` … ``"leaf_{n-1}"``.

        Parameters
        ----------
        n_leaves : int
            Number of leaf agents (≥ 1).
        bidirectional : bool
            If True (default), add edges in both directions (hub ↔ leaf).
            If False, only hub → leaf edges are added.
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.
            First element maps to the hub; remaining to leaves in order.

        Returns
        -------
        PropagatorGraph
        """
        if n_leaves < 1:
            raise ValueError(f"Star topology requires n_leaves ≥ 1; got {n_leaves}")

        hub_id = "hub"
        leaf_ids = [f"leaf_{i}" for i in range(n_leaves)]
        all_ids = [hub_id] + leaf_ids

        graph = PropagatorGraph(name=f"star_n{n_leaves}")
        nodes = _build_nodes(all_ids, agent_configs)

        # Hub is the orchestrator
        nodes[0].role = AgentRole.ORCHESTRATOR
        nodes[0].importance = float(ImportanceTier.CODE_EXECUTION)

        for node in nodes:
            graph.add_agent(node)

        for leaf_id in leaf_ids:
            _add_edge(graph, hub_id, leaf_id)
            if bidirectional:
                _add_edge(graph, leaf_id, hub_id)

        return graph

    # ------------------------------------------------------------------
    # 3. Ring
    # ------------------------------------------------------------------

    @classmethod
    def ring(
        cls,
        n: int,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Ring topology: each node connects to the next, with a wrap-around edge.

        v₀ → v₁ → … → v_{n-1} → v₀

        Parameters
        ----------
        n : int
            Number of agents (≥ 3).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.

        Returns
        -------
        PropagatorGraph
        """
        if n < 3:
            raise ValueError(f"Ring topology requires n ≥ 3; got {n}")

        node_ids = [f"agent_{i}" for i in range(n)]
        graph = PropagatorGraph(name=f"ring_n{n}")
        nodes = _build_nodes(node_ids, agent_configs)

        for node in nodes:
            graph.add_agent(node)

        for i in range(n):
            _add_edge(graph, node_ids[i], node_ids[(i + 1) % n])

        return graph

    # ------------------------------------------------------------------
    # 4. Complete (Clique)
    # ------------------------------------------------------------------

    @classmethod
    def complete(
        cls,
        n: int,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Complete (clique) topology: directed all-to-all edges (excluding self-loops).

        Parameters
        ----------
        n : int
            Number of agents (≥ 2).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.

        Returns
        -------
        PropagatorGraph
        """
        if n < 2:
            raise ValueError(f"Complete topology requires n ≥ 2; got {n}")

        node_ids = [f"agent_{i}" for i in range(n)]
        graph = PropagatorGraph(name=f"complete_n{n}")
        nodes = _build_nodes(node_ids, agent_configs)

        for node in nodes:
            graph.add_agent(node)

        for i, j in product(range(n), range(n)):
            if i != j:
                _add_edge(
                    graph,
                    node_ids[i],
                    node_ids[j],
                    context_mode=ContextMode.SHARED,
                )

        return graph

    # ------------------------------------------------------------------
    # 5. Tree
    # ------------------------------------------------------------------

    @classmethod
    def tree(
        cls,
        n: int,
        branching_factor: int = 2,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Hierarchical tree (DAG) built BFS-style with a given branching factor.

        The root node is ``"agent_0"``.

        Parameters
        ----------
        n : int
            Total number of agents (≥ 2).
        branching_factor : int
            Maximum children per parent node (default 2 = binary tree).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.

        Returns
        -------
        PropagatorGraph
        """
        if n < 2:
            raise ValueError(f"Tree topology requires n ≥ 2; got {n}")
        if branching_factor < 1:
            raise ValueError(f"branching_factor must be ≥ 1; got {branching_factor}")

        node_ids = [f"agent_{i}" for i in range(n)]
        graph = PropagatorGraph(name=f"tree_n{n}_b{branching_factor}")
        nodes = _build_nodes(node_ids, agent_configs)

        # Root is orchestrator
        nodes[0].role = AgentRole.ORCHESTRATOR
        nodes[0].importance = float(ImportanceTier.CODE_EXECUTION)

        for node in nodes:
            graph.add_agent(node)

        # BFS-build edges
        for parent_idx in range(n):
            for k in range(branching_factor):
                child_idx = parent_idx * branching_factor + k + 1
                if child_idx >= n:
                    break
                _add_edge(graph, node_ids[parent_idx], node_ids[child_idx])

        return graph

    # ------------------------------------------------------------------
    # 6. Star-Ring
    # ------------------------------------------------------------------

    @classmethod
    def star_ring(
        cls,
        n_leaves: int,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Star-Ring topology: a central hub with bidirectional spoke edges
        **plus** a directed ring connecting all leaf nodes.

        Parameters
        ----------
        n_leaves : int
            Number of leaf agents (≥ 3 for a meaningful ring).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.
            First element maps to the hub.

        Returns
        -------
        PropagatorGraph
        """
        if n_leaves < 3:
            raise ValueError(
                f"Star-Ring topology requires n_leaves ≥ 3 for a ring; got {n_leaves}"
            )

        hub_id = "hub"
        leaf_ids = [f"leaf_{i}" for i in range(n_leaves)]
        all_ids = [hub_id] + leaf_ids

        graph = PropagatorGraph(name=f"star_ring_n{n_leaves}")
        nodes = _build_nodes(all_ids, agent_configs)

        nodes[0].role = AgentRole.ORCHESTRATOR
        nodes[0].importance = float(ImportanceTier.CODE_EXECUTION)

        for node in nodes:
            graph.add_agent(node)

        # Star edges (bidirectional)
        for leaf_id in leaf_ids:
            _add_edge(graph, hub_id, leaf_id)
            _add_edge(graph, leaf_id, hub_id)

        # Ring edges on leaves
        for i in range(n_leaves):
            _add_edge(
                graph,
                leaf_ids[i],
                leaf_ids[(i + 1) % n_leaves],
            )

        return graph

    # ------------------------------------------------------------------
    # 7. Layered DAG
    # ------------------------------------------------------------------

    @classmethod
    def layered_dag(
        cls,
        n_layers: int,
        layer_width: int,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Layered directed acyclic graph.

        Each node in layer *l* has directed edges to every node in layer *l+1*.
        Total nodes = ``n_layers * layer_width``.

        Parameters
        ----------
        n_layers : int
            Number of layers (≥ 2).
        layer_width : int
            Number of agents per layer (≥ 1).
        agent_configs : list[dict] | None
            Optional per-node configuration dicts (row-major: layer 0 first).

        Returns
        -------
        PropagatorGraph
        """
        if n_layers < 2:
            raise ValueError(f"Layered DAG requires n_layers ≥ 2; got {n_layers}")
        if layer_width < 1:
            raise ValueError(f"layer_width must be ≥ 1; got {layer_width}")

        # Build node ids: "l0_0", "l0_1", ..., "l{n-1}_{w-1}"
        node_ids: List[str] = []
        for layer in range(n_layers):
            for pos in range(layer_width):
                node_ids.append(f"l{layer}_{pos}")

        graph = PropagatorGraph(
            name=f"layered_dag_layers{n_layers}_w{layer_width}"
        )
        nodes = _build_nodes(node_ids, agent_configs)

        # First layer nodes are entry points / orchestrators
        for pos in range(layer_width):
            nodes[pos].is_entry_point = True
            nodes[pos].role = AgentRole.ORCHESTRATOR

        for node in nodes:
            graph.add_agent(node)

        # Layer-to-layer all-to-all edges
        for layer in range(n_layers - 1):
            for src_pos in range(layer_width):
                src_id = f"l{layer}_{src_pos}"
                for tgt_pos in range(layer_width):
                    tgt_id = f"l{layer + 1}_{tgt_pos}"
                    _add_edge(graph, src_id, tgt_id)

        return graph

    # ------------------------------------------------------------------
    # 8. Decentralised Mesh (Erdős–Rényi)
    # ------------------------------------------------------------------

    @classmethod
    def decentralized_mesh(
        cls,
        n: int,
        p: float = 0.3,
        seed: Optional[int] = None,
        agent_configs: Optional[List[Optional[Dict]]] = None,
    ) -> PropagatorGraph:
        """
        Sparse random directed graph (Erdős–Rényi G(n, p) for directed edges).

        Each ordered pair (i, j) with i ≠ j is included as an edge with
        probability *p*.  A seeded RNG ensures reproducibility.

        Parameters
        ----------
        n : int
            Number of agents (≥ 2).
        p : float
            Edge probability ∈ (0, 1).  Default 0.3.
        seed : int | None
            RNG seed for reproducibility.
        agent_configs : list[dict] | None
            Optional per-node configuration dicts.

        Returns
        -------
        PropagatorGraph
        """
        if n < 2:
            raise ValueError(f"Mesh topology requires n ≥ 2; got {n}")
        if not (0.0 < p <= 1.0):
            raise ValueError(f"Edge probability p must be in (0, 1]; got {p}")

        rng = random.Random(seed)
        node_ids = [f"agent_{i}" for i in range(n)]
        graph = PropagatorGraph(name=f"mesh_n{n}_p{p:.2f}")
        nodes = _build_nodes(node_ids, agent_configs)

        for node in nodes:
            graph.add_agent(node)

        for i in range(n):
            for j in range(n):
                if i != j and rng.random() < p:
                    _add_edge(graph, node_ids[i], node_ids[j])

        return graph

    # ------------------------------------------------------------------
    # Convenience: all 8 canonical topologies
    # ------------------------------------------------------------------

    @classmethod
    def all_canonical(cls, n: int = 6) -> Dict[str, PropagatorGraph]:
        """
        Generate all 8 canonical topologies with *n* agents each
        (or the closest valid configuration).

        Parameters
        ----------
        n : int
            Target number of agents per topology.  Some topologies
            impose structural constraints (e.g. ring requires ≥ 3,
            star-ring requires ≥ 3 leaves).  The value is clamped/
            adjusted automatically.

        Returns
        -------
        dict[str, PropagatorGraph]
            Keys are topology names:
            ``chain``, ``star``, ``ring``, ``complete``,
            ``tree``, ``star_ring``, ``layered_dag``, ``decentralized_mesh``.
        """
        n = max(n, 4)  # ensure enough nodes for all topologies

        # Layered DAG: try to split n into (n_layers=2, layer_width)
        n_layers = 2
        layer_width = max(1, n // n_layers)

        return {
            "chain":              cls.chain(n=n),
            "star":               cls.star(n_leaves=n - 1),  # hub + n-1 leaves = n
            "ring":               cls.ring(n=n),
            "complete":           cls.complete(n=n),
            "tree":               cls.tree(n=n, branching_factor=2),
            "star_ring":          cls.star_ring(n_leaves=max(3, n - 1)),
            "layered_dag":        cls.layered_dag(
                                      n_layers=n_layers,
                                      layer_width=layer_width,
                                  ),
            "decentralized_mesh": cls.decentralized_mesh(n=n, p=0.3, seed=42),
        }
