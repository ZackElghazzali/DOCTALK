"""
propagator.graph.core
=====================
Core data types for the PROPAGATOR framework's graph model.

Formalises the typed directed weighted graph G = (V, E, H, W, μ, c) where:
  V  — agent nodes
  E  — directed communication edges
  H  — per-agent heterogeneity embedding
  W  — per-edge transmission weight
  μ  — per-node importance / severity
  c  — per-edge context-sharing mode
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from math import sqrt
from typing import Dict, List, Optional

import numpy as np

# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class AgentRole(str, Enum):
    """Functional role of an agent node in the MAS."""
    ORCHESTRATOR = "orchestrator"
    SPECIALIST    = "specialist"
    MONITOR       = "monitor"
    ENTRY_POINT   = "entry_point"
    EGRESS        = "egress"
    LIGHTWEIGHT   = "lightweight"


class ModelFamily(str, Enum):
    """Known LLM families / base-model identities."""
    GPT4O    = "gpt4o"
    CLAUDE35 = "claude35"
    LLAMA33  = "llama33"
    GEMMA2   = "gemma2"
    QWEN25   = "qwen25"
    MISTRAL  = "mistral"
    GEMMA    = "gemma"
    CUSTOM   = "custom"


class FineTuningDomain(str, Enum):
    """Fine-tuning domain of the agent's underlying model."""
    GENERAL   = "general"
    MEDICAL   = "medical"
    LEGAL     = "legal"
    CODE      = "code"
    FINANCIAL = "financial"
    CUSTOM    = "custom"


class ContextMode(str, Enum):
    """Context-sharing mode for a directed communication edge."""
    SHARED = "shared"
    LOCAL  = "local"
    HYBRID = "hybrid"


class ImportanceTier(IntEnum):
    """
    Importance / severity tiers (μ) for agent nodes.

    Higher value ⟹ greater blast radius if compromised.
    """
    EXTERNAL_EGRESS = 4
    CODE_EXECUTION  = 3
    DATA_WRITE      = 2
    READ_ONLY       = 1


# ---------------------------------------------------------------------------
# Tool-access key order (canonical, used for binary vector construction)
# ---------------------------------------------------------------------------

TOOL_ACCESS_KEYS: List[str] = [
    "web_search",
    "code_execution",
    "file_io",
    "api_calls",
    "db_read",
    "db_write",
    "external_egress",
]

_MODEL_FAMILY_ORDER: List[str] = [f.value for f in ModelFamily]
_FINE_TUNING_DOMAIN_ORDER: List[str] = [f.value for f in FineTuningDomain]


# ---------------------------------------------------------------------------
# AgentNode
# ---------------------------------------------------------------------------

@dataclass
class AgentNode:
    """
    A node in the MAS graph representing a single LLM agent.

    Attributes
    ----------
    node_id : str
        Unique identifier for this agent.
    role : AgentRole
        Functional role within the multi-agent system.
    model_family : ModelFamily
        Base-model identity / LLM family.
    system_prompt : str
        The agent's system prompt text.
    fine_tuning_domain : FineTuningDomain
        Domain in which the model was fine-tuned (if at all).
    tool_access : dict[str, bool]
        Binary map over the seven canonical tool categories:
        web_search, code_execution, file_io, api_calls,
        db_read, db_write, external_egress.
    importance : float
        Scalar importance / severity μ(v) ≥ 0.
    is_entry_point : bool
        True if this node receives external (untrusted) input.
    hardening_level : int
        Security hardening tier: 0 = V0 (none), 1 = V1, 2 = V2.
    metadata : dict
        Arbitrary key-value annotations.
    """

    node_id:           str
    role:              AgentRole             = AgentRole.SPECIALIST
    model_family:      ModelFamily           = ModelFamily.CUSTOM
    system_prompt:     str                   = ""
    fine_tuning_domain: FineTuningDomain     = FineTuningDomain.GENERAL
    tool_access:       Dict[str, bool]       = field(default_factory=dict)
    importance:        float                 = float(ImportanceTier.READ_ONLY)
    is_entry_point:    bool                  = False
    hardening_level:   int                   = 0
    metadata:          Dict                  = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Validate hardening level
        if self.hardening_level not in (0, 1, 2):
            raise ValueError(
                f"hardening_level must be 0, 1, or 2; got {self.hardening_level!r}"
            )
        # Fill missing tool keys with False
        for key in TOOL_ACCESS_KEYS:
            self.tool_access.setdefault(key, False)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "node_id":            self.node_id,
            "role":               self.role.value,
            "model_family":       self.model_family.value,
            "system_prompt":      self.system_prompt,
            "fine_tuning_domain": self.fine_tuning_domain.value,
            "tool_access":        dict(self.tool_access),
            "importance":         self.importance,
            "is_entry_point":     self.is_entry_point,
            "hardening_level":    self.hardening_level,
            "metadata":           dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AgentNode":
        """Reconstruct an :class:`AgentNode` from a dict (e.g. JSON)."""
        return cls(
            node_id=            data["node_id"],
            role=               AgentRole(data.get("role", AgentRole.SPECIALIST.value)),
            model_family=       ModelFamily(data.get("model_family", ModelFamily.CUSTOM.value)),
            system_prompt=      data.get("system_prompt", ""),
            fine_tuning_domain= FineTuningDomain(data.get("fine_tuning_domain", FineTuningDomain.GENERAL.value)),
            tool_access=        data.get("tool_access", {}),
            importance=         float(data.get("importance", ImportanceTier.READ_ONLY)),
            is_entry_point=     bool(data.get("is_entry_point", False)),
            hardening_level=    int(data.get("hardening_level", 0)),
            metadata=           data.get("metadata", {}),
        )

    def __repr__(self) -> str:
        return (
            f"AgentNode(id={self.node_id!r}, role={self.role.value}, "
            f"model={self.model_family.value}, hardening={self.hardening_level}, "
            f"importance={self.importance})"
        )


# ---------------------------------------------------------------------------
# AgentEdge
# ---------------------------------------------------------------------------

@dataclass
class AgentEdge:
    """
    A directed communication edge E ⊆ V×V.

    Attributes
    ----------
    source_id : str
        Origin agent node identifier.
    target_id : str
        Destination agent node identifier.
    weight : float
        Transmission weight W(e) ∈ [0, 1].
    context_mode : ContextMode
        Context-sharing mode c(e).
    metadata : dict
        Arbitrary key-value annotations.
    """

    source_id:    str
    target_id:    str
    weight:       float       = 1.0
    context_mode: ContextMode = ContextMode.LOCAL
    metadata:     Dict        = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not (0.0 <= self.weight <= 1.0):
            raise ValueError(
                f"Edge weight must be in [0, 1]; got {self.weight!r}"
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "source_id":    self.source_id,
            "target_id":    self.target_id,
            "weight":       self.weight,
            "context_mode": self.context_mode.value,
            "metadata":     dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AgentEdge":
        """Reconstruct an :class:`AgentEdge` from a dict."""
        return cls(
            source_id=    data["source_id"],
            target_id=    data["target_id"],
            weight=       float(data.get("weight", 1.0)),
            context_mode= ContextMode(data.get("context_mode", ContextMode.LOCAL.value)),
            metadata=     data.get("metadata", {}),
        )

    def __repr__(self) -> str:
        return (
            f"AgentEdge({self.source_id!r} → {self.target_id!r}, "
            f"w={self.weight:.3f}, mode={self.context_mode.value})"
        )


# ---------------------------------------------------------------------------
# HeterogeneityEmbedding
# ---------------------------------------------------------------------------

@dataclass
class HeterogeneityEmbedding:
    """
    Per-agent heterogeneity embedding H(v_i).

    Components (concatenated in ``full_embedding``):
      1. ``model_vec``        — one-hot over :class:`ModelFamily` (dim = |ModelFamily|)
      2. ``prompt_divergence`` — scalar cosine distance from canonical prompt
      3. ``domain_vec``       — one-hot over :class:`FineTuningDomain` (dim = |FineTuningDomain|)
      4. ``tool_vec``         — binary vector over 7 tool-access keys

    Total dimension d = |ModelFamily| + 1 + |FineTuningDomain| + 7
                      = 8 + 1 + 6 + 7 = 22
    """

    model_vec:        np.ndarray  # shape (|ModelFamily|,)
    prompt_divergence: float       # scalar ∈ [0, 1]
    domain_vec:       np.ndarray  # shape (|FineTuningDomain|,)
    tool_vec:         np.ndarray  # shape (7,)

    @property
    def full_embedding(self) -> np.ndarray:
        """Concatenated embedding vector of dimension d = 22."""
        return np.concatenate([
            self.model_vec,
            np.array([self.prompt_divergence], dtype=float),
            self.domain_vec,
            self.tool_vec,
        ])

    @property
    def dim(self) -> int:
        """Dimension of the full embedding."""
        return len(self.full_embedding)

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "model_vec":         self.model_vec.tolist(),
            "prompt_divergence": self.prompt_divergence,
            "domain_vec":        self.domain_vec.tolist(),
            "tool_vec":          self.tool_vec.tolist(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "HeterogeneityEmbedding":
        """Reconstruct a :class:`HeterogeneityEmbedding` from a dict."""
        return cls(
            model_vec=         np.array(data["model_vec"], dtype=float),
            prompt_divergence= float(data["prompt_divergence"]),
            domain_vec=        np.array(data["domain_vec"], dtype=float),
            tool_vec=          np.array(data["tool_vec"], dtype=float),
        )

    def __repr__(self) -> str:
        return (
            f"HeterogeneityEmbedding(dim={self.dim}, "
            f"prompt_divergence={self.prompt_divergence:.4f})"
        )


# ---------------------------------------------------------------------------
# Embedding computation
# ---------------------------------------------------------------------------

def _hash_based_unit_vector(text: str, dim: int) -> np.ndarray:
    """
    Produce a deterministic pseudo-unit vector for ``text`` without an LLM.

    Uses SHA-256 of the text to seed a pseudo-random unit vector.
    This is a *mock* embedding suitable for graph topology work only;
    the real pipeline should substitute actual sentence embeddings.
    """
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    # Expand digest bytes into float array via repeated hashing if needed
    rng = np.random.default_rng(seed=list(digest[:8]))
    vec = rng.standard_normal(dim)
    norm = np.linalg.norm(vec)
    return vec / norm if norm > 0 else vec


def _cosine_distance(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine distance ∈ [0, 1] between two vectors."""
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    sim = float(np.dot(a, b) / (norm_a * norm_b))
    sim = max(-1.0, min(1.0, sim))  # numerical clamp
    return (1.0 - sim) / 2.0       # map [-1,1] → [0,1]


def compute_heterogeneity_embedding(
    node: AgentNode,
    canonical_prompt_embedding: Optional[np.ndarray] = None,
) -> HeterogeneityEmbedding:
    """
    Compute the heterogeneity embedding H(v_i) for *node*.

    Parameters
    ----------
    node : AgentNode
        The agent whose embedding is being computed.
    canonical_prompt_embedding : np.ndarray | None
        Pre-computed embedding of a canonical neutral system prompt.
        If provided, ``prompt_divergence`` is the cosine distance between
        this vector and a hash-based mock embedding of ``node.system_prompt``.
        Pass ``None`` (default) to leave ``prompt_divergence`` as 0.0.

    Returns
    -------
    HeterogeneityEmbedding
        The computed embedding.

    Notes
    -----
    In production, replace the hash-based mock with real sentence embeddings
    (e.g. text-embedding-3-small) and pass the resulting float directly.
    """
    # 1. Model identity one-hot
    model_idx = _MODEL_FAMILY_ORDER.index(node.model_family.value)
    model_vec = np.zeros(len(_MODEL_FAMILY_ORDER), dtype=float)
    model_vec[model_idx] = 1.0

    # 2. System-prompt divergence
    prompt_divergence = 0.0
    if canonical_prompt_embedding is not None and node.system_prompt:
        _emb_dim = len(canonical_prompt_embedding)
        node_emb = _hash_based_unit_vector(node.system_prompt, _emb_dim)
        prompt_divergence = _cosine_distance(node_emb, canonical_prompt_embedding)

    # 3. Fine-tuning domain one-hot
    domain_idx = _FINE_TUNING_DOMAIN_ORDER.index(node.fine_tuning_domain.value)
    domain_vec = np.zeros(len(_FINE_TUNING_DOMAIN_ORDER), dtype=float)
    domain_vec[domain_idx] = 1.0

    # 4. Tool-access binary vector
    tool_vec = np.array(
        [float(node.tool_access.get(k, False)) for k in TOOL_ACCESS_KEYS],
        dtype=float,
    )

    return HeterogeneityEmbedding(
        model_vec=model_vec,
        prompt_divergence=prompt_divergence,
        domain_vec=domain_vec,
        tool_vec=tool_vec,
    )


# ---------------------------------------------------------------------------
# Resistance score
# ---------------------------------------------------------------------------

def resistance_score_from_embedding(
    embedding: HeterogeneityEmbedding,
    hardening_level: int,
) -> float:
    """
    Derive an intrinsic resistance score r_i ∈ [0, 1] from the embedding.

    Formula
    -------
    .. code-block:: none

        base              = 0.3 + 0.35 * (hardening_level / 2)
                          → V0=0.30,  V1=0.475, V2=0.65

        heterogeneity_bonus = 0.15 * ‖H(v_i)‖ / √d

        r_i               = min(1.0, base + heterogeneity_bonus)

    The heterogeneity bonus rewards diversity in the embedding (higher
    divergence from canonical defaults ⟹ harder to generalise an attack).

    Parameters
    ----------
    embedding : HeterogeneityEmbedding
        Pre-computed embedding for the agent.
    hardening_level : int
        Security hardening tier: 0 (none), 1, or 2 (full).

    Returns
    -------
    float
        Resistance score r_i ∈ [0, 1].
    """
    if hardening_level not in (0, 1, 2):
        raise ValueError(
            f"hardening_level must be 0, 1, or 2; got {hardening_level!r}"
        )

    full = embedding.full_embedding
    d = len(full)

    base = 0.3 + 0.35 * (hardening_level / 2.0)

    norm = float(np.linalg.norm(full))
    heterogeneity_bonus = 0.15 * norm / sqrt(d)

    return min(1.0, base + heterogeneity_bonus)
