"""
PROPAGATOR: Topology-Aware Vulnerability Propagation Framework
for Multi-Agent LLM Systems (GTRI CIPHER Lab)

PROPAGATOR models a multi-agent LLM system as a typed directed weighted graph
G = (V, E, H, W, μ, c) and provides a full measurement-and-defence pipeline:

1. **Graph** — typed agent nodes, directed edges, 8 canonical topologies.
2. **Sim** — discrete SIR-on-graph simulation, 5 attack types, R₀ analysis.
3. **Metrics** — Propagation Risk Score (PRS), Guardrail Attenuation Factor
   (GAF), structural indices, blast radius.
4. **Guardrails** — SCC, SAC, CAPC, ASP checks; edge-level and layer-level
   guardrail deployment.
5. **Map** — 4-D empirical vulnerability map (topology × attack × level ×
   seed) and visualisations.
6. **Place** — optimal guard placement via greedy, PageRank-guided, and
   betweenness-centrality strategies.
7. **Bench** — integration hooks for AutoGen 2.0 and DocTalk harnesses.

Usage
-----
>>> from propagator import PropagatorGraph, TopologyFactory, SimulationEngine
>>> from propagator import AttackType, GuardrailTier, GuardPlacementOptimizer
>>> from propagator.bench import PropagatorAutoGenHook, DocTalkHarness
>>> g = TopologyFactory.chain(4)
>>> engine = SimulationEngine(g)
>>> result = engine.run_experiment(
...     __import__('propagator').AttackConfig(
...         attack_type=AttackType.CONTEXT_POISONING,
...         injection_strength=0.8,
...         seed_node_id="agent_0",
...     )
... )
>>> print(result.mean_final_rate)
"""

__version__ = "0.1.0"
__author__  = "GTRI CIPHER Lab"

# ---------------------------------------------------------------------------
# Graph
# ---------------------------------------------------------------------------
from .graph import (
    AgentEdge,
    AgentNode,
    AgentRole,
    ContextMode,
    ModelFamily,
    PropagatorGraph,
    TopologyFactory,
)

# ---------------------------------------------------------------------------
# Sim
# ---------------------------------------------------------------------------
from .sim import (
    ATTACK_BASE_RATES,
    ATTACK_SEVERITY_WEIGHTS,
    AttackConfig,
    AttackResult,
    AttackType,
    CalibrationPhase,
    ExperimentRunner,
    SimulationEngine,
)

# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
from .metrics import (
    compute_blast_radius,
    compute_gaf,
    compute_prs,
    compute_structural_indices,
)

# ---------------------------------------------------------------------------
# Guardrails
# ---------------------------------------------------------------------------
from .guardrails import (
    EdgeGuardrail,
    GuardrailLayer,
    GuardrailTier,
    topology_conditional_guardrails,
)

# ---------------------------------------------------------------------------
# Map
# ---------------------------------------------------------------------------
from .map import (
    PropagatorVisualizer,
    VulnerabilityMap,
    VulnerabilityMapBuilder,
    VulnerabilityMapCell,
)

# ---------------------------------------------------------------------------
# Place
# ---------------------------------------------------------------------------
from .place import GuardPlacementOptimizer, PlacementMethod

# ---------------------------------------------------------------------------
# __all__
# ---------------------------------------------------------------------------

__all__ = [
    # Graph
    "PropagatorGraph",
    "TopologyFactory",
    "AgentNode",
    "AgentEdge",
    "AgentRole",
    "ModelFamily",
    "ContextMode",
    # Sim
    "SimulationEngine",
    "AttackType",
    "AttackConfig",
    "AttackResult",
    "ExperimentRunner",
    "CalibrationPhase",
    "ATTACK_BASE_RATES",
    "ATTACK_SEVERITY_WEIGHTS",
    # Metrics
    "compute_prs",
    "compute_gaf",
    "compute_structural_indices",
    "compute_blast_radius",
    # Guardrails
    "GuardrailLayer",
    "GuardrailTier",
    "EdgeGuardrail",
    "topology_conditional_guardrails",
    # Map
    "VulnerabilityMap",
    "VulnerabilityMapBuilder",
    "VulnerabilityMapCell",
    "PropagatorVisualizer",
    # Place
    "GuardPlacementOptimizer",
    "PlacementMethod",
    # Meta
    "__version__",
    "__author__",
]
