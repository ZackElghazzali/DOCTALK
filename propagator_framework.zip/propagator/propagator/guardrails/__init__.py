"""
propagator.guardrails
=====================
Guardrail checks and deployment primitives for the PROPAGATOR framework.

Provides four guard check implementations:

* :class:`SemanticConsistencyCheck` (SCC) — semantic similarity against
  reference message distributions.
* :class:`StructuralAnomalyCheck` (SAC) — rule-based injection pattern
  scanner + Shannon entropy analysis.
* :class:`ProvenanceCheck` (CAPC) — cross-agent provenance and novelty
  tracking.
* :class:`AnomalyScorePropagation` (ASP) — running anomaly accumulator and
  quarantine gate.

Plus higher-level deployment primitives:

* :class:`GuardrailTier` — enumeration of four tiers (G1–G4).
* :class:`EdgeGuardrail` — applies a full check suite to a single edge
  message and returns a :class:`GuardrailDecision`.
* :class:`GuardrailLayer` — layer-wide guard manager; runs checks on all
  edges in a topology.
* :func:`topology_conditional_guardrails` — factory that maps topology
  type to a recommended guardrail configuration.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from .checks import (
    AnomalyScorePropagation,
    CheckResult,
    ProvenanceCheck,
    SemanticConsistencyCheck,
    StructuralAnomalyCheck,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# GuardrailTier
# ---------------------------------------------------------------------------


class GuardrailTier(str, Enum):
    """Four-tier guardrail severity classification.

    Tiers map to which checks are enabled:

    * ``G1`` — SAC only (structural pattern scanning).
    * ``G2`` — SAC + ASP (adds anomaly score propagation).
    * ``G3`` — SAC + SCC + ASP (adds semantic consistency).
    * ``G4`` — SAC + SCC + CAPC + ASP (full suite, provenance tracking).
    """
    G1 = "G1"  # SAC only
    G2 = "G2"  # SAC + ASP
    G3 = "G3"  # SAC + SCC + ASP
    G4 = "G4"  # SAC + SCC + CAPC + ASP (full)


# ---------------------------------------------------------------------------
# GuardrailDecision
# ---------------------------------------------------------------------------


@dataclass
class GuardrailDecision:
    """
    Decision produced by :class:`EdgeGuardrail` after evaluating a message.

    Attributes
    ----------
    quarantined : bool
        ``True`` if the message was quarantined (blocked).
    combined_anomaly_score : float
        Aggregate anomaly score across all triggered checks, ∈ [0, 1].
    tier : GuardrailTier
        The tier that produced this decision.
    check_results : list[CheckResult]
        Individual results from each check in the pipeline.
    message_preview : str
        First 80 characters of the evaluated message.
    source_id : str
        Source agent node identifier.
    target_id : str
        Target agent node identifier.
    """

    quarantined: bool
    combined_anomaly_score: float
    tier: GuardrailTier
    check_results: List[CheckResult] = field(default_factory=list)
    message_preview: str = ""
    source_id: str = ""
    target_id: str = ""

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "quarantined":            self.quarantined,
            "combined_anomaly_score": self.combined_anomaly_score,
            "tier":                   self.tier.value,
            "check_results":          [cr.to_dict() for cr in self.check_results],
            "message_preview":        self.message_preview,
            "source_id":              self.source_id,
            "target_id":              self.target_id,
        }

    def __repr__(self) -> str:
        status = "QUARANTINED" if self.quarantined else "PASS"
        return (
            f"GuardrailDecision({status}, tier={self.tier.value}, "
            f"score={self.combined_anomaly_score:.3f})"
        )


# ---------------------------------------------------------------------------
# EdgeGuardrail
# ---------------------------------------------------------------------------


class EdgeGuardrail:
    """
    Applies a full check pipeline to a single directed edge message.

    Instantiated per-edge (or per-tier if shared); the checks are composed
    according to the selected :class:`GuardrailTier`.

    Parameters
    ----------
    tier : GuardrailTier
        Determines which checks are active.
    quarantine_threshold : float
        ASP quarantine threshold Θ.  Default ``0.7``.
    scc_threshold : float
        SCC similarity threshold.  Default ``0.6``.
    reference_messages : list[str] | None
        Reference message corpus for SCC.
    source_id : str
        Source agent identifier (used in decisions).
    target_id : str
        Target agent identifier (used in decisions).
    """

    def __init__(
        self,
        tier: GuardrailTier = GuardrailTier.G4,
        quarantine_threshold: float = 0.7,
        scc_threshold: float = 0.6,
        reference_messages: Optional[List[str]] = None,
        source_id: str = "",
        target_id: str = "",
    ) -> None:
        self.tier = tier
        self.source_id = source_id
        self.target_id = target_id

        # Always present for G1+
        self._sac = StructuralAnomalyCheck()

        # G2+
        self._asp = AnomalyScorePropagation(quarantine_threshold=quarantine_threshold)

        # G3+
        self._scc: Optional[SemanticConsistencyCheck] = None
        if tier in (GuardrailTier.G3, GuardrailTier.G4):
            self._scc = SemanticConsistencyCheck(
                threshold=scc_threshold,
                reference_messages=reference_messages,
            )

        # G4 only
        self._capc: Optional[ProvenanceCheck] = None
        if tier == GuardrailTier.G4:
            self._capc = ProvenanceCheck()

    # ------------------------------------------------------------------

    def evaluate(
        self,
        message: str,
        previous_anomaly_score: float = 0.0,
        claimed_source: Optional[str] = None,
        precomputed_similarity: Optional[float] = None,
    ) -> GuardrailDecision:
        """
        Run the check pipeline for *message*.

        Parameters
        ----------
        message : str
            Inter-agent message to evaluate.
        previous_anomaly_score : float
            Running anomaly score from prior messages on this path.
        claimed_source : str | None
            Claimed source agent ID (used by CAPC if tier == G4).
        precomputed_similarity : float | None
            Pre-computed SCC similarity score; overrides heuristic.

        Returns
        -------
        GuardrailDecision
        """
        check_results: List[CheckResult] = []
        running_delta = 0.0

        # SAC (all tiers)
        sac_result = self._sac.check(message)
        check_results.append(sac_result)
        running_delta += sac_result.delta_anomaly

        # SCC (G3, G4)
        if self._scc is not None:
            scc_result = self._scc.check(message, precomputed_similarity)
            check_results.append(scc_result)
            running_delta += scc_result.delta_anomaly

        # CAPC (G4)
        if self._capc is not None:
            capc_result = self._capc.check(message, claimed_source)
            check_results.append(capc_result)
            running_delta += capc_result.delta_anomaly
            # Update trace with this message (unverified — evaluation only)
            self._capc.add_to_trace(message, self.source_id, verified=False)

        # ASP (G2+)
        if self.tier != GuardrailTier.G1:
            asp_result = self._asp.check(running_delta, previous_anomaly_score)
            check_results.append(asp_result)
            quarantined = asp_result.triggered
            combined    = min(1.0, previous_anomaly_score + running_delta)
        else:
            # G1: quarantine if SAC triggered
            quarantined = sac_result.triggered
            combined    = min(1.0, running_delta)

        return GuardrailDecision(
            quarantined=           quarantined,
            combined_anomaly_score=combined,
            tier=                  self.tier,
            check_results=         check_results,
            message_preview=       message[:80],
            source_id=             self.source_id,
            target_id=             self.target_id,
        )

    # ------------------------------------------------------------------

    def to_safeguards_json(self) -> str:
        """Return a JSON representation of this guardrail's configuration.

        Compatible with the PROPAGATOR safeguards-export format.
        """
        config = {
            "tier":                 self.tier.value,
            "source_id":            self.source_id,
            "target_id":            self.target_id,
            "checks_enabled":       self._active_check_names(),
            "quarantine_threshold": getattr(self._asp, "quarantine_threshold", 0.7),
            "scc_threshold":        getattr(self._scc, "threshold", None),
            "capc_enabled":         self._capc is not None,
        }
        return json.dumps(config, indent=2)

    def _active_check_names(self) -> List[str]:
        names = ["SAC"]
        if self._scc is not None:
            names.append("SCC")
        if self._capc is not None:
            names.append("CAPC")
        if self.tier != GuardrailTier.G1:
            names.append("ASP")
        return names

    def __repr__(self) -> str:
        return (
            f"EdgeGuardrail(tier={self.tier.value}, "
            f"edge={self.source_id!r}→{self.target_id!r}, "
            f"checks={self._active_check_names()})"
        )


# ---------------------------------------------------------------------------
# GuardrailLayer
# ---------------------------------------------------------------------------


class GuardrailLayer:
    """
    Layer-wide guard manager for a :class:`~propagator.graph.PropagatorGraph`.

    Maintains one :class:`EdgeGuardrail` per directed edge and exposes a
    method to evaluate all edges for a given message broadcast.

    Parameters
    ----------
    default_tier : GuardrailTier
        Default tier applied to all edges without an explicit override.
    """

    def __init__(self, default_tier: GuardrailTier = GuardrailTier.G2) -> None:
        self.default_tier = default_tier
        # edge (src, tgt) → EdgeGuardrail
        self._edge_guards: Dict[tuple, EdgeGuardrail] = {}

    def add_edge_guard(
        self,
        source_id: str,
        target_id: str,
        tier: Optional[GuardrailTier] = None,
        **kwargs: Any,
    ) -> EdgeGuardrail:
        """Register an :class:`EdgeGuardrail` for a specific edge.

        Parameters
        ----------
        source_id : str
            Source agent ID.
        target_id : str
            Target agent ID.
        tier : GuardrailTier | None
            Override tier for this edge.  Falls back to ``default_tier``.
        **kwargs :
            Additional keyword arguments forwarded to :class:`EdgeGuardrail`.

        Returns
        -------
        EdgeGuardrail
            The newly registered guardrail.
        """
        guard = EdgeGuardrail(
            tier=tier or self.default_tier,
            source_id=source_id,
            target_id=target_id,
            **kwargs,
        )
        self._edge_guards[(source_id, target_id)] = guard
        return guard

    def build_from_graph(self, graph, tier: Optional[GuardrailTier] = None) -> None:
        """Populate edge guards for every edge in *graph*.

        Parameters
        ----------
        graph : PropagatorGraph
            Topology to instrument.
        tier : GuardrailTier | None
            Tier for all edges (defaults to ``self.default_tier``).
        """
        for (src, tgt) in graph._graph.edges():  # type: ignore[attr-defined]
            self.add_edge_guard(src, tgt, tier=tier)

    def evaluate_edge(
        self,
        source_id: str,
        target_id: str,
        message: str,
        **kwargs: Any,
    ) -> Optional[GuardrailDecision]:
        """Evaluate a single edge's guardrail.

        If no guard exists for this edge, returns ``None``.

        Parameters
        ----------
        source_id : str
        target_id : str
        message : str
        **kwargs :
            Forwarded to :meth:`EdgeGuardrail.evaluate`.

        Returns
        -------
        GuardrailDecision | None
        """
        guard = self._edge_guards.get((source_id, target_id))
        if guard is None:
            return None
        return guard.evaluate(message, **kwargs)

    def evaluate_all(
        self,
        message: str,
        **kwargs: Any,
    ) -> Dict[tuple, GuardrailDecision]:
        """Evaluate *message* against every registered edge guard.

        Returns
        -------
        dict[(source_id, target_id), GuardrailDecision]
        """
        return {
            edge: guard.evaluate(message, **kwargs)
            for edge, guard in self._edge_guards.items()
        }

    @property
    def n_edges(self) -> int:
        """Number of monitored edges."""
        return len(self._edge_guards)

    def __repr__(self) -> str:
        return (
            f"GuardrailLayer(default_tier={self.default_tier.value}, "
            f"edges={self.n_edges})"
        )


# ---------------------------------------------------------------------------
# topology_conditional_guardrails
# ---------------------------------------------------------------------------

# Recommended tier per topology type.
_TOPOLOGY_TIER_MAP: Dict[str, GuardrailTier] = {
    "chain":      GuardrailTier.G3,
    "star":       GuardrailTier.G4,
    "tree":       GuardrailTier.G3,
    "full":       GuardrailTier.G4,
    "ring":       GuardrailTier.G2,
    "mesh":       GuardrailTier.G4,
    "layered":    GuardrailTier.G3,
    "hierarchical": GuardrailTier.G4,
}


def topology_conditional_guardrails(
    topology_type: str,
    graph=None,
) -> GuardrailLayer:
    """Create a :class:`GuardrailLayer` recommended for *topology_type*.

    Parameters
    ----------
    topology_type : str
        Canonical topology name (e.g. ``"star"``, ``"chain"``, ``"mesh"``).
        Case-insensitive prefix match is used.
    graph : PropagatorGraph | None
        If provided, the layer is pre-populated for all edges in *graph*.

    Returns
    -------
    GuardrailLayer
    """
    key = topology_type.lower().split("_")[0]  # strip size suffix
    tier = _TOPOLOGY_TIER_MAP.get(key, GuardrailTier.G2)
    layer = GuardrailLayer(default_tier=tier)
    if graph is not None:
        layer.build_from_graph(graph, tier=tier)
    logger.info(
        "topology_conditional_guardrails: %r → tier %s (%d edges)",
        topology_type, tier.value, layer.n_edges,
    )
    return layer


__all__ = [
    # Check classes
    "CheckResult",
    "SemanticConsistencyCheck",
    "StructuralAnomalyCheck",
    "ProvenanceCheck",
    "AnomalyScorePropagation",
    # Decision
    "GuardrailDecision",
    # Tier
    "GuardrailTier",
    # Edge-level
    "EdgeGuardrail",
    # Layer-level
    "GuardrailLayer",
    # Factory
    "topology_conditional_guardrails",
]
