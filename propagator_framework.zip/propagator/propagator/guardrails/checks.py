"""
propagator.guardrails.checks
============================
Implementations of the four guardrail check types used by PROPAGATOR:

  SCC  — Semantic Consistency Check
  SAC  — Structural Anomaly Check
  CAPC — Cross-Agent Provenance Check
  ASP  — Anomaly Score Propagation

All checks are heuristic / rule-based (no live LLM calls).
Each returns a :class:`CheckResult` carrying a Δa anomaly contribution.
"""

from __future__ import annotations

import math
import re
import string
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# CheckResult
# ---------------------------------------------------------------------------

@dataclass
class CheckResult:
    """
    The outcome produced by a single guardrail check.

    Attributes
    ----------
    check_name : str
        Identifier of the check that produced this result (e.g. ``"SCC"``).
    triggered : bool
        ``True`` if the check detected an anomaly.
    delta_anomaly : float
        Δa — the anomaly score increment contributed by this check.
        Always ≥ 0; only non-zero when *triggered* is ``True``.
    confidence : float
        Confidence in the result, ∈ [0, 1].
    details : dict
        Arbitrary metadata produced by the check (patterns matched,
        similarity score, etc.).
    """

    check_name: str
    triggered: bool
    delta_anomaly: float
    confidence: float
    details: Dict

    def __post_init__(self) -> None:
        self.delta_anomaly = max(0.0, float(self.delta_anomaly))
        self.confidence = max(0.0, min(1.0, float(self.confidence)))

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "check_name": self.check_name,
            "triggered": self.triggered,
            "delta_anomaly": self.delta_anomaly,
            "confidence": self.confidence,
            "details": self.details,
        }

    def __repr__(self) -> str:
        status = "TRIGGERED" if self.triggered else "OK"
        return (
            f"CheckResult({self.check_name} [{status}], "
            f"Δa={self.delta_anomaly:.3f}, conf={self.confidence:.3f})"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tokenise(text: str) -> List[str]:
    """
    Simple whitespace + punctuation tokeniser — produces lowercase tokens.
    Used by SCC and CAPC for keyword-overlap heuristics.
    """
    text = text.lower()
    # Replace punctuation with spaces
    for ch in string.punctuation:
        text = text.replace(ch, " ")
    return [t for t in text.split() if len(t) > 2]


def _shannon_entropy(text: str) -> float:
    """
    Compute the Shannon entropy (bits) of the character-frequency distribution
    of *text*.  Returns 0.0 for empty / single-character strings.
    """
    if not text:
        return 0.0
    freq = Counter(text)
    total = len(text)
    entropy = 0.0
    for count in freq.values():
        p = count / total
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


def _jaccard_similarity(set_a: set, set_b: set) -> float:
    """Jaccard similarity between two token sets."""
    if not set_a and not set_b:
        return 1.0
    union = set_a | set_b
    if not union:
        return 1.0
    return len(set_a & set_b) / len(union)


# ---------------------------------------------------------------------------
# SemanticConsistencyCheck (SCC)
# ---------------------------------------------------------------------------

class SemanticConsistencyCheck:
    """
    SCC — checks whether a message is semantically consistent with the
    expected distribution of clean messages for this communication edge.

    In a production deployment this check would embed the message and compare
    it to a reference distribution using cosine similarity.  Because the core
    framework avoids live LLM / embedder calls, two fallback modes are
    provided:

    1. **Pre-computed similarity** — caller passes ``precomputed_similarity``
       directly (e.g. from an upstream embedder pipeline).
    2. **Keyword-overlap heuristic** — Jaccard similarity between the
       incoming message's tokens and those of the reference messages.

    Parameters
    ----------
    threshold : float
        Minimum similarity required to pass, ∈ [0, 1].  Default ``0.6``.
    reference_messages : list[str] | None
        Corpus of clean reference messages for this edge type.
        Used in heuristic mode when no embedder is available.
    """

    def __init__(
        self,
        threshold: float = 0.6,
        reference_messages: Optional[List[str]] = None,
    ) -> None:
        if not (0.0 <= threshold <= 1.0):
            raise ValueError(f"threshold must be in [0, 1]; got {threshold!r}")
        self.threshold = threshold
        self.reference_messages: List[str] = reference_messages or []
        # Pre-tokenised reference token sets for fast Jaccard
        self._ref_token_sets: List[set] = [
            set(_tokenise(m)) for m in self.reference_messages
        ]

    # ------------------------------------------------------------------

    def check(
        self,
        message: str,
        precomputed_similarity: Optional[float] = None,
    ) -> CheckResult:
        """
        Evaluate semantic consistency of *message*.

        Parameters
        ----------
        message : str
            The inter-agent message to evaluate.
        precomputed_similarity : float | None
            If provided, use this cosine-similarity score directly
            (e.g. from an external embedder).  Must be ∈ [0, 1].
            If ``None``, falls back to keyword-overlap Jaccard heuristic.

        Returns
        -------
        CheckResult
            ``triggered=True`` if similarity < ``self.threshold``.
            ``delta_anomaly = 1.0 - similarity``.
        """
        if precomputed_similarity is not None:
            similarity = max(0.0, min(1.0, float(precomputed_similarity)))
            mode = "precomputed"
        else:
            similarity = self._heuristic_similarity(message)
            mode = "keyword_jaccard"

        triggered = similarity < self.threshold
        delta_anomaly = (1.0 - similarity) if triggered else 0.0

        # Confidence: higher when the gap from threshold is large
        gap = abs(similarity - self.threshold)
        confidence = min(1.0, gap * 2.0 + 0.5) if triggered else min(1.0, gap * 2.0 + 0.5)

        return CheckResult(
            check_name="SCC",
            triggered=triggered,
            delta_anomaly=delta_anomaly,
            confidence=confidence,
            details={
                "similarity": similarity,
                "threshold": self.threshold,
                "mode": mode,
                "reference_count": len(self.reference_messages),
            },
        )

    # ------------------------------------------------------------------

    def _heuristic_similarity(self, message: str) -> float:
        """
        Compute a heuristic similarity score using Jaccard overlap between
        the message's tokens and the union of reference message tokens.

        If no reference messages are configured, returns 1.0 (assume
        messages are always consistent — pass-through).
        """
        if not self._ref_token_sets:
            return 1.0

        msg_tokens = set(_tokenise(message))
        if not msg_tokens:
            return 1.0

        # Compute max Jaccard against any single reference message
        # (closest-neighbour semantics)
        best = max(
            _jaccard_similarity(msg_tokens, ref)
            for ref in self._ref_token_sets
        )
        return best

    def add_reference(self, message: str) -> None:
        """Append a new clean reference message to the distribution."""
        self.reference_messages.append(message)
        self._ref_token_sets.append(set(_tokenise(message)))

    def __repr__(self) -> str:
        return (
            f"SemanticConsistencyCheck(threshold={self.threshold}, "
            f"refs={len(self.reference_messages)})"
        )


# ---------------------------------------------------------------------------
# StructuralAnomalyCheck (SAC)
# ---------------------------------------------------------------------------

class StructuralAnomalyCheck:
    """
    SAC — rule-based scanner for structural injection anomalies.

    Detects:
    * Known prompt-injection patterns (compiled regex library)
    * Suspiciously high Shannon entropy (possibly encoded payload)

    No external dependencies — purely deterministic.
    """

    # Ordered list of compiled injection patterns
    INJECTION_PATTERNS: List[str] = [
        r"ignore\s+(previous|prior|all)\s+instructions?",
        r"you\s+are\s+now\s+(a|an|the)\s+\w+",
        r"system\s*:\s*override",
        r"<\s*system\s*>",
        r"\[INST\].*override",
        r"\\x[0-9a-f]{2}",           # hex-encoded byte
        r"\\u[0-9a-f]{4}",           # unicode escape in suspicious context
        r"forget\s+(everything|all|your)",
        r"(act|behave|pretend)\s+as\s+if",
        r"jailbreak",
        r"DAN\s+mode",
        r"developer\s+mode",
        r"prompt\s+injection",
        r"disregard\s+(all|previous|prior)\s+(instructions?|rules?|constraints?)",
        r"new\s+persona",
        r"roleplay\s+as",
        r"evil\s+(mode|version|variant)",
        r"override\s+(safety|alignment|restrictions?)",
    ]

    # Shannon entropy threshold above which content is flagged as high-entropy
    ENTROPY_HIGH_THRESHOLD: float = 4.5   # bits — typical English ≈ 3.5–4.2

    def __init__(self) -> None:
        self._compiled: List[re.Pattern] = [
            re.compile(p, re.IGNORECASE | re.DOTALL)
            for p in self.INJECTION_PATTERNS
        ]

    # ------------------------------------------------------------------

    def check(self, message: str) -> CheckResult:
        """
        Scan *message* for injection patterns and anomalous entropy.

        Algorithm
        ---------
        1. Run each compiled pattern against the message.
        2. Compute Shannon entropy of the message's character distribution.
        3. ``triggered`` iff any pattern matches OR entropy > threshold.
        4. ``delta_anomaly`` = matched_patterns / len(PATTERNS) * 0.7
                              + 0.3 * entropy_signal
           so both dimensions contribute but patterns dominate.

        Returns
        -------
        CheckResult
        """
        matched: List[str] = []
        for pat in self._compiled:
            if pat.search(message):
                matched.append(pat.pattern)

        entropy = _shannon_entropy(message)
        high_entropy = entropy > self.ENTROPY_HIGH_THRESHOLD

        pattern_score = len(matched) / max(len(self._compiled), 1)
        # Normalise entropy: map [threshold, 8] → [0, 1]
        entropy_signal = 0.0
        if high_entropy:
            entropy_signal = min(
                1.0,
                (entropy - self.ENTROPY_HIGH_THRESHOLD)
                / (8.0 - self.ENTROPY_HIGH_THRESHOLD),
            )

        triggered = bool(matched) or high_entropy
        delta_anomaly = (0.7 * pattern_score + 0.3 * entropy_signal) if triggered else 0.0

        # Cap at 1.0
        delta_anomaly = min(1.0, delta_anomaly)

        # Confidence proportional to evidence strength
        confidence = min(1.0, (len(matched) * 0.2 + (0.3 if high_entropy else 0.0) + 0.5))
        if not triggered:
            confidence = 0.8  # high confidence in negative result

        return CheckResult(
            check_name="SAC",
            triggered=triggered,
            delta_anomaly=delta_anomaly,
            confidence=confidence,
            details={
                "matched_patterns": matched,
                "pattern_count": len(matched),
                "entropy": round(entropy, 4),
                "high_entropy": high_entropy,
                "entropy_threshold": self.ENTROPY_HIGH_THRESHOLD,
            },
        )

    def __repr__(self) -> str:
        return (
            f"StructuralAnomalyCheck(patterns={len(self._compiled)}, "
            f"entropy_threshold={self.ENTROPY_HIGH_THRESHOLD})"
        )


# ---------------------------------------------------------------------------
# ProvenanceCheck (CAPC)
# ---------------------------------------------------------------------------

class ProvenanceCheck:
    """
    CAPC — Cross-Agent Provenance Check.

    Maintains an execution trace of verified messages and checks whether
    key claims in new messages are traceable to that trace.

    This is a *simplified non-cryptographic* implementation:

    * "Claims" are operationalised as named entities, numbers, and uncommon
      noun phrases extracted via simple heuristics.
    * Traceability is tested via token-level overlap against the verified trace.
    * An unrecognised ``claimed_source`` adds Δa.
    * New factual tokens (numbers, capitalised terms) not seen in the trace
      also add Δa.

    Parameters
    ----------
    novelty_threshold : float
        Fraction of novel factual tokens above which the check triggers.
        Default 0.5 — if more than half the message's factual tokens are new,
        flag it.
    """

    def __init__(self, novelty_threshold: float = 0.5) -> None:
        self.novelty_threshold = novelty_threshold
        self._verified_sources: List[str] = []
        self._execution_trace: List[Dict] = []
        self._trace_token_set: set = set()  # running union of all trace tokens

    # ------------------------------------------------------------------

    def add_to_trace(
        self,
        message: str,
        source_id: str,
        verified: bool = True,
    ) -> None:
        """
        Add *message* to the execution trace.

        Parameters
        ----------
        message : str
            Message content.
        source_id : str
            Identifier of the sending agent.
        verified : bool
            Whether this message is considered trusted / verified.
            Unverified messages are logged but ``source_id`` is not added to
            the verified-source registry.
        """
        entry = {
            "source_id": source_id,
            "message": message,
            "verified": verified,
            "tokens": set(_tokenise(message)),
            "factual_tokens": set(self._extract_factual_tokens(message)),
        }
        self._execution_trace.append(entry)
        if verified:
            # Merge tokens into global trace set
            self._trace_token_set.update(entry["tokens"])
            self._trace_token_set.update(entry["factual_tokens"])
            if source_id not in self._verified_sources:
                self._verified_sources.append(source_id)

    # ------------------------------------------------------------------

    def check(
        self,
        message: str,
        claimed_source: Optional[str] = None,
    ) -> CheckResult:
        """
        Check provenance of *message*.

        Steps
        -----
        1. If *claimed_source* is provided and not in verified sources → flag.
        2. Extract factual tokens from *message*.
        3. Compute fraction of those tokens *not* seen in the trace.
        4. Trigger if fraction > ``novelty_threshold``.

        Returns
        -------
        CheckResult
        """
        source_unverified = (
            claimed_source is not None
            and claimed_source not in self._verified_sources
        )

        factual_tokens = set(self._extract_factual_tokens(message))
        novel_tokens: set = set()
        if factual_tokens:
            novel_tokens = factual_tokens - self._trace_token_set
            novelty_ratio = len(novel_tokens) / len(factual_tokens)
        else:
            novelty_ratio = 0.0

        high_novelty = novelty_ratio > self.novelty_threshold
        triggered = source_unverified or high_novelty

        # Compose delta_anomaly
        source_penalty = 0.4 if source_unverified else 0.0
        novelty_penalty = min(0.6, novelty_ratio * 0.6) if high_novelty else 0.0
        delta_anomaly = min(1.0, source_penalty + novelty_penalty) if triggered else 0.0

        confidence = 0.6
        if source_unverified and high_novelty:
            confidence = 0.9
        elif source_unverified or high_novelty:
            confidence = 0.7

        return CheckResult(
            check_name="CAPC",
            triggered=triggered,
            delta_anomaly=delta_anomaly,
            confidence=confidence,
            details={
                "claimed_source": claimed_source,
                "source_unverified": source_unverified,
                "verified_sources": list(self._verified_sources),
                "factual_token_count": len(factual_tokens),
                "novel_token_count": len(novel_tokens),
                "novelty_ratio": round(novelty_ratio, 4),
                "trace_length": len(self._execution_trace),
            },
        )

    # ------------------------------------------------------------------

    def reset_trace(self) -> None:
        """Clear the execution trace and verified-source registry."""
        self._verified_sources = []
        self._execution_trace = []
        self._trace_token_set = set()

    # ------------------------------------------------------------------

    @staticmethod
    def _extract_factual_tokens(text: str) -> List[str]:
        """
        Heuristically extract "factual" tokens: numbers and capitalised words
        that are likely to be named entities or specific values.

        Numbers (digits) and words with an initial capital letter (excluding
        the very first word of a sentence) are treated as factual claims.
        """
        tokens: List[str] = []
        words = text.split()
        for i, word in enumerate(words):
            clean = word.strip(string.punctuation)
            if not clean:
                continue
            # Numbers
            if re.match(r"^-?\d+(\.\d+)?([eE][+-]?\d+)?(%|K|M|B)?$", clean):
                tokens.append(clean.lower())
            # Capitalised words not at the very start of a sentence
            elif i > 0 and clean[0].isupper() and len(clean) > 1:
                tokens.append(clean.lower())
        return tokens

    def __repr__(self) -> str:
        return (
            f"ProvenanceCheck(trace_len={len(self._execution_trace)}, "
            f"verified_sources={len(self._verified_sources)}, "
            f"novelty_threshold={self.novelty_threshold})"
        )


# ---------------------------------------------------------------------------
# AnomalyScorePropagation (ASP)
# ---------------------------------------------------------------------------

class AnomalyScorePropagation:
    """
    ASP — running anomaly score accumulator and quarantine gatekeeper.

    Each message carries a cumulative anomaly score that is incremented by
    each guardrail check's Δa.  If the combined score exceeds the quarantine
    threshold Θ, the message is flagged for quarantine.

    Parameters
    ----------
    quarantine_threshold : float
        Θ — combined score above which a message is quarantined.
        Default ``0.7``.
    """

    def __init__(self, quarantine_threshold: float = 0.7) -> None:
        if not (0.0 <= quarantine_threshold <= 1.0):
            raise ValueError(
                f"quarantine_threshold must be in [0, 1]; got {quarantine_threshold!r}"
            )
        self.quarantine_threshold = quarantine_threshold

    # ------------------------------------------------------------------

    def check(
        self,
        message_anomaly_score: float,
        previous_score: float = 0.0,
    ) -> CheckResult:
        """
        Accumulate anomaly score and test against the quarantine threshold.

        Parameters
        ----------
        message_anomaly_score : float
            Δa contributed by the current round of checks.
        previous_score : float
            Running anomaly score accumulated from prior messages / checks
            on this propagation path.  Default ``0.0``.

        Returns
        -------
        CheckResult
            ``triggered=True`` if ``previous_score + message_anomaly_score``
            exceeds ``self.quarantine_threshold``.
            ``delta_anomaly`` = ``message_anomaly_score``.
        """
        combined = max(0.0, previous_score) + max(0.0, message_anomaly_score)
        triggered = combined > self.quarantine_threshold

        # Confidence scales with how far above / below the threshold we are
        margin = abs(combined - self.quarantine_threshold)
        confidence = min(1.0, 0.5 + margin)

        return CheckResult(
            check_name="ASP",
            triggered=triggered,
            delta_anomaly=float(max(0.0, message_anomaly_score)),
            confidence=confidence,
            details={
                "previous_score": previous_score,
                "message_anomaly_score": message_anomaly_score,
                "combined_score": combined,
                "quarantine_threshold": self.quarantine_threshold,
                "margin": round(combined - self.quarantine_threshold, 4),
            },
        )

    def __repr__(self) -> str:
        return f"AnomalyScorePropagation(threshold={self.quarantine_threshold})"
