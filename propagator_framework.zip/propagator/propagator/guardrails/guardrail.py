"""
propagator.guardrails.guardrail
================================
Core guardrail classes for PROPAGATOR edge-level interception.

Architecture overview
---------------------
* :class:`GuardrailTier` — G0-G4 preset identifiers.
* :class:`GuardrailConfig` — per-tier configuration (which checks are active,
  thresholds, expected FPR/latency, miss-rate m_e).
* :class:`GuardrailDecision` — result of a single interception call.
* :class:`EdgeGuardrail` — pluggable interceptor bound to one directed edge
  (source_id → target_id).  Call ``.intercept()`` on every forwarded message.
* :class:`GuardrailLayer` — manages a collection of :class:`EdgeGuardrail`
  instances deployed across a :class:`~propagator.graph.PropagatorGraph`.
"""

from __future__ import annotations

import copy
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

from ..graph.graph import PropagatorGraph
from .checks import (
    AnomalyScorePropagation,
    CheckResult,
    ProvenanceCheck,
    SemanticConsistencyCheck,
    StructuralAnomalyCheck,
)


# ---------------------------------------------------------------------------
# GuardrailTier
# ---------------------------------------------------------------------------

class GuardrailTier(str, Enum):
    """
    Guardrail tier identifiers.

    Each tier enables a specific combination of checks with known
    expected FPR, latency, and miss-rate trade-offs.

    ======  =============  ============  ==========  =========
    Tier    Checks active  Expected FPR  Latency ms  Miss-rate
    ======  =============  ============  ==========  =========
    G0      none           0 %           0           1.00
    G1      SAC            ~5 %          ~10         0.40
    G2      SCC + SAC      ~12 %         ~80         0.20
    G3      SCC+SAC+CAPC   ~18 %         ~150        0.10
    G4      all 4          ~22 %         ~200        0.05
    ======  =============  ============  ==========  =========
    """

    G0 = "G0"  # Baseline — no checks
    G1 = "G1"  # Structural only
    G2 = "G2"  # Semantic + Structural
    G3 = "G3"  # Provenance + Semantic + Structural
    G4 = "G4"  # Full stack (all four checks)


# ---------------------------------------------------------------------------
# GuardrailConfig
# ---------------------------------------------------------------------------

@dataclass
class GuardrailConfig:
    """
    Configuration for an :class:`EdgeGuardrail` instance.

    Attributes
    ----------
    tier : GuardrailTier
        Preset tier label.
    scc_enabled : bool
        Enable :class:`~.checks.SemanticConsistencyCheck`.
    scc_threshold : float
        Similarity threshold used by SCC, ∈ [0, 1].
    sac_enabled : bool
        Enable :class:`~.checks.StructuralAnomalyCheck`.
    capc_enabled : bool
        Enable :class:`~.checks.ProvenanceCheck`.
    asp_enabled : bool
        Enable :class:`~.checks.AnomalyScorePropagation`.
    asp_threshold : float
        Quarantine threshold Θ used by ASP, ∈ [0, 1].
    expected_fpr : float
        Expected false-positive rate for this configuration.
    expected_latency_ms : float
        Expected additional per-message latency in milliseconds.
    miss_rate : float
        m_e ∈ [0, 1] — fraction of malicious messages that still
        pass (1 = useless, 0 = perfect).  Used to modulate edge
        transmission probabilities.
    reference_messages : list[str]
        Seed reference messages for SCC's heuristic mode.
    """

    tier: GuardrailTier
    scc_enabled: bool = False
    scc_threshold: float = 0.6
    sac_enabled: bool = False
    capc_enabled: bool = False
    asp_enabled: bool = False
    asp_threshold: float = 0.7
    expected_fpr: float = 0.0
    expected_latency_ms: float = 0.0
    miss_rate: float = 1.0
    reference_messages: List[str] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Presets
    # ------------------------------------------------------------------

    @classmethod
    def from_tier(cls, tier: GuardrailTier) -> "GuardrailConfig":
        """
        Factory method returning the canonical preset config for *tier*.

        Parameters
        ----------
        tier : GuardrailTier
            The desired tier.

        Returns
        -------
        GuardrailConfig
            Preset configuration with canonical FPR / latency / miss-rate
            values as documented in :class:`GuardrailTier`.
        """
        presets: Dict[GuardrailTier, Dict] = {
            GuardrailTier.G0: dict(
                scc_enabled=False,
                sac_enabled=False,
                capc_enabled=False,
                asp_enabled=False,
                expected_fpr=0.00,
                expected_latency_ms=0.0,
                miss_rate=1.00,
            ),
            GuardrailTier.G1: dict(
                scc_enabled=False,
                sac_enabled=True,
                capc_enabled=False,
                asp_enabled=True,
                expected_fpr=0.05,
                expected_latency_ms=10.0,
                miss_rate=0.40,
            ),
            GuardrailTier.G2: dict(
                scc_enabled=True,
                sac_enabled=True,
                capc_enabled=False,
                asp_enabled=True,
                expected_fpr=0.12,
                expected_latency_ms=80.0,
                miss_rate=0.20,
            ),
            GuardrailTier.G3: dict(
                scc_enabled=True,
                sac_enabled=True,
                capc_enabled=True,
                asp_enabled=True,
                expected_fpr=0.18,
                expected_latency_ms=150.0,
                miss_rate=0.10,
            ),
            GuardrailTier.G4: dict(
                scc_enabled=True,
                sac_enabled=True,
                capc_enabled=True,
                asp_enabled=True,
                expected_fpr=0.22,
                expected_latency_ms=200.0,
                miss_rate=0.05,
            ),
        }
        kwargs = presets[tier]
        return cls(tier=tier, **kwargs)

    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "tier": self.tier.value,
            "scc_enabled": self.scc_enabled,
            "scc_threshold": self.scc_threshold,
            "sac_enabled": self.sac_enabled,
            "capc_enabled": self.capc_enabled,
            "asp_enabled": self.asp_enabled,
            "asp_threshold": self.asp_threshold,
            "expected_fpr": self.expected_fpr,
            "expected_latency_ms": self.expected_latency_ms,
            "miss_rate": self.miss_rate,
        }

    def __repr__(self) -> str:
        active = [
            name
            for name, enabled in [
                ("SCC", self.scc_enabled),
                ("SAC", self.sac_enabled),
                ("CAPC", self.capc_enabled),
                ("ASP", self.asp_enabled),
            ]
            if enabled
        ]
        return (
            f"GuardrailConfig(tier={self.tier.value}, "
            f"checks={active}, miss_rate={self.miss_rate})"
        )


# ---------------------------------------------------------------------------
# GuardrailDecision
# ---------------------------------------------------------------------------

@dataclass
class GuardrailDecision:
    """
    The outcome of a single :meth:`EdgeGuardrail.intercept` call.

    Attributes
    ----------
    passed : bool
        ``True`` → message passes; ``False`` → quarantine.
    anomaly_score : float
        Final combined anomaly score for this message.
    triggered_checks : list[str]
        Names of checks that fired.
    check_results : list[CheckResult]
        Full results from each active check.
    latency_ms : float
        Wall-clock time consumed by the interception (milliseconds).
    message_id : str
        Unique identifier for this interception event (UUID-4).
    """

    passed: bool
    anomaly_score: float
    triggered_checks: List[str]
    check_results: List[CheckResult]
    latency_ms: float
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        """Return a JSON-serialisable representation."""
        return {
            "passed": self.passed,
            "anomaly_score": self.anomaly_score,
            "triggered_checks": self.triggered_checks,
            "check_results": [r.to_dict() for r in self.check_results],
            "latency_ms": self.latency_ms,
            "message_id": self.message_id,
        }

    def __repr__(self) -> str:
        verdict = "PASS" if self.passed else "QUARANTINE"
        return (
            f"GuardrailDecision({verdict}, score={self.anomaly_score:.3f}, "
            f"triggered={self.triggered_checks}, id={self.message_id[:8]})"
        )


# ---------------------------------------------------------------------------
# EdgeGuardrail
# ---------------------------------------------------------------------------

class EdgeGuardrail:
    """
    Edge-level interceptor for messages flowing from *source_id* → *target_id*.

    Pluggable and framework-agnostic: apply via decorator or direct
    :meth:`intercept` call.  Does **not** modify the underlying AutoGen /
    LangGraph framework objects.

    Parameters
    ----------
    source_id : str
        Identifier of the sending agent.
    target_id : str
        Identifier of the receiving agent.
    config : GuardrailConfig
        Active check configuration.
    """

    def __init__(
        self,
        source_id: str,
        target_id: str,
        config: GuardrailConfig,
    ) -> None:
        self.source_id = source_id
        self.target_id = target_id
        self.config = config

        # Instantiate active check objects
        self._checks: List = self._build_checks()

        # State
        self._decision_log: List[GuardrailDecision] = []
        self._false_positive_count: int = 0   # updated externally via mark_false_positive()
        self._total_messages: int = 0

    # ------------------------------------------------------------------
    # Check construction
    # ------------------------------------------------------------------

    def _build_checks(self) -> List:
        """Construct check instances based on :attr:`config`."""
        checks = []
        if self.config.scc_enabled:
            checks.append(
                SemanticConsistencyCheck(
                    threshold=self.config.scc_threshold,
                    reference_messages=list(self.config.reference_messages),
                )
            )
        if self.config.sac_enabled:
            checks.append(StructuralAnomalyCheck())
        if self.config.capc_enabled:
            checks.append(ProvenanceCheck())
        if self.config.asp_enabled:
            checks.append(
                AnomalyScorePropagation(
                    quarantine_threshold=self.config.asp_threshold
                )
            )
        return checks

    # ------------------------------------------------------------------
    # Core interception
    # ------------------------------------------------------------------

    def intercept(
        self,
        message: str,
        anomaly_score: float = 0.0,
        precomputed_similarity: Optional[float] = None,
        claimed_source: Optional[str] = None,
    ) -> GuardrailDecision:
        """
        Run all active checks on *message* and return a :class:`GuardrailDecision`.

        Parameters
        ----------
        message : str
            The inter-agent message content to evaluate.
        anomaly_score : float
            Running anomaly score carried by this message from prior edges.
            Default ``0.0`` (fresh message).
        precomputed_similarity : float | None
            Pre-computed cosine similarity passed to SCC (if active).
        claimed_source : str | None
            Source identifier claimed in the message, passed to CAPC (if active).

        Returns
        -------
        GuardrailDecision
        """
        t_start = time.perf_counter()

        results: List[CheckResult] = []
        running_score = float(anomaly_score)

        for check in self._checks:
            if isinstance(check, SemanticConsistencyCheck):
                result = check.check(message, precomputed_similarity=precomputed_similarity)
            elif isinstance(check, StructuralAnomalyCheck):
                result = check.check(message)
            elif isinstance(check, ProvenanceCheck):
                result = check.check(message, claimed_source=claimed_source)
            elif isinstance(check, AnomalyScorePropagation):
                # Pass the accumulated Δa from previous checks this round
                accumulated_delta = sum(r.delta_anomaly for r in results)
                result = check.check(
                    message_anomaly_score=accumulated_delta,
                    previous_score=running_score,
                )
            else:
                # Unknown check type — skip
                continue

            results.append(result)
            if result.triggered:
                running_score += result.delta_anomaly

        # Final quarantine decision
        final_score = running_score
        # ASP result (if present) already encodes the combined check; use it
        asp_results = [r for r in results if r.check_name == "ASP"]
        if asp_results:
            final_score = asp_results[-1].details.get("combined_score", running_score)

        passed = final_score <= self.config.asp_threshold

        triggered_checks = [r.check_name for r in results if r.triggered]

        t_end = time.perf_counter()
        latency_ms = (t_end - t_start) * 1_000.0

        decision = GuardrailDecision(
            passed=passed,
            anomaly_score=final_score,
            triggered_checks=triggered_checks,
            check_results=results,
            latency_ms=latency_ms,
        )

        self._decision_log.append(decision)
        self._total_messages += 1

        return decision

    # ------------------------------------------------------------------
    # Trace management
    # ------------------------------------------------------------------

    def add_to_provenance_trace(
        self,
        message: str,
        source_id: str,
        verified: bool = True,
    ) -> None:
        """
        Feed a known-clean message into the CAPC provenance trace
        (if CAPC is active on this guardrail).

        Parameters
        ----------
        message : str
            Clean reference message.
        source_id : str
            Agent that produced it.
        verified : bool
            Whether the source is considered trusted.
        """
        for check in self._checks:
            if isinstance(check, ProvenanceCheck):
                check.add_to_trace(message, source_id=source_id, verified=verified)

    # ------------------------------------------------------------------
    # Metrics / introspection
    # ------------------------------------------------------------------

    def measured_fpr(self) -> float:
        """
        Empirical false-positive rate estimated from the decision log.

        In the absence of ground-truth labels, FPR is approximated as the
        ratio of quarantine decisions to total messages processed.  On a
        clean baseline run this approximates the true FPR.

        Returns
        -------
        float
            FPR estimate ∈ [0, 1].  Returns ``0.0`` if no messages processed.
        """
        if self._total_messages == 0:
            return 0.0
        quarantined = sum(1 for d in self._decision_log if not d.passed)
        return quarantined / self._total_messages

    def mark_false_positive(self, message_id: str) -> bool:
        """
        Mark a quarantine decision as a false positive (requires ground truth
        from a human reviewer or external oracle).

        Parameters
        ----------
        message_id : str
            The ``message_id`` of the :class:`GuardrailDecision` to mark.

        Returns
        -------
        bool
            ``True`` if the decision was found and marked; ``False`` otherwise.
        """
        for decision in self._decision_log:
            if decision.message_id == message_id:
                self._false_positive_count += 1
                return True
        return False

    def effective_transmission_multiplier(self) -> float:
        """
        Returns the miss-rate ``m_e`` — the factor by which this guardrail
        multiplies the edge's transmission probability for adversarial traffic.

        A value of 1.0 means the guardrail provides no protection; 0.0 means
        perfect detection (no adversarial message passes).

        Returns
        -------
        float
            ``config.miss_rate`` ∈ [0, 1].
        """
        return self.config.miss_rate

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def reset_state(self) -> None:
        """
        Reset mutable state: provenance trace, decision log, counters.

        Preserves the active check instances and configuration.
        """
        self._decision_log = []
        self._false_positive_count = 0
        self._total_messages = 0
        for check in self._checks:
            if isinstance(check, ProvenanceCheck):
                check.reset_trace()

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a JSON-serialisable summary."""
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "config": self.config.to_dict(),
            "total_messages": self._total_messages,
            "quarantined": sum(1 for d in self._decision_log if not d.passed),
            "measured_fpr": self.measured_fpr(),
            "false_positive_count": self._false_positive_count,
        }

    def __repr__(self) -> str:
        return (
            f"EdgeGuardrail({self.source_id!r} → {self.target_id!r}, "
            f"tier={self.config.tier.value}, msgs={self._total_messages})"
        )


# ---------------------------------------------------------------------------
# GuardrailLayer
# ---------------------------------------------------------------------------

class GuardrailLayer:
    """
    Topology-aware manager for a collection of :class:`EdgeGuardrail` instances.

    Maintains a dictionary keyed by ``(source_id, target_id)`` and provides
    bulk operations: deploy on all edges, intercept, apply to graph weights,
    emit AutoGen-compatible ``safeguards.json``.

    Parameters
    ----------
    graph : PropagatorGraph
        The underlying agent communication graph.  Used for edge enumeration
        and importance-weighted operations.
    """

    def __init__(self, graph: PropagatorGraph) -> None:
        self._guardrails: Dict[Tuple[str, str], EdgeGuardrail] = {}
        self._graph = graph

    # ------------------------------------------------------------------
    # Deployment
    # ------------------------------------------------------------------

    def deploy(
        self,
        source_id: str,
        target_id: str,
        tier: GuardrailTier,
        reference_messages: Optional[List[str]] = None,
    ) -> EdgeGuardrail:
        """
        Deploy a guardrail on edge (source_id → target_id).

        Replaces any previously deployed guardrail on that edge.

        Parameters
        ----------
        source_id : str
            Sending agent.
        target_id : str
            Receiving agent.
        tier : GuardrailTier
            Configuration preset to use.
        reference_messages : list[str] | None
            Optional clean reference corpus for SCC.

        Returns
        -------
        EdgeGuardrail
            The newly deployed guardrail instance.
        """
        config = GuardrailConfig.from_tier(tier)
        if reference_messages:
            config.reference_messages = list(reference_messages)
        guardrail = EdgeGuardrail(source_id=source_id, target_id=target_id, config=config)
        self._guardrails[(source_id, target_id)] = guardrail
        return guardrail

    def deploy_all(self, tier: GuardrailTier) -> None:
        """
        Deploy *tier* guardrails on **all** edges in the underlying graph.

        Existing guardrails on any edge are replaced.

        Parameters
        ----------
        tier : GuardrailTier
            Configuration preset to apply uniformly.
        """
        for source_id, target_id in self._graph.edge_list():
            self.deploy(source_id, target_id, tier)

    # ------------------------------------------------------------------
    # Edge-level access
    # ------------------------------------------------------------------

    def remove(self, source_id: str, target_id: str) -> None:
        """
        Remove the guardrail on edge (source_id → target_id).

        Raises
        ------
        KeyError
            If no guardrail is deployed on that edge.
        """
        key = (source_id, target_id)
        if key not in self._guardrails:
            raise KeyError(
                f"No guardrail deployed on edge {source_id!r} → {target_id!r}."
            )
        del self._guardrails[key]

    def get(self, source_id: str, target_id: str) -> Optional[EdgeGuardrail]:
        """
        Retrieve the guardrail on edge (source_id → target_id), or ``None``.

        Parameters
        ----------
        source_id : str
        target_id : str

        Returns
        -------
        EdgeGuardrail | None
        """
        return self._guardrails.get((source_id, target_id))

    # ------------------------------------------------------------------
    # Interception
    # ------------------------------------------------------------------

    def intercept(
        self,
        source_id: str,
        target_id: str,
        message: str,
        **kwargs,
    ) -> Optional[GuardrailDecision]:
        """
        Intercept *message* on edge (source_id → target_id).

        Returns ``None`` (pass-through) if no guardrail is deployed on that edge.

        Parameters
        ----------
        source_id : str
        target_id : str
        message : str
        **kwargs
            Additional keyword arguments forwarded to
            :meth:`EdgeGuardrail.intercept` (e.g. ``anomaly_score``,
            ``precomputed_similarity``, ``claimed_source``).

        Returns
        -------
        GuardrailDecision | None
        """
        guard = self._guardrails.get((source_id, target_id))
        if guard is None:
            return None
        return guard.intercept(message, **kwargs)

    # ------------------------------------------------------------------
    # Graph-level operations
    # ------------------------------------------------------------------

    def apply_to_graph_transmission(self) -> PropagatorGraph:
        """
        Return a **deep copy** of the underlying graph with each guarded edge's
        weight multiplied by the deployed guardrail's miss-rate.

        Unguarded edges are unchanged.

        Returns
        -------
        PropagatorGraph
            Modified copy; original graph is not mutated.
        """
        modified = self._graph.copy()
        for (source_id, target_id), guard in self._guardrails.items():
            try:
                edge = modified.get_edge(source_id, target_id)
            except KeyError:
                continue  # edge may have been removed from copy
            new_weight = max(0.0, min(1.0, edge.weight * guard.effective_transmission_multiplier()))
            # Remove and re-add with updated weight
            modified.remove_edge(source_id, target_id)
            from ..graph.core import AgentEdge
            new_edge = AgentEdge(
                source_id=source_id,
                target_id=target_id,
                weight=new_weight,
                context_mode=edge.context_mode,
                metadata=dict(edge.metadata),
            )
            modified.add_edge(new_edge)
        return modified

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def coverage_summary(self) -> dict:
        """
        Return a coverage summary over the underlying graph.

        Returns
        -------
        dict
            Keys: ``total_edges``, ``guarded_edges``, ``unguarded_edges``,
            ``coverage_fraction``, ``tier_distribution`` (dict tier→count).
        """
        total_edges = len(self._graph.edge_list())
        guarded_edges = len(self._guardrails)
        unguarded_edges = total_edges - guarded_edges

        tier_dist: Dict[str, int] = {}
        for guard in self._guardrails.values():
            tier_name = guard.config.tier.value
            tier_dist[tier_name] = tier_dist.get(tier_name, 0) + 1

        coverage_fraction = guarded_edges / total_edges if total_edges > 0 else 0.0

        return {
            "total_edges": total_edges,
            "guarded_edges": guarded_edges,
            "unguarded_edges": unguarded_edges,
            "coverage_fraction": round(coverage_fraction, 4),
            "tier_distribution": tier_dist,
        }

    # ------------------------------------------------------------------
    # AutoGen safeguards.json emission
    # ------------------------------------------------------------------

    def to_safeguards_json(self) -> dict:
        """
        Emit an AutoGen-compatible ``safeguards.json`` structure.

        The ``inter_agent_safeguards.agent_transitions`` list is consumed by
        AutoGen's ``apply_safeguard_policy`` to enforce inter-agent checks.

        Mapping
        -------
        * G0 → ``check_method: "none"``      (no-op transition)
        * G1 → ``check_method: "deterministic"``  (SAC is purely rule-based)
        * G2 → ``check_method: "hybrid"``    (SCC adds semantic component)
        * G3 → ``check_method: "llm"``       (provenance requires richer context)
        * G4 → ``check_method: "llm"``       (full stack)

        Returns
        -------
        dict
            AutoGen safeguards.json-compatible dictionary.
        """
        _method_map: Dict[GuardrailTier, str] = {
            GuardrailTier.G0: "none",
            GuardrailTier.G1: "deterministic",
            GuardrailTier.G2: "hybrid",
            GuardrailTier.G3: "llm",
            GuardrailTier.G4: "llm",
        }

        transitions = []
        for (source_id, target_id), guard in sorted(
            self._guardrails.items(), key=lambda x: (x[0][0], x[0][1])
        ):
            tier = guard.config.tier
            transitions.append(
                {
                    "message_source": source_id,
                    "message_destination": target_id,
                    "check_method": _method_map[tier],
                    "action": "block",
                    "tier": tier.value,
                    "expected_fpr": guard.config.expected_fpr,
                    "miss_rate": guard.config.miss_rate,
                }
            )

        return {
            "inter_agent_safeguards": {
                "agent_transitions": transitions
            }
        }

    # ------------------------------------------------------------------
    # Iteration / length
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._guardrails)

    def __iter__(self):
        return iter(self._guardrails.values())

    def __repr__(self) -> str:
        return (
            f"GuardrailLayer(graph={self._graph.name!r}, "
            f"guardrails={len(self._guardrails)})"
        )

    def to_dict(self) -> dict:
        """Return a JSON-serialisable summary of the layer."""
        return {
            "graph_name": self._graph.name,
            "guardrails": [g.to_dict() for g in self._guardrails.values()],
            "coverage_summary": self.coverage_summary(),
        }
