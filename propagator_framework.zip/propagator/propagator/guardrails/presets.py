"""
propagator.guardrails.presets
==============================
Convenience factory functions for topology-aware guardrail placement.

All functions return a :class:`~.guardrail.GuardrailLayer` with guardrails
pre-deployed according to the selected strategy.

Available strategies
--------------------
* :func:`topology_conditional_guardrails` — topology-adaptive preset based on
  graph topology classification (star, chain, tree, …).
* :func:`minimum_vertex_cut_guardrails` — deploy on edges incident to minimum
  vertex-cut nodes (bottleneck protection).
* :func:`budget_greedy_guardrails` — greedy importance-weighted placement up
  to a fixed edge-count budget.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

import networkx as nx

from ..graph.graph import PropagatorGraph
from .guardrail import EdgeGuardrail, GuardrailLayer, GuardrailTier


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _in_degree(graph: PropagatorGraph, node_id: str) -> int:
    """Return the in-degree of *node_id*."""
    return len(graph.get_predecessors(node_id))


def _out_degree(graph: PropagatorGraph, node_id: str) -> int:
    """Return the out-degree of *node_id*."""
    return len(graph.get_neighbors(node_id))


def _degree(graph: PropagatorGraph, node_id: str) -> int:
    return _in_degree(graph, node_id) + _out_degree(graph, node_id)


def _hub_nodes(graph: PropagatorGraph) -> Set[str]:
    """
    Return nodes whose degree is more than 2× the mean degree.
    Used to identify hubs in star / star-ring topologies.
    """
    node_ids = graph.node_ids()
    if not node_ids:
        return set()
    degrees = {n: _degree(graph, n) for n in node_ids}
    mean_deg = sum(degrees.values()) / len(degrees)
    threshold = 2.0 * mean_deg
    return {n for n, d in degrees.items() if d >= threshold}


def _leaf_nodes(graph: PropagatorGraph) -> Set[str]:
    """Return nodes with total degree ≤ 1 (leaves in a tree / star)."""
    return {n for n in graph.node_ids() if _degree(graph, n) <= 1}


def _edge_importance(
    graph: PropagatorGraph,
    source_id: str,
    target_id: str,
) -> float:
    """
    Importance weight of edge (source → target).

    Defined as:  w_ij * μ(target)

    Higher weight = guarding this edge matters more for blast-radius reduction.
    """
    try:
        edge = graph.get_edge(source_id, target_id)
        target_node = graph.get_agent(target_id)
        return edge.weight * target_node.importance
    except KeyError:
        return 0.0


# ---------------------------------------------------------------------------
# topology_conditional_guardrails
# ---------------------------------------------------------------------------

def topology_conditional_guardrails(
    graph: PropagatorGraph,
    topology_type: str,
) -> GuardrailLayer:
    """
    Deploy guardrails according to topology-conditional recommendations.

    The topology type determines which tier is applied to which edges:

    ==================  =====================================================
    topology_type       Deployment strategy
    ==================  =====================================================
    ``"star"``          G4 on hub-outbound edges; G1 on leaf-to-hub edges
    ``"chain"``         G2 uniform on all edges
    ``"complete"``      G3 on all edges (advise topology restructuring if R₀>1)
    ``"tree"``          G2 on root-to-child edges; G1 on leaf edges
    ``"ring"``          G2 uniform on all edges
    ``"layered_dag"``   G2 on cross-layer edges; G1 on same-layer edges
    ``"star_ring"``     G4 on hub edges; G2 on ring edges
    ``"decentralized_mesh"`` G1 on all edges (low value from edge guards alone)
    (default)           G2 uniform on all edges
    ==================  =====================================================

    Parameters
    ----------
    graph : PropagatorGraph
        The agent communication graph.
    topology_type : str
        One of the topology labels above (case-insensitive).

    Returns
    -------
    GuardrailLayer
        Layer with guardrails deployed per the strategy.
    """
    layer = GuardrailLayer(graph)
    topo = topology_type.lower().strip()

    edges = graph.edge_list()
    if not edges:
        return layer

    # ------------------------------------------------------------------
    # star
    # ------------------------------------------------------------------
    if topo == "star":
        hubs = _hub_nodes(graph)
        for src, tgt in edges:
            if src in hubs:
                # Hub → leaf: outbound from hub — highest risk
                layer.deploy(src, tgt, GuardrailTier.G4)
            else:
                # Leaf → hub: inbound to hub
                layer.deploy(src, tgt, GuardrailTier.G1)

    # ------------------------------------------------------------------
    # chain
    # ------------------------------------------------------------------
    elif topo == "chain":
        for src, tgt in edges:
            layer.deploy(src, tgt, GuardrailTier.G2)

    # ------------------------------------------------------------------
    # complete
    # ------------------------------------------------------------------
    elif topo == "complete":
        # Every edge is a potential propagation pathway; G3 across the board.
        # Note: for complete graphs with R₀>1, topology restructuring should
        # be prioritised over guardrail placement alone.
        for src, tgt in edges:
            layer.deploy(src, tgt, GuardrailTier.G3)

    # ------------------------------------------------------------------
    # tree
    # ------------------------------------------------------------------
    elif topo == "tree":
        leaves = _leaf_nodes(graph)
        for src, tgt in edges:
            if src in leaves or tgt in leaves:
                layer.deploy(src, tgt, GuardrailTier.G1)
            else:
                # Internal / root-to-child edges
                layer.deploy(src, tgt, GuardrailTier.G2)

    # ------------------------------------------------------------------
    # ring
    # ------------------------------------------------------------------
    elif topo == "ring":
        for src, tgt in edges:
            layer.deploy(src, tgt, GuardrailTier.G2)

    # ------------------------------------------------------------------
    # layered_dag
    # ------------------------------------------------------------------
    elif topo == "layered_dag":
        # Determine topological layers via longest-path / BFS depth
        try:
            _nx_graph = graph._graph
            # Compute generation / layer as the longest path from any source
            generations: Dict[str, int] = {}
            # BFS from all nodes with in-degree 0
            sources = [n for n in _nx_graph.nodes if _nx_graph.in_degree(n) == 0]
            if not sources:
                # No true source; fall back to G2 uniform
                for src, tgt in edges:
                    layer.deploy(src, tgt, GuardrailTier.G2)
                return layer
            for src in sources:
                for n in nx.descendants(_nx_graph, src) | {src}:
                    try:
                        depth = nx.dag_longest_path_length(
                            _nx_graph.subgraph(
                                nx.ancestors(_nx_graph, n) | {n}
                            )
                        )
                    except Exception:
                        depth = 0
                    if n not in generations or depth > generations[n]:
                        generations[n] = depth
        except Exception:
            generations = {}

        for src, tgt in edges:
            src_layer = generations.get(src, 0)
            tgt_layer = generations.get(tgt, 0)
            if src_layer != tgt_layer:
                # Cross-layer: higher tier
                layer.deploy(src, tgt, GuardrailTier.G2)
            else:
                # Same-layer (lateral): lower tier
                layer.deploy(src, tgt, GuardrailTier.G1)

    # ------------------------------------------------------------------
    # star_ring
    # ------------------------------------------------------------------
    elif topo == "star_ring":
        hubs = _hub_nodes(graph)
        for src, tgt in edges:
            if src in hubs or tgt in hubs:
                layer.deploy(src, tgt, GuardrailTier.G4)
            else:
                layer.deploy(src, tgt, GuardrailTier.G2)

    # ------------------------------------------------------------------
    # decentralized_mesh
    # ------------------------------------------------------------------
    elif topo in ("decentralized_mesh", "mesh"):
        # Edge guards alone provide limited value in a highly connected mesh.
        # Lightweight structural check on all edges.
        for src, tgt in edges:
            layer.deploy(src, tgt, GuardrailTier.G1)

    # ------------------------------------------------------------------
    # default
    # ------------------------------------------------------------------
    else:
        for src, tgt in edges:
            layer.deploy(src, tgt, GuardrailTier.G2)

    return layer


# ---------------------------------------------------------------------------
# minimum_vertex_cut_guardrails
# ---------------------------------------------------------------------------

def minimum_vertex_cut_guardrails(
    graph: PropagatorGraph,
    tier: GuardrailTier = GuardrailTier.G3,
) -> GuardrailLayer:
    """
    Deploy guardrails on all edges **incident** to minimum vertex-cut nodes.

    Minimum vertex-cut nodes are the smallest set whose removal disconnects
    the graph (or maximally reduces connectivity).  Guarding edges at these
    bottleneck nodes provides the highest per-node return on investment.

    Parameters
    ----------
    graph : PropagatorGraph
        The agent communication graph.
    tier : GuardrailTier
        Tier to deploy on identified edges.  Defaults to G3.

    Returns
    -------
    GuardrailLayer
        Layer with guardrails on all edges incident to cut nodes.

    Notes
    -----
    The minimum vertex cut is computed on the underlying NetworkX DiGraph.
    For disconnected graphs, the function processes each weakly-connected
    component separately.
    """
    layer = GuardrailLayer(graph)
    nx_graph = graph._graph

    if len(nx_graph) == 0:
        return layer

    cut_nodes: Set[str] = set()

    # NetworkX connectivity requires at least 2 nodes
    if len(nx_graph) >= 2:
        # Work on weakly-connected components
        for component in nx.weakly_connected_components(nx_graph):
            subgraph = nx_graph.subgraph(component).copy()
            if len(subgraph) < 2:
                continue
            try:
                # Use approximate vertex connectivity for efficiency
                # minimum_node_cut returns the actual cut set
                cut = nx.minimum_node_cut(subgraph.to_undirected())
                cut_nodes.update(cut)
            except nx.NetworkXError:
                # Graph is already disconnected or trivially connected
                continue
            except Exception:
                # Fall back: use betweenness-centrality top nodes
                bc = nx.betweenness_centrality(subgraph)
                if bc:
                    max_bc_node = max(bc, key=bc.get)  # type: ignore[arg-type]
                    cut_nodes.add(max_bc_node)

    # Deploy on all edges incident to cut nodes
    guarded: Set[Tuple[str, str]] = set()
    for src, tgt in graph.edge_list():
        if src in cut_nodes or tgt in cut_nodes:
            if (src, tgt) not in guarded:
                layer.deploy(src, tgt, tier)
                guarded.add((src, tgt))

    return layer


# ---------------------------------------------------------------------------
# budget_greedy_guardrails
# ---------------------------------------------------------------------------

def budget_greedy_guardrails(
    graph: PropagatorGraph,
    budget: int,
    tier: GuardrailTier = GuardrailTier.G2,
    importance_weighted: bool = True,
) -> GuardrailLayer:
    """
    Greedy guardrail placement within a fixed edge-count budget.

    At each step the algorithm picks the unguarded edge that maximally
    reduces the importance-weighted blast radius and deploys a guardrail,
    until *budget* guardrails have been deployed.

    Blast-radius reduction per edge is approximated as:

      gain(e) = importance(e) * (1 - miss_rate(tier))

    where ``importance(e) = w_{ij} * μ(target)`` (edge weight × target
    importance).

    If *importance_weighted* is ``False``, all edges are treated as equally
    important (uniform random greedy — equivalent to picking edges with highest
    weight).

    Parameters
    ----------
    graph : PropagatorGraph
        The agent communication graph.
    budget : int
        Maximum number of guardrails to deploy.  If budget ≥ |E| all edges
        are guarded.
    tier : GuardrailTier
        Tier to deploy on each selected edge.
    importance_weighted : bool
        Use importance-weighted scoring if ``True`` (default); otherwise use
        uniform scoring.

    Returns
    -------
    GuardrailLayer
        Layer with up to *budget* guardrails on the highest-value edges.
    """
    layer = GuardrailLayer(graph)

    edges = graph.edge_list()
    if not edges or budget <= 0:
        return layer

    # Pre-compute tier miss-rate
    from .guardrail import GuardrailConfig
    miss_rate = GuardrailConfig.from_tier(tier).miss_rate
    detection_rate = 1.0 - miss_rate  # gain per unit importance

    # Score each edge
    edge_scores: List[Tuple[float, str, str]] = []
    for src, tgt in edges:
        if importance_weighted:
            importance = _edge_importance(graph, src, tgt)
        else:
            try:
                importance = graph.get_edge(src, tgt).weight
            except KeyError:
                importance = 1.0
        gain = importance * detection_rate
        edge_scores.append((gain, src, tgt))

    # Sort descending by gain
    edge_scores.sort(key=lambda x: x[0], reverse=True)

    # Deploy on top-*budget* edges
    deployed = 0
    for gain, src, tgt in edge_scores:
        if deployed >= budget:
            break
        layer.deploy(src, tgt, tier)
        deployed += 1

    return layer
