"""
propagator.sim.engine
=====================
Core SIR-on-graph simulation engine for the PROPAGATOR framework.

Mathematical model
------------------
Infection level I_i(t) ∈ [0, 1] per agent (fraction of outputs carrying
adversarial signal):

    dI_i/dt = β · Σ_{j:(j,i)∈E} p_ji · I_j(t) · (1 - I_i(t))  −  γ · I_i(t)

Discretised (per-round):

    I_i(t+1) = clamp(
        I_i(t)
        + β · Σ_j p_ji · I_j(t) · (1 - I_i(t))
        − γ · I_i(t),
        0, 1
    )

R₀ is defined as the leading eigenvalue (λ_max) of the transmission-weighted
adjacency matrix W where W[i, j] = p_ji (weight on directed edge j → i).
R₀ > 1 implies self-sustaining spread in the absence of recovery.
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import numpy.linalg as nla

from ..graph import AgentNode, PropagatorGraph
from .attacks import ATTACK_BASE_RATES, AttackConfig, AttackResult, AttackType

logger = logging.getLogger(__name__)


class SimulationEngine:
    """Runs controlled adversarial-injection experiments on a topology graph.

    Parameters
    ----------
    graph:
        The :class:`PropagatorGraph` topology to simulate over.
    beta:
        Base infection rate (β).  The effective rate is scaled by each attack
        type's ``ATTACK_BASE_RATES`` value at runtime.
    gamma:
        Recovery / detection rate (γ).  Set to ``0.0`` for worst-case analysis.
    infection_threshold:
        Nodes are counted as "infected" (for Ī and attack-path tracking) when
        I_i exceeds this threshold.
    rounds:
        Number of discrete time-steps T per trial.
    random_seed:
        Optional integer seed for reproducibility.  When provided, a
        :class:`numpy.random.Generator` is constructed from this seed and
        used for any stochastic operations.
    """

    def __init__(
        self,
        graph: PropagatorGraph,
        beta: float = 0.3,
        gamma: float = 0.0,
        infection_threshold: float = 0.5,
        rounds: int = 20,
        random_seed: Optional[int] = None,
    ) -> None:
        self.graph = graph
        self.beta = beta
        self.gamma = gamma
        self.infection_threshold = infection_threshold
        self.rounds = rounds
        self.random_seed = random_seed

        self._rng: np.random.Generator = np.random.default_rng(random_seed)

        # Cache the ordered list of node IDs so index ↔ id conversion is O(1).
        self._node_ids: list[str] = graph.node_ids()
        self._node_index: dict[str, int] = {
            nid: idx for idx, nid in enumerate(self._node_ids)
        }
        # Build and cache the transmission-weight matrix W (shape N×N).
        # W[i, j] = transmission probability on directed edge j → i.
        self._W: np.ndarray = self._build_weight_matrix()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_weight_matrix(self) -> np.ndarray:
        """Construct the transmission-weight matrix from the graph.

        ``W[i, j]`` represents the per-edge transmission weight on the directed
        edge from node j to node i (i.e., j infects i).  The weight is taken
        from ``AgentEdge.weight`` (the ``W(e)`` field in the graph model).

        Returns
        -------
        np.ndarray
            Shape ``(N, N)`` float64 array.
        """
        n = len(self._node_ids)
        W = np.zeros((n, n), dtype=np.float64)
        # graph._edges is a dict[(source_id, target_id), AgentEdge]
        for (src_id, tgt_id), edge in self.graph._edges.items():
            src_idx = self._node_index.get(src_id)
            tgt_idx = self._node_index.get(tgt_id)
            if src_idx is None or tgt_idx is None:
                continue
            # W[target, source] = weight on edge source → target
            W[tgt_idx, src_idx] = float(edge.weight)
        return W

    def _effective_beta(self, attack_config: AttackConfig) -> float:
        """Return β scaled by the attack-type base persistence rate."""
        scale = ATTACK_BASE_RATES.get(attack_config.attack_type, 1.0)
        return self.beta * scale

    def _override_weight_matrix(self, attack_config: AttackConfig) -> np.ndarray:
        """Return W, optionally with all non-zero weights replaced by the override.

        When ``attack_config.semantic_similarity_override`` is set, every
        non-zero entry in W is replaced with that constant value.  This lets
        callers do sensitivity analysis by neutralising per-edge heterogeneity.
        """
        if attack_config.semantic_similarity_override is not None:
            W = self._W.copy()
            mask = W > 0
            W[mask] = float(attack_config.semantic_similarity_override)
            return W
        return self._W

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute_r0(self) -> float:
        """Compute the basic reproduction number R₀ for the current graph.

        R₀ is the spectral radius (maximum real part of eigenvalues) of the
        transmission-weighted adjacency matrix W scaled by β.

        Returns
        -------
        float
            Leading real eigenvalue of ``β · W``.  Returns ``0.0`` for
            degenerate (empty or single-node) graphs and for zero-weight
            matrices.
        """
        n = len(self._node_ids)
        if n <= 1:
            logger.debug("compute_r0: degenerate graph (n=%d), returning 0.0", n)
            return 0.0
        if not np.any(self._W):
            logger.debug("compute_r0: zero weight matrix, returning 0.0")
            return 0.0
        scaled = self.beta * self._W
        eigvals = nla.eigvals(scaled)
        r0 = float(np.max(np.real(eigvals)))
        logger.debug("compute_r0: R₀ = %.6f", r0)
        return r0

    def run_trial(self, attack_config: AttackConfig) -> dict[str, list[float]]:
        """Run a single discrete SIR trial for ``self.rounds`` rounds.

        The seed node is initialised to ``attack_config.injection_strength``
        and all other nodes start at ``0``.  The update rule is applied
        **simultaneously** (synchronous update) each round.

        Parameters
        ----------
        attack_config:
            Specifies the attack type, injection strength, and seed node.

        Returns
        -------
        dict[str, list[float]]
            Mapping ``node_id → trajectory``.  Each trajectory is a list of
            ``rounds + 1`` floats: I_i(0), I_i(1), …, I_i(T).

        Raises
        ------
        ValueError
            If ``attack_config.seed_node_id`` is not present in the graph.
        """
        seed_id = attack_config.seed_node_id
        if seed_id not in self._node_index:
            raise ValueError(
                f"Seed node {seed_id!r} not found in graph "
                f"(available: {self._node_ids[:5]}…)"
            )

        n = len(self._node_ids)
        beta_eff = self._effective_beta(attack_config)
        W = self._override_weight_matrix(attack_config)

        # I[i] = infection level for node i at the current round.
        I = np.zeros(n, dtype=np.float64)
        I[self._node_index[seed_id]] = float(attack_config.injection_strength)

        # trajectories[i] = list of I_i values over time (length rounds+1).
        trajectories: list[list[float]] = [[float(I[i])] for i in range(n)]

        for _ in range(self.rounds):
            # Inflow from predecessors: W[i, j] * I[j] summed over j  (matrix-vector)
            inflow = W @ I  # shape (n,)
            dI = beta_eff * inflow * (1.0 - I) - self.gamma * I
            I = np.clip(I + dI, 0.0, 1.0)
            for i in range(n):
                trajectories[i].append(float(I[i]))

        return {self._node_ids[i]: trajectories[i] for i in range(n)}

    def run_experiment(self, attack_config: AttackConfig) -> AttackResult:
        """Run ``attack_config.trials`` independent trials and aggregate results.

        Uses vectorised NumPy operations wherever possible.

        Parameters
        ----------
        attack_config:
            Full experiment specification.

        Returns
        -------
        AttackResult
            Populated with trajectories, final infection rates, peak
            velocities, and attack paths from all trials.

        Raises
        ------
        ValueError
            If ``attack_config.seed_node_id`` is not in the graph.
        """
        n = len(self._node_ids)
        beta_eff = self._effective_beta(attack_config)
        W = self._override_weight_matrix(attack_config)

        seed_idx = self._node_index.get(attack_config.seed_node_id)
        if seed_idx is None:
            raise ValueError(
                f"Seed node {attack_config.seed_node_id!r} not found in graph."
            )

        all_trajectories: list[dict[str, list[float]]] = []
        all_final_rates: list[float] = []
        all_peak_velocities: list[float] = []
        all_attack_paths: list[list[str]] = []

        for trial_idx in range(attack_config.trials):
            # --- initialise ---------------------------------------------------
            I = np.zeros(n, dtype=np.float64)
            I[seed_idx] = float(attack_config.injection_strength)

            # traj_arr[t, i] = I_i at round t; shape (rounds+1, n)
            traj_arr = np.empty((self.rounds + 1, n), dtype=np.float64)
            traj_arr[0] = I

            peak_vel = 0.0
            for t in range(self.rounds):
                inflow = W @ I  # (n,)
                dI = beta_eff * inflow * (1.0 - I) - self.gamma * I
                # Track peak aggregate velocity (L1 norm of the update vector).
                vel = float(np.sum(np.abs(dI)))
                if vel > peak_vel:
                    peak_vel = vel
                I = np.clip(I + dI, 0.0, 1.0)
                traj_arr[t + 1] = I

            # --- aggregate ----------------------------------------------------
            # Ī: fraction of nodes above infection_threshold at the final round.
            final_I = traj_arr[self.rounds]
            final_rate = float(np.mean(final_I > self.infection_threshold))

            # Attack path: nodes ordered by the first round they crossed threshold.
            exceeded = traj_arr > self.infection_threshold  # (rounds+1, n) bool
            first_exceeded = np.full(n, self.rounds + 2, dtype=np.int64)
            for i in range(n):
                where = np.where(exceeded[:, i])[0]
                if where.size > 0:
                    first_exceeded[i] = int(where[0])
            path_indices = np.argsort(first_exceeded)
            attack_path = [
                self._node_ids[i]
                for i in path_indices
                if first_exceeded[i] <= self.rounds
            ]

            # Convert traj_arr to dict form for storage.
            traj_dict: dict[str, list[float]] = {
                self._node_ids[i]: traj_arr[:, i].tolist() for i in range(n)
            }

            all_trajectories.append(traj_dict)
            all_final_rates.append(final_rate)
            all_peak_velocities.append(peak_vel)
            all_attack_paths.append(attack_path)

            logger.debug(
                "Trial %d/%d — final_rate=%.4f, peak_vel=%.4f",
                trial_idx + 1,
                attack_config.trials,
                final_rate,
                peak_vel,
            )

        return AttackResult(
            attack_config=attack_config,
            infection_trajectories=all_trajectories,
            final_infection_rates=all_final_rates,
            peak_velocities=all_peak_velocities,
            attack_paths=all_attack_paths,
        )

    def run_full_matrix(
        self,
        attack_types: Optional[list[AttackType]] = None,
        seed_nodes: Optional[list[str]] = None,
        trials: int = 30,
    ) -> dict[tuple[AttackType, str], AttackResult]:
        """Cross-product sweep: all attack types × all seed nodes.

        Parameters
        ----------
        attack_types:
            Subset of :class:`AttackType` members to sweep.  Defaults to all
            five attack types.
        seed_nodes:
            Node IDs to use as injection seeds.  Defaults to every node in the
            graph.
        trials:
            Number of trials per (attack_type, seed_node) cell.

        Returns
        -------
        dict
            Mapping ``(AttackType, seed_node_id) → AttackResult``.
        """
        if attack_types is None:
            attack_types = list(AttackType)
        if seed_nodes is None:
            seed_nodes = self._node_ids

        results: dict[tuple[AttackType, str], AttackResult] = {}
        total = len(attack_types) * len(seed_nodes)
        count = 0
        for at in attack_types:
            for seed in seed_nodes:
                count += 1
                logger.info(
                    "run_full_matrix [%d/%d]: attack=%s seed=%s",
                    count,
                    total,
                    at.value,
                    seed,
                )
                cfg = AttackConfig(
                    attack_type=at,
                    injection_strength=1.0,
                    seed_node_id=seed,
                    trials=trials,
                )
                results[(at, seed)] = self.run_experiment(cfg)
        return results

    def calibrate_r0_threshold(self) -> bool:
        """Test whether R₀ exceeds the critical threshold of 1.

        Returns
        -------
        bool
            ``True`` if R₀ > 1 (self-sustaining spread expected);
            ``False`` otherwise.
        """
        r0 = self.compute_r0()
        logger.info(
            "calibrate_r0_threshold: R₀ = %.6f → sustaining=%s", r0, r0 > 1.0
        )
        return r0 > 1.0

    def set_transmission_weights_from_calibration(
        self, calibration_data: dict[str, dict[str, float]]
    ) -> None:
        """Update graph edge transmission weights from calibration resistance scores.

        For each directed edge (source → target) in the graph the new
        transmission weight is derived from the *target* node's mean resistance
        score across all attack types present in the calibration data:

        .. code-block:: none

            w_new = 1 - mean_resistance(target_node)

        If the calibration data contains no entry for a given target node, the
        existing edge weight is left unchanged.

        Parameters
        ----------
        calibration_data:
            Nested dict ``node_id → attack_type_value → resistance_score``.
            Values are resistance scores ∈ [0, 1]; higher means more resistant
            (and therefore lower transmission probability).
        """
        updated = 0
        for (src_id, tgt_id), edge in self.graph._edges.items():
            if tgt_id not in calibration_data:
                continue
            node_cal = calibration_data[tgt_id]
            if not node_cal:
                continue
            mean_resistance = float(np.mean(list(node_cal.values())))
            new_weight = float(np.clip(1.0 - mean_resistance, 0.0, 1.0))
            edge.weight = new_weight
            updated += 1

        # Rebuild the cached weight matrix so future calls reflect the new weights.
        self._W = self._build_weight_matrix()
        logger.info(
            "set_transmission_weights_from_calibration: updated %d edges", updated
        )
