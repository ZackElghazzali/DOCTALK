"""
propagator.sim.runner
=====================
High-level experiment orchestration for the PROPAGATOR framework.

Provides:

* :class:`ExperimentRunner` — sweeps heterogeneity levels and builds the full
  4-D vulnerability tensor (topology × attack_type × seed_node → AttackResult).
* :class:`CalibrationPhase` — estimates per-node, per-attack resistance scores
  using isolated single-agent trials (no real LLM; purely numerical).
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np

from ..graph import AgentNode, PropagatorGraph
from .attacks import ATTACK_BASE_RATES, AttackConfig, AttackResult, AttackType
from .engine import SimulationEngine

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# ExperimentRunner
# ---------------------------------------------------------------------------


class ExperimentRunner:
    """Orchestrates multi-topology, multi-attack sweeps.

    Parameters
    ----------
    engine:
        A configured :class:`SimulationEngine`.  When running multi-topology
        sweeps, a fresh engine is cloned for each topology using the same
        hyperparameters (β, γ, rounds, etc.).
    """

    def __init__(self, engine: SimulationEngine) -> None:
        self.engine = engine

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _engine_for_graph(self, graph: PropagatorGraph) -> SimulationEngine:
        """Return a :class:`SimulationEngine` configured identically to
        ``self.engine`` but operating on *graph*.

        Preserves β, γ, infection_threshold, rounds, and random_seed while
        swapping in the new topology.
        """
        return SimulationEngine(
            graph=graph,
            beta=self.engine.beta,
            gamma=self.engine.gamma,
            infection_threshold=self.engine.infection_threshold,
            rounds=self.engine.rounds,
            random_seed=self.engine.random_seed,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_hst_sweep(
        self,
        heterogeneity_levels: list[str],
        topology_graphs: dict[str, PropagatorGraph],
        attack_type: AttackType = AttackType.CONTEXT_POISONING,
        trials: int = 30,
    ) -> dict[str, dict[str, AttackResult]]:
        """Sweep heterogeneity-variance levels across multiple topologies.

        For each combination of *heterogeneity_level* × *topology*, a fixed
        injection-strength attack is launched from every node in the graph and
        the results are combined.  Heterogeneity labels map to injection
        strengths as follows:

        * ``"low"``    → injection_strength = 0.3
        * ``"medium"`` → injection_strength = 0.6
        * ``"high"``   → injection_strength = 1.0

        Parameters
        ----------
        heterogeneity_levels:
            Ordered list of heterogeneity labels, e.g.
            ``["low", "medium", "high"]``.
        topology_graphs:
            Mapping *topology_name → PropagatorGraph*.
        attack_type:
            The attack mechanism to use for all cells.
        trials:
            Trials per (topology, seed_node) cell.

        Returns
        -------
        dict[str, dict[str, AttackResult]]
            Nested mapping
            ``heterogeneity_level → topology_name → AttackResult``.
            The :class:`AttackResult` aggregates data across all seed nodes
            (trajectories, rates, and paths are concatenated across seeds).
        """
        strength_map: dict[str, float] = {"low": 0.3, "medium": 0.6, "high": 1.0}
        output: dict[str, dict[str, AttackResult]] = {}

        for level in heterogeneity_levels:
            injection_strength = strength_map.get(level, 1.0)
            output[level] = {}

            for topo_name, graph in topology_graphs.items():
                node_ids = graph.node_ids()
                if not node_ids:
                    logger.warning(
                        "run_hst_sweep: topology %r has no nodes — skipping.", topo_name
                    )
                    continue

                logger.info(
                    "run_hst_sweep: level=%s topology=%s attack=%s nodes=%d",
                    level,
                    topo_name,
                    attack_type.value,
                    len(node_ids),
                )
                eng = self._engine_for_graph(graph)

                # Use the first node as a placeholder seed for the combined config.
                combined_cfg = AttackConfig(
                    attack_type=attack_type,
                    injection_strength=injection_strength,
                    seed_node_id=node_ids[0],
                    trials=trials,
                )
                combined = AttackResult(attack_config=combined_cfg)

                for seed_id in node_ids:
                    cfg = AttackConfig(
                        attack_type=attack_type,
                        injection_strength=injection_strength,
                        seed_node_id=seed_id,
                        trials=trials,
                    )
                    result = eng.run_experiment(cfg)
                    combined.infection_trajectories.extend(result.infection_trajectories)
                    combined.final_infection_rates.extend(result.final_infection_rates)
                    combined.peak_velocities.extend(result.peak_velocities)
                    combined.attack_paths.extend(result.attack_paths)

                output[level][topo_name] = combined

        return output

    def run_full_empirical_map(
        self,
        topology_graphs: dict[str, PropagatorGraph],
        attack_types: Optional[list[AttackType]] = None,
        trials: int = 30,
    ) -> dict[str, dict[AttackType, dict[str, AttackResult]]]:
        """Build the full 4-D vulnerability tensor.

        Dimensions: topology × attack_type × seed_node → :class:`AttackResult`.

        Parameters
        ----------
        topology_graphs:
            Mapping *topology_name → PropagatorGraph*.
        attack_types:
            Attack types to sweep.  Defaults to all five.
        trials:
            Trials per leaf cell.

        Returns
        -------
        dict
            Nested dict:
            ``topology_name → AttackType → seed_node_id → AttackResult``.
        """
        if attack_types is None:
            attack_types = list(AttackType)

        output: dict[str, dict[AttackType, dict[str, AttackResult]]] = {}

        for topo_name, graph in topology_graphs.items():
            node_ids = graph.node_ids()
            logger.info(
                "run_full_empirical_map: topology=%s nodes=%d", topo_name, len(node_ids)
            )
            eng = self._engine_for_graph(graph)

            topo_results: dict[AttackType, dict[str, AttackResult]] = {}
            for at in attack_types:
                at_results: dict[str, AttackResult] = {}
                for seed_id in node_ids:
                    logger.debug(
                        "run_full_empirical_map: topo=%s attack=%s seed=%s",
                        topo_name,
                        at.value,
                        seed_id,
                    )
                    cfg = AttackConfig(
                        attack_type=at,
                        injection_strength=1.0,
                        seed_node_id=seed_id,
                        trials=trials,
                    )
                    at_results[seed_id] = eng.run_experiment(cfg)
                topo_results[at] = at_results
            output[topo_name] = topo_results

        return output

    def compute_topology_r0_spread(
        self, topology_graphs: dict[str, PropagatorGraph]
    ) -> dict[str, float]:
        """Compute R₀ for each topology in the supplied mapping.

        Parameters
        ----------
        topology_graphs:
            Mapping *topology_name → PropagatorGraph*.

        Returns
        -------
        dict[str, float]
            ``topology_name → R₀`` for each graph.
        """
        r0_map: dict[str, float] = {}
        for topo_name, graph in topology_graphs.items():
            eng = self._engine_for_graph(graph)
            r0 = eng.compute_r0()
            logger.info(
                "compute_topology_r0_spread: %s → R₀=%.6f", topo_name, r0
            )
            r0_map[topo_name] = r0
        return r0_map


# ---------------------------------------------------------------------------
# CalibrationPhase
# ---------------------------------------------------------------------------


class CalibrationPhase:
    """Estimates per-node, per-attack resistance scores.

    Calibration runs isolated *single-agent* trials — one node at a time with
    no inter-node propagation — to measure how often that node would comply
    with an adversarial prompt.  Because no real LLM is invoked, compliance
    probability is modelled as:

    .. code-block:: none

        p_comply = (1 - hardening_level/2 * 0.5) * ATTACK_BASE_RATES[attack_type]

    Gaussian noise with σ = 0.05 is added to each trial draw to simulate
    measurement variance.  The resistance estimate is:

    .. code-block:: none

        r_i = 1 - mean(complied_across_trials)    (∈ [0, 1])

    Attributes
    ----------
    rng:
        Internal :class:`numpy.random.Generator`.  Seeded if a seed is
        supplied at construction time.
    """

    def __init__(self, random_seed: Optional[int] = None) -> None:
        self.rng: np.random.Generator = np.random.default_rng(random_seed)

    def run(
        self,
        graph: PropagatorGraph,
        attack_types: list[AttackType],
        trials_per_cell: int = 100,
    ) -> dict[str, dict[str, float]]:
        """Run single-agent resistance calibration for every node × attack type.

        For each (node, attack_type) cell, ``trials_per_cell`` isolated trials
        are simulated.  In each trial a compliance probability is drawn (with
        additive Gaussian noise) and compared to a Uniform(0,1) sample.  The
        fraction of trials in which the node *resisted* (did not comply) is the
        resistance estimate r_i.

        Parameters
        ----------
        graph:
            The topology to calibrate.
        attack_types:
            Attack types to include in the calibration matrix.
        trials_per_cell:
            Number of Monte-Carlo draws per (node, attack_type) cell.

        Returns
        -------
        dict[str, dict[str, float]]
            Nested mapping ``node_id → attack_type_value → r_i ∈ [0, 1]``.
        """
        calibration: dict[str, dict[str, float]] = {}

        for node_id in graph.node_ids():
            node: AgentNode = graph.get_agent(node_id)
            node_cal: dict[str, float] = {}

            # hardening_level ∈ {0, 1, 2} per the AgentNode spec.
            hardening = float(np.clip(node.hardening_level, 0, 2))

            for at in attack_types:
                base_rate = ATTACK_BASE_RATES.get(at, 0.5)

                # Deterministic compliance probability for this (node, attack) cell.
                # Formula: (1 - hardening/2 * 0.5) * base_rate
                p_comply_base = (1.0 - (hardening / 2.0) * 0.5) * base_rate

                # Add measurement noise to each trial's compliance probability.
                noise = self.rng.normal(0.0, 0.05, size=trials_per_cell)
                p_comply_noisy = np.clip(p_comply_base + noise, 0.0, 1.0)

                # Bernoulli compliance draw: complied if Uniform(0,1) < p_comply.
                u = self.rng.uniform(0.0, 1.0, size=trials_per_cell)
                complied = u < p_comply_noisy

                # Resistance = fraction of trials where node did NOT comply.
                r_i = float(1.0 - np.mean(complied))
                r_i = float(np.clip(r_i, 0.0, 1.0))

                logger.debug(
                    "CalibrationPhase: node=%s attack=%s hardening=%d "
                    "p_comply_base=%.4f r_i=%.4f",
                    node_id,
                    at.value,
                    int(hardening),
                    p_comply_base,
                    r_i,
                )
                node_cal[at.value] = r_i

            calibration[node_id] = node_cal

        return calibration
