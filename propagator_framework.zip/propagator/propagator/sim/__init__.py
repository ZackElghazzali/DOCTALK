"""
propagator.sim
==============
Simulation engine for PROPAGATOR adversarial injection experiments.

This sub-package implements a directed SIR-on-graph model for studying
how adversarial signals propagate across multi-agent topologies.

Exports
-------
AttackType
    Enumeration of the five supported attack mechanisms.
AttackConfig
    Dataclass specifying experiment parameters (attack type, injection
    strength, seed node, trial count, optional similarity override).
AttackResult
    Dataclass holding aggregated numerical output from a completed
    experiment (trajectories, final infection rates, peak velocities,
    attack paths, and summary properties).
ATTACK_BASE_RATES
    Dict mapping each AttackType to its base persistence rate (modulates β).
ATTACK_SEVERITY_WEIGHTS
    Dict mapping each AttackType to its severity weight λ for PRS scoring.
SimulationEngine
    Core SIR-on-graph numerical engine.  Provides run_trial,
    run_experiment, run_full_matrix, compute_r0, calibrate_r0_threshold,
    and set_transmission_weights_from_calibration.
ExperimentRunner
    High-level orchestrator for heterogeneity sweeps and full 4-D
    vulnerability-tensor construction across multiple topologies.
CalibrationPhase
    Estimates per-node, per-attack resistance scores via isolated
    single-agent simulation (no real LLM calls).
"""

from .attacks import (
    ATTACK_BASE_RATES,
    ATTACK_SEVERITY_WEIGHTS,
    AttackConfig,
    AttackResult,
    AttackType,
)
from .engine import SimulationEngine
from .runner import CalibrationPhase, ExperimentRunner

__all__ = [
    "AttackType",
    "AttackConfig",
    "AttackResult",
    "ATTACK_BASE_RATES",
    "ATTACK_SEVERITY_WEIGHTS",
    "SimulationEngine",
    "ExperimentRunner",
    "CalibrationPhase",
]
