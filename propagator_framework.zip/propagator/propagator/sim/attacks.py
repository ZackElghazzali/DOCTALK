"""
propagator.sim.attacks
======================
Attack type definitions, configuration, and result containers for the
PROPAGATOR simulation engine.

Attack model
------------
Each AttackType has a *base persistence rate* that modulates the SIR β
parameter, and a *severity weight* (λ) used by the Propagation Risk Score
metric.  Concrete experiment parameters live in :class:`AttackConfig`;
raw numerical outputs from a completed experiment live in
:class:`AttackResult`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from statistics import mean, stdev
from typing import Optional


# ---------------------------------------------------------------------------
# Attack taxonomy
# ---------------------------------------------------------------------------


class AttackType(Enum):
    """Enumeration of adversarial injection attack types.

    Each member corresponds to a distinct mechanism by which an adversarial
    signal can propagate through a multi-agent graph.
    """

    CONTEXT_POISONING = "context_poisoning"
    """Inject malicious content into shared context windows (75 % persistence)."""

    DIRECT_OVERRIDE = "direct_override"
    """Directly override agent instructions via prompt injection (67 % persistence)."""

    ROLE_HIJACK = "role_hijack"
    """Attempt to reassign the agent's system role (<1 % in homogeneous topologies)."""

    ASSUMPTION_INJECTION = "assumption_injection"
    """Embed false premises that downstream agents inherit (dominant real-world vector)."""

    HALLUCINATION_SEEDING = "hallucination_seeding"
    """Introduce plausible-but-false facts that snowball through the graph (60 % persistence)."""


# ---------------------------------------------------------------------------
# Calibrated rate constants
# ---------------------------------------------------------------------------


#: Per-attack-type base persistence rates.  These scale the effective
#: transmission rate β when a trial is executed:
#:   β_eff = β * ATTACK_BASE_RATES[attack_type]
ATTACK_BASE_RATES: dict[AttackType, float] = {
    AttackType.CONTEXT_POISONING: 0.75,
    AttackType.DIRECT_OVERRIDE: 0.67,
    AttackType.ROLE_HIJACK: 0.15,
    AttackType.ASSUMPTION_INJECTION: 0.80,
    AttackType.HALLUCINATION_SEEDING: 0.60,
}

#: Severity weights λ used by the Propagation Risk Score (PRS).
#: Higher λ means the attack contributes more to the composite risk metric.
ATTACK_SEVERITY_WEIGHTS: dict[AttackType, float] = {
    AttackType.CONTEXT_POISONING: 0.9,
    AttackType.DIRECT_OVERRIDE: 0.7,
    AttackType.ASSUMPTION_INJECTION: 1.0,
    AttackType.HALLUCINATION_SEEDING: 0.6,
    AttackType.ROLE_HIJACK: 0.3,
}


# ---------------------------------------------------------------------------
# AttackConfig
# ---------------------------------------------------------------------------


@dataclass
class AttackConfig:
    """Parameters for a single adversarial injection experiment.

    Attributes
    ----------
    attack_type:
        Which attack mechanism is being modelled.
    injection_strength:
        Initial infection level I_seed ∈ [0, 1] placed on the seed node.
    seed_node_id:
        Identifier of the node where the injection originates.
    trials:
        Number of independent Monte-Carlo trials to run.  Defaults to 30.
    semantic_similarity_override:
        When provided, replaces the graph-derived per-edge transmission
        probability with this fixed value for all edges, which is useful for
        sensitivity analysis.  ``None`` means use the graph's own weights.
    """

    attack_type: AttackType
    injection_strength: float
    seed_node_id: str
    trials: int = 30
    semantic_similarity_override: Optional[float] = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.injection_strength <= 1.0:
            raise ValueError(
                f"injection_strength must be in [0, 1], got {self.injection_strength}"
            )
        if self.trials < 1:
            raise ValueError(f"trials must be ≥ 1, got {self.trials}")
        if (
            self.semantic_similarity_override is not None
            and not 0.0 <= self.semantic_similarity_override <= 1.0
        ):
            raise ValueError(
                "semantic_similarity_override must be in [0, 1] or None, "
                f"got {self.semantic_similarity_override}"
            )


# ---------------------------------------------------------------------------
# AttackResult
# ---------------------------------------------------------------------------


@dataclass
class AttackResult:
    """Aggregated numerical output from a completed injection experiment.

    Attributes
    ----------
    attack_config:
        The configuration that produced this result.
    infection_trajectories:
        One dict per trial.  Each dict maps ``node_id → list[float]`` where
        the list holds I_i(t) for t = 0 … T (length = rounds + 1).
    final_infection_rates:
        Scalar Ī per trial — fraction of agents with I_i > infection_threshold
        at the final round.
    peak_velocities:
        Maximum Σ_i dI_i/dt observed across all rounds, per trial.
    attack_paths:
        Per trial: ordered list of node IDs in the sequence they first
        exceeded the infection threshold.
    """

    attack_config: AttackConfig
    infection_trajectories: list[dict[str, list[float]]] = field(default_factory=list)
    final_infection_rates: list[float] = field(default_factory=list)
    peak_velocities: list[float] = field(default_factory=list)
    attack_paths: list[list[str]] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Computed properties
    # ------------------------------------------------------------------

    @property
    def mean_final_rate(self) -> float:
        """Mean Ī across all trials.

        Returns ``0.0`` when no trials have been recorded yet.
        """
        if not self.final_infection_rates:
            return 0.0
        return mean(self.final_infection_rates)

    @property
    def std_final_rate(self) -> float:
        """Standard deviation of Ī across all trials.

        Returns ``0.0`` when fewer than two trials have been recorded.
        """
        if len(self.final_infection_rates) < 2:
            return 0.0
        return stdev(self.final_infection_rates)

    @property
    def mean_peak_velocity(self) -> float:
        """Mean peak Σ dI/dt across all trials.

        Returns ``0.0`` when no trials have been recorded yet.
        """
        if not self.peak_velocities:
            return 0.0
        return mean(self.peak_velocities)

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"AttackResult(attack={self.attack_config.attack_type.value!r}, "
            f"seed={self.attack_config.seed_node_id!r}, "
            f"trials={len(self.final_infection_rates)}, "
            f"mean_final_rate={self.mean_final_rate:.4f}, "
            f"std={self.std_final_rate:.4f})"
        )
