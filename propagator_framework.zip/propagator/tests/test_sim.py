"""
tests/test_sim.py
=================
Tests for the propagator.sim module.

Covers:
* run_trial produces infection trajectories with correct shape
* R₀ computation returns a positive float for connected graphs
* Seeded node has I > 0 at round 0
* Infection never exceeds 1.0 across all nodes and rounds
* CalibrationPhase produces resistance scores in [0, 1]
"""

import pytest

from propagator.graph import TopologyFactory
from propagator.sim import (
    AttackConfig,
    AttackType,
    CalibrationPhase,
    SimulationEngine,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _engine(n: int = 4, topology: str = "chain", beta: float = 0.3, rounds: int = 10) -> SimulationEngine:
    """Return a SimulationEngine for the requested canonical topology."""
    if topology == "chain":
        g = TopologyFactory.chain(n=n)
    elif topology == "star":
        g = TopologyFactory.star(n_leaves=n - 1)
    elif topology == "complete":
        g = TopologyFactory.complete(n=n)
    else:
        g = TopologyFactory.chain(n=n)
    return SimulationEngine(g, beta=beta, gamma=0.0, rounds=rounds, random_seed=42)


def _cfg(
    attack_type: AttackType = AttackType.CONTEXT_POISONING,
    injection_strength: float = 0.9,
    seed_node_id: str = "agent_0",
    trials: int = 5,
) -> AttackConfig:
    return AttackConfig(
        attack_type=attack_type,
        injection_strength=injection_strength,
        seed_node_id=seed_node_id,
        trials=trials,
    )


# ---------------------------------------------------------------------------
# run_trial — trajectory shape
# ---------------------------------------------------------------------------


class TestRunTrial:
    """run_trial returns trajectories with correct structure."""

    def test_returns_dict(self):
        eng = _engine()
        traj = eng.run_trial(_cfg())
        assert isinstance(traj, dict)

    def test_trajectory_has_all_nodes(self):
        eng = _engine(n=4)
        traj = eng.run_trial(_cfg())
        assert set(traj.keys()) == set(eng.graph.node_ids())

    def test_trajectory_length_equals_rounds_plus_one(self):
        eng = _engine(n=4, rounds=10)
        traj = eng.run_trial(_cfg())
        for node_id, series in traj.items():
            assert len(series) == 11, f"Node {node_id!r}: expected 11 time-steps, got {len(series)}"

    def test_trajectory_values_in_unit_interval(self):
        eng = _engine(n=5)
        traj = eng.run_trial(_cfg())
        for node_id, series in traj.items():
            for t, val in enumerate(series):
                assert 0.0 <= val <= 1.0, (
                    f"Node {node_id!r} t={t}: infection {val} outside [0, 1]"
                )

    def test_seed_node_infected_at_round_zero(self):
        seed = "agent_0"
        eng = _engine(n=4, topology="chain")
        traj = eng.run_trial(_cfg(seed_node_id=seed, injection_strength=0.8))
        assert traj[seed][0] == pytest.approx(0.8, abs=1e-6)

    def test_non_seed_zero_at_round_zero(self):
        eng = _engine(n=4, topology="chain")
        traj = eng.run_trial(_cfg(seed_node_id="agent_0"))
        for node_id, series in traj.items():
            if node_id != "agent_0":
                assert series[0] == pytest.approx(0.0, abs=1e-6)

    def test_infection_propagates_beyond_seed(self):
        """With high beta and enough rounds, infection reaches other nodes."""
        eng = SimulationEngine(
            TopologyFactory.chain(n=3),
            beta=0.8, gamma=0.0, rounds=30
        )
        traj = eng.run_trial(_cfg(seed_node_id="agent_0", injection_strength=1.0))
        # At least one other node should have non-zero infection by end
        non_seed_infected = any(
            traj[nid][-1] > 0.01
            for nid in eng.graph.node_ids()
            if nid != "agent_0"
        )
        assert non_seed_infected

    def test_invalid_seed_raises(self):
        eng = _engine(n=4)
        with pytest.raises(ValueError):
            eng.run_trial(_cfg(seed_node_id="nonexistent_node"))


# ---------------------------------------------------------------------------
# R₀ computation
# ---------------------------------------------------------------------------


class TestComputeR0:
    """compute_r0 returns a positive float for connected topologies."""

    def test_ring_r0_is_positive(self):
        """Ring graph has cycles → R₀ > 0."""
        g = TopologyFactory.ring(n=4)
        eng = SimulationEngine(g, beta=0.3)
        r0 = eng.compute_r0()
        assert isinstance(r0, float)
        assert r0 > 0.0

    def test_chain_r0_is_nonneg(self):
        """Chain DAG has no cycles; R₀ may be 0 (spectral radius of nilpotent matrix)."""
        eng = _engine(n=4, topology="chain", beta=0.3)
        r0 = eng.compute_r0()
        assert isinstance(r0, float)
        assert r0 >= 0.0

    def test_complete_r0_greater_than_ring(self):
        """Complete graph has more cycles → higher R₀ than ring."""
        n = 4
        ring_eng    = SimulationEngine(TopologyFactory.ring(n=n), beta=0.3)
        complete_eng = SimulationEngine(TopologyFactory.complete(n=n), beta=0.3)
        assert complete_eng.compute_r0() >= ring_eng.compute_r0()

    def test_r0_scales_with_beta(self):
        """R₀ is proportional to β for a fixed graph with cycles."""
        g = TopologyFactory.ring(n=4)  # ring has cycles → non-zero R₀
        eng_low  = SimulationEngine(g, beta=0.1)
        eng_high = SimulationEngine(g, beta=0.9)
        assert eng_high.compute_r0() > eng_low.compute_r0()

    def test_r0_degenerate_single_node(self):
        """Single-node graph → R₀ = 0."""
        from propagator.graph import PropagatorGraph, AgentNode
        g = PropagatorGraph(name="single")
        g.add_agent(AgentNode(node_id="only"))
        eng = SimulationEngine(g, beta=0.5)
        assert eng.compute_r0() == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# run_experiment
# ---------------------------------------------------------------------------


class TestRunExperiment:
    """run_experiment aggregates multiple trials into AttackResult."""

    def test_returns_attack_result(self):
        from propagator.sim import AttackResult
        eng = _engine(n=4)
        result = eng.run_experiment(_cfg(trials=3))
        assert isinstance(result, AttackResult)

    def test_final_infection_rates_count(self):
        eng = _engine(n=4)
        result = eng.run_experiment(_cfg(trials=5))
        assert len(result.final_infection_rates) == 5

    def test_mean_final_rate_in_unit_interval(self):
        eng = _engine(n=4)
        result = eng.run_experiment(_cfg(trials=5))
        assert 0.0 <= result.mean_final_rate <= 1.0

    def test_all_infection_rates_in_unit_interval(self):
        eng = _engine(n=5, topology="star")
        result = eng.run_experiment(_cfg(trials=10, seed_node_id="hub"))
        for rate in result.final_infection_rates:
            assert 0.0 <= rate <= 1.0

    def test_infection_never_exceeds_1(self):
        """No individual trajectory value should exceed 1.0."""
        eng = _engine(n=5, topology="complete", beta=0.9)
        result = eng.run_experiment(
            _cfg(trials=5, injection_strength=1.0, seed_node_id="agent_0")
        )
        for traj in result.infection_trajectories:
            for node_id, series in traj.items():
                for val in series:
                    assert val <= 1.0 + 1e-9, (
                        f"Infection {val} > 1 for node {node_id!r}"
                    )

    def test_peak_velocities_count(self):
        eng = _engine(n=4)
        result = eng.run_experiment(_cfg(trials=5))
        assert len(result.peak_velocities) == 5


# ---------------------------------------------------------------------------
# CalibrationPhase
# ---------------------------------------------------------------------------


class TestCalibrationPhase:
    """CalibrationPhase produces resistance scores in [0, 1]."""

    def test_produces_all_nodes(self):
        g = TopologyFactory.chain(n=4)
        calib = CalibrationPhase(random_seed=0)
        scores = calib.run(g, list(AttackType), trials_per_cell=20)
        assert set(scores.keys()) == set(g.node_ids())

    def test_produces_all_attack_types(self):
        g = TopologyFactory.chain(n=3)
        calib = CalibrationPhase(random_seed=0)
        scores = calib.run(g, list(AttackType), trials_per_cell=20)
        for node_scores in scores.values():
            for at in AttackType:
                assert at.value in node_scores

    def test_scores_in_unit_interval(self):
        g = TopologyFactory.star(n_leaves=4)
        calib = CalibrationPhase(random_seed=7)
        scores = calib.run(g, list(AttackType), trials_per_cell=50)
        for node_id, node_scores in scores.items():
            for atk_val, r_i in node_scores.items():
                assert 0.0 <= r_i <= 1.0, (
                    f"node={node_id!r} attack={atk_val!r}: r_i={r_i} outside [0, 1]"
                )

    def test_higher_hardening_higher_resistance(self):
        """Harder nodes should generally resist more (statistical test)."""
        from propagator.graph import PropagatorGraph, AgentNode
        g = PropagatorGraph(name="test")
        g.add_agent(AgentNode(node_id="soft", hardening_level=0))
        g.add_agent(AgentNode(node_id="hard", hardening_level=2))

        calib = CalibrationPhase(random_seed=42)
        scores = calib.run(g, [AttackType.CONTEXT_POISONING], trials_per_cell=200)

        r_soft = scores["soft"][AttackType.CONTEXT_POISONING.value]
        r_hard = scores["hard"][AttackType.CONTEXT_POISONING.value]
        # Hard node should have higher resistance (statistically)
        assert r_hard > r_soft

    def test_seeded_reproducibility(self):
        g = TopologyFactory.chain(n=3)
        calib1 = CalibrationPhase(random_seed=99)
        calib2 = CalibrationPhase(random_seed=99)
        s1 = calib1.run(g, [AttackType.DIRECT_OVERRIDE], trials_per_cell=50)
        s2 = calib2.run(g, [AttackType.DIRECT_OVERRIDE], trials_per_cell=50)
        for node_id in g.node_ids():
            assert s1[node_id] == s2[node_id]
