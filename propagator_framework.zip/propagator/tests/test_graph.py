"""
tests/test_graph.py
===================
Tests for the propagator.graph module.

Covers:
* All 8 canonical topology generators (node/edge count correctness)
* add_agent / add_edge
* transmission_probability computation
* heterogeneity_variance
* to_dict / from_dict round-trip
* PropagatorGraph.copy

Note: PropagatorGraph uses node_ids() (method) for public node access
      and _nodes (dict) internally.  edge_list() returns list of (src, tgt).
"""

import pytest

from propagator.graph import (
    AgentEdge,
    AgentNode,
    AgentRole,
    ContextMode,
    ModelFamily,
    PropagatorGraph,
    TopologyFactory,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _node(node_id: str, hardening: int = 0, role: AgentRole = AgentRole.SPECIALIST) -> AgentNode:
    """Convenience factory for minimal AgentNode instances."""
    return AgentNode(node_id=node_id, role=role, hardening_level=hardening)


# ---------------------------------------------------------------------------
# 8 canonical topologies — node / edge count assertions
# ---------------------------------------------------------------------------


class TestTopologyGenerators:
    """All 8 canonical topology generators produce correct structure."""

    def test_chain_nodes(self):
        g = TopologyFactory.chain(n=4)
        assert len(g.node_ids()) == 4

    def test_chain_edges(self):
        g = TopologyFactory.chain(n=4)
        # Chain: n-1 directed edges
        assert len(g.edge_list()) == 3

    def test_chain_minimum_n(self):
        with pytest.raises(ValueError):
            TopologyFactory.chain(n=1)

    def test_star_nodes(self):
        # n_leaves=5 → hub + 5 leaves = 6 nodes
        g = TopologyFactory.star(n_leaves=5)
        assert len(g.node_ids()) == 6

    def test_star_edges_bidirectional(self):
        # Bidirectional (default): 2 * n_leaves edges
        g = TopologyFactory.star(n_leaves=4, bidirectional=True)
        assert len(g.edge_list()) == 8

    def test_star_edges_unidirectional(self):
        g = TopologyFactory.star(n_leaves=4, bidirectional=False)
        assert len(g.edge_list()) == 4

    def test_ring_nodes(self):
        g = TopologyFactory.ring(n=6)
        assert len(g.node_ids()) == 6

    def test_ring_edges(self):
        # Ring: exactly n directed edges (cyclic)
        g = TopologyFactory.ring(n=6)
        assert len(g.edge_list()) == 6

    def test_complete_nodes(self):
        g = TopologyFactory.complete(n=4)
        assert len(g.node_ids()) == 4

    def test_complete_edges(self):
        # Complete directed graph: n*(n-1) edges
        g = TopologyFactory.complete(n=4)
        assert len(g.edge_list()) == 4 * 3

    def test_tree_nodes(self):
        g = TopologyFactory.tree(n=7, branching_factor=2)
        assert len(g.node_ids()) == 7

    def test_tree_edges(self):
        # Tree: n-1 edges (one per non-root node)
        g = TopologyFactory.tree(n=7, branching_factor=2)
        assert len(g.edge_list()) == 6

    def test_star_ring_nodes(self):
        g = TopologyFactory.star_ring(n_leaves=4)
        # hub + 4 leaves = 5 nodes
        assert len(g.node_ids()) == 5

    def test_star_ring_edges(self):
        # 2*n_leaves (star bidirectional) + n_leaves (ring) = 3*n_leaves
        g = TopologyFactory.star_ring(n_leaves=4)
        assert len(g.edge_list()) == 3 * 4

    def test_star_ring_minimum_leaves(self):
        with pytest.raises(ValueError):
            TopologyFactory.star_ring(n_leaves=2)

    def test_layered_dag_nodes(self):
        g = TopologyFactory.layered_dag(n_layers=3, layer_width=2)
        assert len(g.node_ids()) == 6  # 3 * 2

    def test_layered_dag_edges(self):
        # Each pair of adjacent layers: layer_width^2 edges
        # (n_layers-1) * layer_width^2
        g = TopologyFactory.layered_dag(n_layers=3, layer_width=2)
        assert len(g.edge_list()) == 2 * (2 ** 2)

    def test_decentralized_mesh_nodes(self):
        g = TopologyFactory.decentralized_mesh(n=5, p=0.5, seed=0)
        assert len(g.node_ids()) == 5

    def test_decentralized_mesh_has_edges(self):
        # With p=0.9 and seed there should definitely be some edges
        g = TopologyFactory.decentralized_mesh(n=5, p=0.9, seed=42)
        assert len(g.edge_list()) > 0

    def test_all_canonical_returns_8_topologies(self):
        topos = TopologyFactory.all_canonical(n=6)
        assert len(topos) == 8
        expected_keys = {
            "chain", "star", "ring", "complete",
            "tree", "star_ring", "layered_dag", "decentralized_mesh",
        }
        assert set(topos.keys()) == expected_keys

    def test_all_canonical_all_have_nodes(self):
        topos = TopologyFactory.all_canonical(n=6)
        for name, g in topos.items():
            assert len(g.node_ids()) > 0, f"Topology {name!r} has no nodes"

    def test_all_canonical_all_have_edges(self):
        topos = TopologyFactory.all_canonical(n=6)
        for name, g in topos.items():
            assert len(g.edge_list()) > 0, f"Topology {name!r} has no edges"


# ---------------------------------------------------------------------------
# add_agent / add_edge
# ---------------------------------------------------------------------------


class TestAddAgentAndEdge:
    """Manual node/edge construction."""

    def test_add_single_agent(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        assert "a" in g            # uses __contains__
        assert len(g.node_ids()) == 1

    def test_add_multiple_agents(self):
        g = PropagatorGraph(name="test")
        for i in range(5):
            g.add_agent(_node(f"n{i}"))
        assert len(g.node_ids()) == 5

    def test_add_duplicate_agent_raises(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        with pytest.raises(ValueError):
            g.add_agent(_node("a"))

    def test_add_edge(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        g.add_agent(_node("b"))
        g.add_edge(AgentEdge(source_id="a", target_id="b", weight=0.8))
        assert ("a", "b") in g.edge_list()

    def test_add_edge_invalid_weight_raises(self):
        with pytest.raises(ValueError):
            AgentEdge(source_id="a", target_id="b", weight=1.5)

    def test_add_edge_missing_node_raises(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        with pytest.raises((KeyError, ValueError)):
            g.add_edge(AgentEdge(source_id="a", target_id="z"))

    def test_get_agent(self):
        g = PropagatorGraph(name="test")
        node = _node("agent_x", hardening=2)
        g.add_agent(node)
        retrieved = g.get_agent("agent_x")
        assert retrieved.node_id == "agent_x"
        assert retrieved.hardening_level == 2

    def test_get_edge(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        g.add_agent(_node("b"))
        g.add_edge(AgentEdge(source_id="a", target_id="b", weight=0.5))
        edge = g.get_edge("a", "b")
        assert edge.weight == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# transmission_probability
# ---------------------------------------------------------------------------


class TestTransmissionProbability:
    """Edge transmission probability computation."""

    def test_returns_float_in_unit_interval(self):
        g = TopologyFactory.chain(n=4)
        nodes = g.node_ids()
        p = g.transmission_probability(nodes[0], nodes[1], attack_type="context_poisoning")
        assert isinstance(p, float)
        assert 0.0 <= p <= 1.0

    def test_higher_weight_higher_probability(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        g.add_agent(_node("b"))
        g.add_agent(_node("c"))
        g.add_edge(AgentEdge(source_id="a", target_id="b", weight=0.9))
        g.add_edge(AgentEdge(source_id="a", target_id="c", weight=0.1))
        p_b = g.transmission_probability("a", "b", attack_type="context_poisoning")
        p_c = g.transmission_probability("a", "c", attack_type="context_poisoning")
        assert p_b > p_c

    def test_different_attack_types_differ(self):
        g = TopologyFactory.chain(n=3)
        nodes = g.node_ids()
        p_injection = g.transmission_probability(
            nodes[0], nodes[1], attack_type="context_poisoning"
        )
        p_hijack = g.transmission_probability(
            nodes[0], nodes[1], attack_type="role_hijack"
        )
        # role_hijack has lower base rate (0.15) vs context_poisoning (0.75)
        # so their transmission probabilities should differ
        assert isinstance(p_injection, float)
        assert isinstance(p_hijack, float)


# ---------------------------------------------------------------------------
# heterogeneity_variance
# ---------------------------------------------------------------------------


class TestHeterogeneityVariance:
    """heterogeneity_variance returns a non-negative float."""

    def test_chain_variance_is_nonneg(self):
        g = TopologyFactory.chain(n=5)
        var = g.heterogeneity_variance()
        assert isinstance(var, float)
        assert var >= 0.0

    def test_diverse_graph_higher_variance(self):
        """Graph with distinct model families → higher variance than uniform."""
        uniform_g = PropagatorGraph(name="uniform")
        for i in range(4):
            uniform_g.add_agent(AgentNode(
                node_id=f"a{i}",
                model_family=ModelFamily.GPT4O,
            ))

        diverse_g = PropagatorGraph(name="diverse")
        families = [ModelFamily.GPT4O, ModelFamily.CLAUDE35, ModelFamily.LLAMA33, ModelFamily.GEMMA2]
        for i, mf in enumerate(families):
            diverse_g.add_agent(AgentNode(node_id=f"a{i}", model_family=mf))

        # Diverse graph should have equal or higher heterogeneity variance
        assert diverse_g.heterogeneity_variance() >= uniform_g.heterogeneity_variance()


# ---------------------------------------------------------------------------
# to_dict / from_dict round-trip
# ---------------------------------------------------------------------------


class TestSerialisationRoundTrip:
    """to_dict / from_dict preserves graph structure."""

    def test_chain_round_trip_node_count(self):
        g = TopologyFactory.chain(n=5)
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert len(g2.node_ids()) == len(g.node_ids())

    def test_chain_round_trip_edge_count(self):
        g = TopologyFactory.chain(n=5)
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert len(g2.edge_list()) == len(g.edge_list())

    def test_star_round_trip_node_ids(self):
        g = TopologyFactory.star(n_leaves=3)
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert set(g2.node_ids()) == set(g.node_ids())

    def test_round_trip_hardening_levels(self):
        g = PropagatorGraph(name="test")
        g.add_agent(AgentNode(node_id="a", hardening_level=2))
        g.add_agent(AgentNode(node_id="b", hardening_level=1))
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert g2.get_agent("a").hardening_level == 2
        assert g2.get_agent("b").hardening_level == 1

    def test_round_trip_edge_weights(self):
        g = PropagatorGraph(name="test")
        g.add_agent(_node("a"))
        g.add_agent(_node("b"))
        g.add_edge(AgentEdge(source_id="a", target_id="b", weight=0.42))
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert g2.get_edge("a", "b").weight == pytest.approx(0.42)

    def test_round_trip_graph_name(self):
        g = PropagatorGraph(name="my_test_graph")
        g.add_agent(_node("x"))
        d = g.to_dict()
        g2 = PropagatorGraph.from_dict(d)
        assert g2.name == "my_test_graph"


# ---------------------------------------------------------------------------
# PropagatorGraph.copy
# ---------------------------------------------------------------------------


class TestGraphCopy:
    """PropagatorGraph.copy produces an independent deep copy."""

    def test_copy_has_same_node_count(self):
        g = TopologyFactory.star(n_leaves=4)
        gc = g.copy()
        assert len(gc.node_ids()) == len(g.node_ids())

    def test_copy_has_same_edge_count(self):
        g = TopologyFactory.star(n_leaves=4)
        gc = g.copy()
        assert len(gc.edge_list()) == len(g.edge_list())

    def test_copy_is_independent(self):
        g = TopologyFactory.chain(n=3)
        gc = g.copy()
        # Adding a node to the copy should not affect the original
        gc.add_agent(_node("extra"))
        assert "extra" not in g   # uses __contains__

    def test_copy_preserves_node_ids(self):
        g = TopologyFactory.chain(n=3)
        gc = g.copy()
        assert set(gc.node_ids()) == set(g.node_ids())

    def test_copy_preserves_edge_list(self):
        g = TopologyFactory.chain(n=3)
        gc = g.copy()
        assert set(gc.edge_list()) == set(g.edge_list())
