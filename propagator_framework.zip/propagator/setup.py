"""
Setup script for the PROPAGATOR package.

For modern installations, prefer pyproject.toml.  This file is retained
for compatibility with older toolchains (e.g. `pip install -e .` without
PEP 517 build isolation).
"""

from setuptools import find_packages, setup

setup(
    name="propagator",
    version="0.1.0",
    description=(
        "Topology-Aware Vulnerability Propagation Framework "
        "for Multi-Agent LLM Systems"
    ),
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="GTRI CIPHER Lab",
    url="https://github.com/gtri/propagator",
    packages=find_packages(exclude=["tests", "tests.*"]),
    python_requires=">=3.10",
    install_requires=[
        "numpy>=1.24",
        "scipy>=1.10",
        "networkx>=3.0",
        "matplotlib>=3.7",
    ],
    extras_require={
        "maf": [
            "microsoft-agents-ai>=1.0",
            "microsoft-agents-ai-openai>=1.0",
        ],
        "autogen": ["ag2>=0.9.10"],  # legacy; kept for backward compatibility
        "dev": [
            "pytest>=7.0",
            "pytest-cov",
            "black",
            "mypy",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[
        "multi-agent systems",
        "LLM security",
        "propagation",
        "vulnerability",
        "graph",
        "adversarial",
    ],
)
